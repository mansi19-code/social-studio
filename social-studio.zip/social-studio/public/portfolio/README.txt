========================================================================
SOCIAL STUDIO — PORTFOLIO MEDIA FOLDER
========================================================================

Drop your real files right here in this folder (`/public/portfolio/`):

1. Images:
   - Instagram posts / Carousels (.jpg, .png, .webp)
   - Posters & Branding packaging (.png, .jpg)
   - Graphic design work (.jpg, .png)
   - Studio photos & BTS

2. Videos:
   - Reels / TikToks (.mp4, .webm)
   - Shorts / campaign teasers

3. Then open `src/data/projects.ts` and set:
   `coverImage: '/portfolio/your-file-name.jpg'`

Whenever an entry in `src/data/projects.ts` doesn't have an image set yet,
Social Studio displays an elegant, on-brand scrapbook placeholder automatically!
========================================================================
