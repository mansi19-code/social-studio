# Annapurna Events — Creative Assets Vault
📁 Directory: `/public/portfolio/annapurna-events/`

Welcome to your client assets folder for **ANNAPURNA EVENTS**!

---

### How to Add Your Creative Work:

1. **Drop your actual media files into this folder:**
   - **Instagram Posts & Carousels**: `.jpg`, `.png`, `.webp`
   - **Festive Campaigns & Posters**: `.jpg`, `.png`, `.webp`
   - **Stories & Vertical Graphics**: `.jpg`, `.png`, `.webp`
   - **Reels & Video Showcases**: `.mp4`
   - **Cover Image**: You can name a landscape or 4:3 image `cover.jpg` (or any name you prefer) to use as the main card preview.

2. **Register your files in the data config file:**
   Open `src/data/annapurnaEvents.ts`. In the `annapurnaMediaItems` array, simply add your file entries:
   ```ts
   {
     id: 'festive-1',
     title: 'Diwali Festive Campaign',
     category: 'Festive Creatives',
     src: '/portfolio/annapurna-events/diwali-creative.jpg',
     type: 'image',
     caption: 'Champagne luxury gold festive campaign creative'
   },
   {
     id: 'reel-1',
     title: 'Grand Wedding Decor Reveal',
     category: 'Reels & Videos',
     src: '/portfolio/annapurna-events/wedding-decor.mp4',
     type: 'video',
     caption: 'Behind-the-scenes event production reel'
   }
   ```

3. **Reordering or Removing:**
   - To reorder: simply cut and paste the objects in the array in your desired order.
   - To remove: delete the object from the array.

4. **Zero AI images:**
   Only your actual creative work is showcased. If this folder has no uploaded files yet, the website displays an elegant, on-brand editable placeholder explaining where to drop your files.
