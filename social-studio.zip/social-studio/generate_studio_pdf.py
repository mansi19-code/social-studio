import os
import sys
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image as RLImage, Table, TableStyle, PageBreak, KeepTogether, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.pdfgen import canvas

# Define Palette
PINK = colors.HexColor('#FF6496')
PINK_HOT = colors.HexColor('#FF2A7A')
PINK_SOFT = colors.HexColor('#FFF0F5')
CREAM = colors.HexColor('#FAF6EE')
DARK = colors.HexColor('#141416')
YELLOW = colors.HexColor('#FDE047')
GREEN = colors.HexColor('#72C29B')
GREEN_SOFT = colors.HexColor('#E8F5EE')
PURPLE_SOFT = colors.HexColor('#F3E8FF')
GRAY_LIGHT = colors.HexColor('#F4F4F6')
GRAY_TEXT = colors.HexColor('#55555C')

class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super(NumberedCanvas, self).__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super(NumberedCanvas, self).showPage()
        super(NumberedCanvas, self).save()

    def draw_page_decorations(self, page_count):
        # Don't draw footer on cover page
        if self._pageNumber == 1:
            return

        self.saveState()
        self.setFont("Helvetica-Bold", 8)
        self.setFillColor(PINK)
        self.drawString(36, 24, "SOCIAL STUDIO ♡")
        
        self.setFont("Helvetica", 8)
        self.setFillColor(GRAY_TEXT)
        self.drawString(120, 24, "•  Creative Social Media & Digital Agency")
        
        page_text = f"Page {self._pageNumber} of {page_count}"
        self.drawRightString(A4[0] - 36, 24, page_text)
        
        # Top subtle bar
        self.setStrokeColor(PINK)
        self.setLineWidth(1.5)
        self.line(36, A4[1] - 25, A4[0] - 36, A4[1] - 25)
        
        self.restoreState()

def build_pdf(output_path, project_root):
    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=40
    )

    styles = getSampleStyleSheet()

    # Custom typography styles
    title_style = ParagraphStyle(
        'CoverTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=32,
        leading=38,
        textColor=DARK,
        alignment=TA_LEFT
    )

    h1_style = ParagraphStyle(
        'SectionHeading',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=26,
        textColor=DARK,
        spaceAfter=12
    )

    h2_style = ParagraphStyle(
        'SubHeading',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=13,
        leading=18,
        textColor=PINK_HOT,
        spaceAfter=6
    )

    body_style = ParagraphStyle(
        'Body',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9.5,
        leading=14,
        textColor=DARK
    )

    badge_style = ParagraphStyle(
        'Badge',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8,
        leading=10,
        textColor=PINK_HOT,
        alignment=TA_CENTER
    )

    quote_style = ParagraphStyle(
        'Quote',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=12,
        leading=17,
        textColor=PINK_HOT,
        alignment=TA_LEFT
    )

    story = []

    # Paths to visual assets
    public_dir = os.path.join(project_root, 'public')
    cutout_path = os.path.join(public_dir, 'mansi-full-cutout.png')
    headshot_path = os.path.join(public_dir, 'stickers', 'headshot.png')
    reels_img_path = os.path.join(public_dir, 'portfolio', 'portfolio_social_reels.jpg')
    carousel_img_path = os.path.join(public_dir, 'portfolio', 'portfolio_carousel_content.jpg')
    cafe_img_path = os.path.join(public_dir, 'portfolio', 'portfolio_branding_cafe.jpg')
    skincare_img_path = os.path.join(public_dir, 'portfolio', 'portfolio_campaign_skincare.jpg')
    web_img_path = os.path.join(public_dir, 'portfolio', 'portfolio_web_academy.jpg')

    # ==========================================
    # PAGE 1: COVER
    # ==========================================
    header_table = Table([
        [
            Paragraph("<font color='#FF2A7A'><b>SOCIAL STUDIO ♡</b></font>", ParagraphStyle('H', fontName='Helvetica-Bold', fontSize=14, leading=16)),
            Paragraph("<font color='#55555C'>CREATIVE AGENCY PORTFOLIO & BRAND GUIDE</font>", ParagraphStyle('HR', fontName='Helvetica-Bold', fontSize=9, alignment=TA_RIGHT))
        ]
    ], colWidths=[250, 270])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(header_table)
    story.append(HRFlowable(width="100%", thickness=2, color=PINK, spaceAfter=25))

    # Hero Banner
    story.append(Paragraph("YOUR BRAND.<br/><font color='#FF6496'>OUR CREATIVITY.</font><br/><i>LET’S MAKE IT MOVE.</i>", title_style))
    story.append(Spacer(1, 10))
    story.append(Paragraph("<b>Turning ideas into scroll-stopping content, memorable brands and digital experiences.</b>", quote_style))
    story.append(Spacer(1, 20))

    # Cover Visual Grid (Mansi cutout + Agency Pillars)
    if os.path.exists(cutout_path):
        mansi_img = RLImage(cutout_path, width=2.4*inch, height=2.6*inch)
    else:
        mansi_img = Paragraph("Mansi Visual", body_style)

    intro_text = """
    <b>FOUNDER & CREATIVE DIRECTOR:</b><br/>
    Mansi<br/><br/>
    <b>CORE PHILOSOPHY:</b><br/>
    ATTRACTIVE → INFORMATIVE → CONSISTENT → STUDENT-FOCUSED<br/><br/>
    <b>MAIN DISCIPLINES:</b><br/>
    • Content Creation & UGC Production<br/>
    • Graphic Design & Brand Identity<br/>
    • Social Media Strategy & Calendars<br/>
    • High-Retention Copywriting & Hooks<br/>
    • Performance Marketing & Ad Creatives<br/>
    • Modern Motion-Rich Websites<br/><br/>
    <b>STUDIO VIBE:</b><br/>
    Pinterest × Canva × Modern Creative Agency × Digital Scrapbook
    """

    cover_grid = Table([
        [mansi_img, Paragraph(intro_text, body_style)]
    ], colWidths=[2.5*inch, 4.3*inch])
    cover_grid.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('BACKGROUND', (1, 0), (1, 0), PINK_SOFT),
        ('BOX', (1, 0), (1, 0), 1.5, PINK),
        ('TOPPADDING', (1, 0), (1, 0), 14),
        ('BOTTOMPADDING', (1, 0), (1, 0), 14),
        ('LEFTPADDING', (1, 0), (1, 0), 14),
        ('RIGHTPADDING', (1, 0), (1, 0), 14),
    ]))
    story.append(cover_grid)

    story.append(Spacer(1, 30))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#E5E5E8'), spaceAfter=15))
    
    footer_cover = Table([
        [
            Paragraph("<b>Website:</b> http://localhost:5173", body_style),
            Paragraph("<b>Inquiries:</b> hello@socialstudio.design", body_style),
            Paragraph("<b>Instagram:</b> @socialstudio.creative", body_style)
        ]
    ], colWidths=[175, 175, 170])
    story.append(footer_cover)
    story.append(PageBreak())

    # ==========================================
    # PAGE 2: MEET MANSI & BRAND PHILOSOPHY
    # ==========================================
    story.append(Paragraph("MEET THE MIND BEHIND SOCIAL STUDIO", h1_style))
    story.append(Paragraph("“Hi, I’m Mansi — the creative mind behind Social Studio.”", h2_style))
    story.append(Paragraph(
        "I combine <b>creativity, content, design and strategy</b> to help brands build an online presence that actually feels like them. "
        "Most agencies outsource your account to tired interns who churn out lifeless templates that nobody saves or shares. "
        "At Social Studio, I personally direct your strategy, script your hooks, and craft visual identities that build genuine community.",
        body_style
    ))
    story.append(Spacer(1, 14))

    # Voice Script Box
    script_box = Table([
        [
            Paragraph(
                "<b>🎙️ MANSI'S PERSONAL VOICE NOTE & SCRIPT:</b><br/><br/>"
                "<i>“Hey, I’m Mansi, the founder of Social Studio.<br/><br/>"
                "I love turning ideas into content that looks good, communicates clearly and actually connects with people.<br/><br/>"
                "From social media and graphic design to content creation, strategy and websites, Social Studio is all about helping brands show up online with confidence.<br/><br/>"
                "If you have an idea, let’s turn it into something people remember.” ♡</i>",
                ParagraphStyle('VoiceText', parent=body_style, fontSize=10, leading=15, textColor=DARK)
            )
        ]
    ], colWidths=[520])
    script_box.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#FEF9C3')), # Yellow note
        ('BOX', (0, 0), (-1, -1), 2, DARK),
        ('TOPPADDING', (0, 0), (-1, -1), 14),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 14),
        ('LEFTPADDING', (0, 0), (-1, -1), 16),
        ('RIGHTPADDING', (0, 0), (-1, -1), 16),
    ]))
    story.append(script_box)
    story.append(Spacer(1, 18))

    story.append(Paragraph("OUR 4 BRAND PILLARS", h2_style))
    
    pillars_data = [
        [
            Paragraph("<b>01. ATTRACTIVE.</b><br/><i>“Make them stop scrolling.” ♡</i><br/>Demanding immediate visual intrigue in under 1.5 seconds.", body_style),
            Paragraph("<b>02. INFORMATIVE.</b><br/><i>“Give them a reason to stay.” 💡</i><br/>Substantive value, education, and actionable takeaways.", body_style),
        ],
        [
            Paragraph("<b>03. CONSISTENT.</b><br/><i>“Make them remember you.” ✨</i><br/>Unwavering visual identity and regular publishing cadence.", body_style),
            Paragraph("<b>04. STUDENT-FOCUSED.</b><br/><i>“Always curious, always learning.” 📚</i><br/>Constant testing, platform curiosity, and trend innovation.", body_style),
        ]
    ]
    pillars_table = Table(pillars_data, colWidths=[255, 255])
    pillars_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), PINK_SOFT),
        ('BOX', (0, 0), (-1, -1), 1, PINK),
        ('INNERGRID', (0, 0), (-1, -1), 1, colors.HexColor('#FFB8D2')),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
    ]))
    story.append(pillars_table)
    story.append(PageBreak())

    # ==========================================
    # PAGE 3: WHAT WE DO (THE 6 SERVICES)
    # ==========================================
    story.append(Paragraph("WHAT CAN WE CREATE FOR YOU?", h1_style))
    story.append(Paragraph("Our 6 full-funnel creative services engineered for high conversion and thumb-stopping attention:", body_style))
    story.append(Spacer(1, 10))

    services_rows = [
        [
            Paragraph("<b>CONTENT CREATION</b><br/><font color='#FF2A7A'><i>“Reels, carousels, stories, campaigns & scroll-stopping content.”</i></font><br/>Cinematic vertical video, audio syncing, and retention hook architecture.", body_style),
            Paragraph("<b>GRAPHIC DESIGN</b><br/><font color='#FF2A7A'><i>“Creative visuals that make your brand instantly recognizable.”</i></font><br/>Custom Gen-Z palettes, signature stickers, packaging & editorial grid styling.", body_style)
        ],
        [
            Paragraph("<b>SOCIAL MEDIA STRATEGY</b><br/><font color='#FF2A7A'><i>“Content pillars, calendars, positioning and growth-focused planning.”</i></font><br/>Comprehensive monthly roadmaps, competitor whitespace analysis & KPI tracking.", body_style),
            Paragraph("<b>COPYWRITING</b><br/><font color='#FF2A7A'><i>“Hooks, captions, CTAs and messaging that sound like your brand.”</i></font><br/>Voice-matched storytelling that eliminates corporate speak and sparks comment engagement.", body_style)
        ],
        [
            Paragraph("<b>PERFORMANCE MARKETING</b><br/><font color='#FF2A7A'><i>“Creative campaigns designed around attention and action.”</i></font><br/>Native-feeling UGC and aesthetic paid social ads designed for maximum return on spend.", body_style),
            Paragraph("<b>WEBSITE BUILDING</b><br/><font color='#FF2A7A'><i>“Modern websites that give your brand a digital home.”</i></font><br/>Motion-rich digital sanctuaries, mobile-first UX, speed optimization & checkout flows.", body_style)
        ]
    ]

    services_table = Table(services_rows, colWidths=[255, 255])
    services_table.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 1.5, DARK),
        ('INNERGRID', (0, 0), (-1, -1), 1, colors.HexColor('#E5E5E8')),
        ('BACKGROUND', (0, 0), (0, 0), colors.white),
        ('BACKGROUND', (1, 0), (1, 0), colors.HexColor('#FEF9C3')),
        ('BACKGROUND', (0, 1), (0, 1), GREEN_SOFT),
        ('BACKGROUND', (1, 1), (1, 1), PURPLE_SOFT),
        ('BACKGROUND', (0, 2), (0, 2), PINK_SOFT),
        ('BACKGROUND', (1, 2), (1, 2), colors.HexColor('#EFF6FF')),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
    ]))
    story.append(services_table)
    story.append(Spacer(1, 15))

    # Generic Agency vs Social Studio comparison
    vs_table = Table([
        [
            Paragraph("<b>THE GENERIC AGENCY WAY:</b><br/>• Recycled Canva templates<br/>• Robotic ChatGPT captions with 30 hashtags<br/>• Outsourced to junior interns<br/>• Posting randomly with no strategy", ParagraphStyle('R', parent=body_style, textColor=colors.HexColor('#991B1B'))),
            Paragraph("<b>THE SOCIAL STUDIO WAY:</b><br/>• 100% bespoke creative direction<br/>• Witty, human storytelling that converts<br/>• Direct collaboration with founder Mansi<br/>• Strategic 4-pillar growth calendars", ParagraphStyle('G', parent=body_style, textColor=colors.HexColor('#065F46')))
        ]
    ], colWidths=[255, 255])
    vs_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, 0), colors.HexColor('#FEF2F2')),
        ('BACKGROUND', (1, 0), (1, 0), GREEN_SOFT),
        ('BOX', (0, 0), (-1, -1), 1, DARK),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
    ]))
    story.append(vs_table)
    story.append(PageBreak())

    # ==========================================
    # PAGE 4: PORTFOLIO SHOWCASE
    # ==========================================
    story.append(Paragraph("THINGS WE’VE MADE ♡", h1_style))
    story.append(Paragraph("Editorial highlights from client retainers and studio creative campaigns:", body_style))
    story.append(Spacer(1, 10))

    # Project 1: Social Media & Reels
    if os.path.exists(reels_img_path):
        p1_img = RLImage(reels_img_path, width=2.4*inch, height=1.7*inch)
    else:
        p1_img = Paragraph("Reels Preview", body_style)

    p1_desc = """
    <b>01. VIRAL REELS & COMMUNITY ENGINE</b><br/>
    <font color='#FF2A7A'><b>Category: SOCIAL MEDIA | Result: +3.8M Views • 95K Shares</b></font><br/>
    Short-form video takeover engineered for 3-second thumb stopping power. Audio curation, dynamic typography hooks, and aesthetic sticker annotations.
    """

    p1_table = Table([[p1_img, Paragraph(p1_desc, body_style)]], colWidths=[2.5*inch, 4.3*inch])
    p1_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BOX', (0, 0), (-1, -1), 1, DARK),
        ('BACKGROUND', (0, 0), (-1, -1), colors.white),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(p1_table)
    story.append(Spacer(1, 12))

    # Project 2: Carousels & Content
    if os.path.exists(carousel_img_path):
        p2_img = RLImage(carousel_img_path, width=2.4*inch, height=1.7*inch)
    else:
        p2_img = Paragraph("Carousel Preview", body_style)

    p2_desc = """
    <b>02. EDITORIAL EDUCATIONAL CAROUSELS</b><br/>
    <font color='#FF2A7A'><b>Category: CONTENT | Result: 14.2K Saves • 4.6x Reach Lift</b></font><br/>
    Multi-slide swipeable educational carousel series breaking down complex topics into bite-sized visual notes with signature scrapbook doodles and washi tape aesthetics.
    """

    p2_table = Table([[p2_img, Paragraph(p2_desc, body_style)]], colWidths=[2.5*inch, 4.3*inch])
    p2_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BOX', (0, 0), (-1, -1), 1, DARK),
        ('BACKGROUND', (0, 0), (-1, -1), colors.white),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(p2_table)
    story.append(Spacer(1, 12))

    # Project 3 & 4 Mini Table
    if os.path.exists(cafe_img_path):
        cafe_img = RLImage(cafe_img_path, width=2.3*inch, height=1.5*inch)
    else:
        cafe_img = Paragraph("Branding", body_style)

    if os.path.exists(skincare_img_path):
        skincare_img = RLImage(skincare_img_path, width=2.3*inch, height=1.5*inch)
    else:
        skincare_img = Paragraph("Campaign", body_style)

    p34_table = Table([
        [cafe_img, skincare_img],
        [
            Paragraph("<b>BLOOM SPECIALTY CAFÉ</b><br/><font color='#FF2A7A'>Branding & Packaging Suite</font>", body_style),
            Paragraph("<b>GLOWLAB BEAUTY CAMPAIGN</b><br/><font color='#FF2A7A'>3.8x ROAS • Sold Out in 48hrs</font>", body_style)
        ]
    ], colWidths=[255, 255])
    p34_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#E5E5E8')),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(p34_table)
    story.append(PageBreak())

    # ==========================================
    # PAGE 5: PROCESS & PACKAGES
    # ==========================================
    story.append(Paragraph("HOW WE MAKE IT HAPPEN", h1_style))
    story.append(Paragraph("Our structured 6-stage workflow ensuring creative momentum without delays:", body_style))
    story.append(Spacer(1, 10))

    process_data = [
        [
            Paragraph("<b>01. DISCOVER</b><br/>Unearthing true brand DNA, audience cravings & whitespace.", body_style),
            Paragraph("<b>02. PLAN</b><br/>Strategic monthly content blueprint, calendar & audio spotlights.", body_style),
            Paragraph("<b>03. CREATE</b><br/>Editing timeline magic: high-retention cuts, sound & covers.", body_style),
        ],
        [
            Paragraph("<b>04. POST</b><br/>Optimized scheduling times & first-hour engagement tactics.", body_style),
            Paragraph("<b>05. ANALYZE</b><br/>Retention curves, share velocity & monthly ROI insights.", body_style),
            Paragraph("<b>06. GROW</b><br/>Scaling momentum into loyal, obsessed brand communities.", body_style),
        ]
    ]
    process_table = Table(process_data, colWidths=[170, 170, 170])
    process_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.white),
        ('BOX', (0, 0), (-1, -1), 1.5, DARK),
        ('INNERGRID', (0, 0), (-1, -1), 1, colors.HexColor('#E5E5E8')),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(process_table)
    story.append(Spacer(1, 20))

    story.append(Paragraph("MONTHLY PARTNERSHIP PACKAGES", h1_style))

    packages_data = [
        [
            Paragraph("<b>STARTER</b><br/><font color='#FF2A7A' size='14'><b>₹8,500/mo</b></font><br/><i>Best for emerging brands</i>", body_style),
            Paragraph("<b>GROWTH (POPULAR ♡)</b><br/><font color='#FF2A7A' size='14'><b>₹14,500/mo</b></font><br/><i>For brands wanting viral scale</i>", body_style),
            Paragraph("<b>PREMIUM TAKEOVER</b><br/><font color='#FF2A7A' size='14'><b>₹25,000/mo</b></font><br/><i>Full studio digital takeover</i>", body_style)
        ],
        [
            Paragraph("• 10-12 Static Posts<br/>• 8 Aesthetic Reels / Shorts<br/>• 10 Story Sequences<br/>• Monthly Blueprint Calendar<br/>• 1 Revision Round", body_style),
            Paragraph("• 15 Static Posts<br/>• 10 Viral Reels / Shorts<br/>• 12 Story Sequences<br/>• Community Engagement<br/>• Trend & Audio Research<br/>• 2 Revision Rounds", body_style),
            Paragraph("• 18-20 Static Posts<br/>• 15 Viral Reels / Shorts<br/>• 20 Story Sequences<br/>• Full DM & Community Mgmt<br/>• 1-on-1 Monthly Strategy Call<br/>• Priority Creative Turnaround", body_style)
        ]
    ]
    pkg_table = Table(packages_data, colWidths=[170, 170, 170])
    pkg_table.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 2, DARK),
        ('INNERGRID', (0, 0), (-1, -1), 1, colors.HexColor('#E5E5E8')),
        ('BACKGROUND', (0, 0), (0, 0), colors.white),
        ('BACKGROUND', (1, 0), (1, 0), PINK_SOFT),
        ('BACKGROUND', (2, 0), (2, 0), colors.white),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
    ]))
    story.append(pkg_table)
    story.append(PageBreak())

    # ==========================================
    # PAGE 6: FINAL CTA & CONTACT
    # ==========================================
    story.append(Spacer(1, 30))
    cta_box = Table([
        [
            Paragraph(
                "<font size='26' color='#141416'><b>READY TO GROW YOUR BRAND?</b></font><br/><br/>"
                "<font size='14' color='#FF2A7A'><b>Let’s turn your ideas into content people actually want to see.</b></font><br/><br/>"
                "<font size='10' color='#55555C'>Average response time: &lt; 24 hours • Free 20-min creative discovery call included ♡</font>",
                ParagraphStyle('CTA', alignment=TA_CENTER, leading=28)
            )
        ]
    ], colWidths=[520])
    cta_box.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), PINK_SOFT),
        ('BOX', (0, 0), (-1, -1), 2, PINK),
        ('TOPPADDING', (0, 0), (-1, -1), 25),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 25),
        ('LEFTPADDING', (0, 0), (-1, -1), 20),
        ('RIGHTPADDING', (0, 0), (-1, -1), 20),
    ]))
    story.append(cta_box)
    story.append(Spacer(1, 30))

    contact_info = [
        [
            Paragraph("<b>DIRECT EMAIL:</b><br/>hello@socialstudio.design", body_style),
            Paragraph("<b>INSTAGRAM:</b><br/>@socialstudio.creative", body_style),
            Paragraph("<b>LOCATION:</b><br/>Based in India • Scaling Worldwide 🌍", body_style)
        ]
    ]
    contact_table = Table(contact_info, colWidths=[170, 170, 170])
    contact_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.white),
        ('BOX', (0, 0), (-1, -1), 1.5, DARK),
        ('INNERGRID', (0, 0), (-1, -1), 1, colors.HexColor('#E5E5E8')),
        ('TOPPADDING', (0, 0), (-1, -1), 14),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 14),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
    ]))
    story.append(contact_table)

    story.append(Spacer(1, 40))
    story.append(Paragraph(
        "© 2026 Social Studio ♡. All rights reserved. Designed & directed by Mansi.",
        ParagraphStyle('Foot', parent=body_style, alignment=TA_CENTER, textColor=GRAY_TEXT, fontSize=9)
    ))

    # Build the PDF
    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"Successfully generated: {output_path}")

if __name__ == '__main__':
    project_root = r"C:\Users\Admin\.gemini\antigravity-ide\scratch\social-studio"
    desktop_folder = r"C:\Users\Admin\OneDrive\Desktop\Social-Studio"
    desktop_root = r"C:\Users\Admin\OneDrive\Desktop"

    out1 = os.path.join(project_root, "Social-Studio-Portfolio.pdf")
    build_pdf(out1, project_root)

    # Also copy to Desktop and Desktop/Social-Studio
    import shutil
    out2 = os.path.join(desktop_folder, "Social-Studio-Portfolio.pdf")
    out3 = os.path.join(desktop_root, "Social-Studio-Portfolio.pdf")

    shutil.copyfile(out1, out2)
    shutil.copyfile(out1, out3)
    print(f"Copied to: {out2}")
    print(f"Copied to: {out3}")
