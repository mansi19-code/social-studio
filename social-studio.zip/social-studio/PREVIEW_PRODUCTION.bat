@echo off
title Social Studio - Production Preview
echo ========================================================
echo        SOCIAL STUDIO - PRODUCTION BUILD PREVIEW
echo ========================================================
echo.
echo Launching production preview server...
echo Your browser will open automatically at http://localhost:4173
echo.
start http://localhost:4173
npm run preview
pause
