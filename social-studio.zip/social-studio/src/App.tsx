import React, { useState } from 'react';
import { CustomCursor } from './components/CustomCursor';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Founder } from './components/Founder';
import { Services } from './components/Services';
import { Marquee } from './components/Marquee';
import { CreativeDesk } from './components/CreativeDesk';
import { Portfolio } from './components/Portfolio';
import { Process } from './components/Process';
import { Philosophy } from './components/Philosophy';
import { WhyUs } from './components/WhyUs';
import { Packages } from './components/Packages';
import { CTA } from './components/CTA';
import { Footer } from './components/Footer';
import { ContactModal } from './components/ContactModal';

export function App() {
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [preselectedPkg, setPreselectedPkg] = useState<string>('');

  const handleOpenContact = (pkgName?: string) => {
    if (pkgName) {
      setPreselectedPkg(pkgName);
    }
    setContactModalOpen(true);
  };

  const handleCloseContact = () => {
    setContactModalOpen(false);
    setPreselectedPkg('');
  };

  return (
    <div className="relative min-h-screen bg-studio-cream text-studio-dark font-sans overflow-x-hidden selection:bg-studio-pink selection:text-white">
      {/* Editorial Analog Paper Grain Texture */}
      <div className="paper-grain" />

      {/* Desktop Custom Cursor */}
      <CustomCursor />

      {/* Floating Glass Navbar */}
      <Navbar onOpenContact={() => handleOpenContact()} />

      {/* Main Content Sections */}
      <main>
        {/* 1. Hero Section */}
        <Hero onOpenContact={() => handleOpenContact()} />

        {/* 2. Top Marquee ticker */}
        <Marquee bg="bg-studio-pink" textColor="text-white" borderColor="border-studio-dark" />

        {/* 3. Founder / Meet Mansi Section with Voice Player */}
        <Founder />

        {/* 4. What We Do / Services Bento Grid */}
        <Services />

        {/* 5. Creative Desk (Interactive Parallax Setup) */}
        <CreativeDesk />

        {/* 6. Mid-page Alternating Marquee ticker */}
        <Marquee reverse bg="bg-studio-yellow" textColor="text-studio-dark" borderColor="border-studio-dark" />

        {/* 7. Things We've Made / Portfolio */}
        <Portfolio onOpenContact={() => handleOpenContact()} />

        {/* 8. Process Timeline */}
        <Process />

        {/* 9. Brand Philosophy Typography Reveal */}
        <Philosophy />

        {/* 10. Why Social Studio Cards */}
        <WhyUs />

        {/* 11. Monthly Packages / Retainers */}
        <Packages onSelectPackage={(pkg) => handleOpenContact(pkg)} />

        {/* 12. Final Call To Action */}
        <CTA onOpenContact={() => handleOpenContact()} />
      </main>

      {/* Scrapbook Footer */}
      <Footer />

      {/* Interactive Contact & Package Booking Modal */}
      <ContactModal
        isOpen={contactModalOpen}
        onClose={handleCloseContact}
        preselectedPackage={preselectedPkg}
      />
    </div>
  );
}

export default App;
