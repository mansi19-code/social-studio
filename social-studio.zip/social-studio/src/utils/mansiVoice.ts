// Intelligent Web Speech API controller for Mansi's Voice Introduction
// Follows user requirements: warm, youthful, natural tone with precise script pacing

export interface ScriptParagraph {
  id: number;
  display: string;
  speech: string;
  rate: number;
  pitch: number;
  pauseAfterMs: number;
  vibe: string;
}

export const MANSI_SCRIPT: ScriptParagraph[] = [
  {
    id: 1,
    display: "“Hey, I’m Mansi, the founder of Social Studio.” ♡",
    speech: "Hey, I’m Mansi, the founder of Social Studio.",
    rate: 0.96,
    pitch: 1.14,
    pauseAfterMs: 440,
    vibe: "Warm & Welcoming"
  },
  {
    id: 2,
    display: "“I love turning ideas into content that looks good, communicates clearly and actually connects with people.”",
    speech: "I love turning ideas into content that looks good, communicates clearly and actually connects with people.",
    rate: 0.94,
    pitch: 1.12,
    pauseAfterMs: 460,
    vibe: "Creative & Intentional"
  },
  {
    id: 3,
    display: "“From social media and graphic design to content creation, strategy and websites, Social Studio is all about helping brands show up online with confidence.”",
    speech: "From social media and graphic design to content creation, strategy and websites, Social Studio is all about helping brands show up online with confidence.",
    rate: 0.95,
    pitch: 1.10,
    pauseAfterMs: 480,
    vibe: "Empowering & Strategic"
  },
  {
    id: 4,
    display: "“If you have an idea, let’s turn it into something people remember.” ♡",
    speech: "If you have an idea, let’s turn it into something people remember.",
    rate: 0.92,
    pitch: 1.13,
    pauseAfterMs: 400,
    vibe: "Inspiring Invitation"
  }
];

export type VoiceState = 'idle' | 'speaking' | 'paused' | 'finished';

export interface VoiceListener {
  onStateChange?: (state: VoiceState) => void;
  onParagraphChange?: (index: number) => void;
  onVoiceLoaded?: (voice: SpeechSynthesisVoice | null) => void;
}

class MansiVoiceController {
  private state: VoiceState = 'idle';
  private currentParaIndex: number = 0;
  private selectedVoice: SpeechSynthesisVoice | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private pauseTimer: ReturnType<typeof setTimeout> | null = null;
  private listeners: Set<VoiceListener> = new Set();
  private isBrowserSupported: boolean = false;
  private isInternalStopping: boolean = false;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.isBrowserSupported = true;
      this.initVoices();
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = () => this.initVoices();
      }
    }
  }

  public isSupported(): boolean {
    return this.isBrowserSupported;
  }

  public getState(): VoiceState {
    return this.state;
  }

  public getCurrentParagraphIndex(): number {
    return this.currentParaIndex;
  }

  public getSelectedVoice(): SpeechSynthesisVoice | null {
    return this.selectedVoice;
  }

  public subscribe(listener: VoiceListener): () => void {
    this.listeners.add(listener);
    if (listener.onStateChange) listener.onStateChange(this.state);
    if (listener.onParagraphChange) listener.onParagraphChange(this.currentParaIndex);
    if (listener.onVoiceLoaded) listener.onVoiceLoaded(this.selectedVoice);

    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyState(newState: VoiceState) {
    this.state = newState;
    this.listeners.forEach((l) => l.onStateChange?.(newState));
  }

  private notifyParagraph(index: number) {
    this.currentParaIndex = index;
    this.listeners.forEach((l) => l.onParagraphChange?.(index));
  }

  private notifyVoice(voice: SpeechSynthesisVoice | null) {
    this.selectedVoice = voice;
    this.listeners.forEach((l) => l.onVoiceLoaded?.(voice));
  }

  public initVoices() {
    if (!this.isBrowserSupported) return;
    const voices = window.speechSynthesis.getVoices();
    if (!voices || voices.length === 0) return;

    const scoreVoice = (v: SpeechSynthesisVoice): number => {
      let score = 0;
      const name = v.name.toLowerCase();
      const lang = (v.lang || '').toLowerCase().replace('_', '-');
      const isEnglish = lang.startsWith('en');

      const isMale = /male|david|george|mark|richard|james|rishi|guy|stefan|daniel|thomas|fred|oliver|arthur|bernard|microsoft ravi/i.test(name);
      if (isMale) return -100;

      const isFemale = /female|woman|girl|zira|jenny|aria|samantha|karen|victoria|neerja|heera|veena|ananya|kavya|fiona|moira|hazel|susan/i.test(name);

      const isIndianLang = lang === 'en-in' || lang.startsWith('en-in') || /india/i.test(name);
      if (isIndianLang) {
        if (isFemale || /neerja|heera|veena|ananya|kavya/i.test(name)) {
          score += 1000;
          if (/natural|online/i.test(name)) score += 100;
        } else {
          score += 850;
        }
      }

      if (!isEnglish && !isIndianLang) return -50;

      if (/microsoft neerja/i.test(name)) score += 950;
      else if (/microsoft heera/i.test(name)) score += 920;
      else if (/microsoft jenny/i.test(name)) score += 880;
      else if (/microsoft aria/i.test(name)) score += 870;
      else if (/google uk english female/i.test(name)) score += 860;
      else if (/google us english/i.test(name) && !isMale) score += 830;
      else if (/samantha/i.test(name)) score += 820;
      else if (/karen/i.test(name)) score += 810;
      else if (/microsoft zira/i.test(name)) score += 780;
      else if (/victoria/i.test(name)) score += 770;

      if (/natural|neural|premium|enhanced/i.test(name)) score += 150;
      if (isFemale) score += 100;
      if (isEnglish) score += 50;

      return score;
    };

    const sorted = [...voices].sort((a, b) => scoreVoice(b) - scoreVoice(a));
    const best = sorted[0] || null;
    this.notifyVoice(best);
  }

  public speakIntroduction(startIndex: number = 0) {
    if (!this.isBrowserSupported) return;

    this.stopIntroductionInternal();

    if (!this.selectedVoice) {
      this.initVoices();
    }

    this.currentParaIndex = Math.max(0, Math.min(startIndex, MANSI_SCRIPT.length - 1));
    this.notifyParagraph(this.currentParaIndex);
    this.notifyState('speaking');

    this.speakCurrentParagraph();
  }

  private speakCurrentParagraph() {
    if (!this.isBrowserSupported || this.state !== 'speaking') return;

    if (this.currentParaIndex >= MANSI_SCRIPT.length) {
      this.notifyState('finished');
      this.notifyParagraph(-1);
      return;
    }

    const para = MANSI_SCRIPT[this.currentParaIndex];
    const utterance = new SpeechSynthesisUtterance(para.speech);

    if (this.selectedVoice) {
      utterance.voice = this.selectedVoice;
    }

    utterance.rate = para.rate;
    utterance.pitch = para.pitch;
    utterance.volume = 1.0;

    utterance.onend = () => {
      if (this.isInternalStopping || this.state !== 'speaking') return;

      const nextIndex = this.currentParaIndex + 1;
      if (nextIndex < MANSI_SCRIPT.length) {
        this.pauseTimer = setTimeout(() => {
          if (this.state === 'speaking') {
            this.currentParaIndex = nextIndex;
            this.notifyParagraph(nextIndex);
            this.speakCurrentParagraph();
          }
        }, para.pauseAfterMs);
      } else {
        this.notifyState('finished');
        this.notifyParagraph(-1);
      }
    };

    utterance.onerror = (e) => {
      if (e.error === 'canceled' || e.error === 'interrupted') return;
      console.warn('Speech synthesis warning:', e);
      this.notifyState('idle');
      this.notifyParagraph(-1);
    };

    this.currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  public pauseIntroduction() {
    if (!this.isBrowserSupported) return;
    if (this.state !== 'speaking') return;

    if (this.pauseTimer) {
      clearTimeout(this.pauseTimer);
      this.pauseTimer = null;
    }

    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
    }
    this.notifyState('paused');
  }

  public resumeIntroduction() {
    if (!this.isBrowserSupported) return;
    if (this.state !== 'paused') return;

    this.notifyState('speaking');

    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      setTimeout(() => {
        if (this.state === 'speaking' && !window.speechSynthesis.speaking) {
          window.speechSynthesis.cancel();
          this.speakCurrentParagraph();
        }
      }, 150);
    } else {
      this.speakCurrentParagraph();
    }
  }

  public stopIntroduction() {
    this.stopIntroductionInternal();
    this.notifyState('idle');
    this.notifyParagraph(-1);
  }

  private stopIntroductionInternal() {
    this.isInternalStopping = true;
    if (this.pauseTimer) {
      clearTimeout(this.pauseTimer);
      this.pauseTimer = null;
    }

    if (this.isBrowserSupported && typeof window !== 'undefined') {
      window.speechSynthesis.cancel();
    }
    this.currentUtterance = null;
    this.isInternalStopping = false;
  }
}

export const mansiVoice = new MansiVoiceController();

export const speakIntroduction = () => mansiVoice.speakIntroduction(0);
export const stopIntroduction = () => mansiVoice.stopIntroduction();
export const pauseIntroduction = () => mansiVoice.pauseIntroduction();
export const resumeIntroduction = () => mansiVoice.resumeIntroduction();
