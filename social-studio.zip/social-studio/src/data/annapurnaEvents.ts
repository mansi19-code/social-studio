/**
 * ANNAPURNA EVENTS — CLIENT CASE STUDY & GALLERY CONFIGURATION
 * 
 * Client: Annapurna Events
 * Studio: Social Studio
 * Project Type: Social Media & Creative Design
 * Visual Direction: Champagne Luxury
 * 
 * ------------------------------------------------------------------------
 * HOW TO ADD / REMOVE / REORDER YOUR ACTUAL WORK:
 * ------------------------------------------------------------------------
 * 1. Drop your images (.jpg, .png, .webp) or videos (.mp4) into:
 *    /public/portfolio/annapurna-events/
 * 
 * 2. Add or edit entries in the `annapurnaMediaItems` array below.
 *    - To add an image:
 *      {
 *        id: 'img-1',
 *        title: 'Wedding Welcome Board Creative',
 *        category: 'Instagram Posts',
 *        src: '/portfolio/annapurna-events/wedding-post.jpg',
 *        type: 'image',
 *        caption: 'Champagne luxury typography with floral framing'
 *      }
 *    - To add a video/reel:
 *      {
 *        id: 'vid-1',
 *        title: 'Royal Mandap Stage Reveal',
 *        category: 'Reels & Videos',
 *        src: '/portfolio/annapurna-events/mandap-reel.mp4',
 *        type: 'video',
 *        caption: 'Behind-the-scenes event decor production reel'
 *      }
 * 
 * 3. Reorder by simply moving the objects up or down in the array.
 * ------------------------------------------------------------------------
 */

export type AnnapurnaMediaCategory =
  | 'ALL'
  | 'Instagram Posts'
  | 'Festive Creatives'
  | 'Promotional Posters'
  | 'Campaign Designs'
  | 'Carousel Designs'
  | 'Stories'
  | 'Reels & Videos';

export interface AnnapurnaMediaItem {
  id: string;
  title: string;
  category: Exclude<AnnapurnaMediaCategory, 'ALL'>;
  src: string;
  type: 'image' | 'video';
  caption?: string;
  badge?: string;
}

export interface AnnapurnaCaseStudyData {
  title: string;
  client: string;
  studio: string;
  projectType: string;
  visualDirection: string;
  clientLabel: string;
  category: string;
  coverImage: string;
  description: string;
  overview: {
    badge: string;
    headline: string;
    introduction: string;
    detail: string;
    pillars: {
      title: string;
      description: string;
      icon: string;
    }[];
  };
  contributions: {
    id: string;
    title: string;
    description: string;
    tag: string;
  }[];
  creativeDirection: {
    theme: string;
    subtitle: string;
    description: string;
    principles: {
      title: string;
      description: string;
    }[];
    palette: {
      name: string;
      hex: string;
      role: string;
      border?: boolean;
    }[];
  };
}

export const annapurnaCaseStudyData: AnnapurnaCaseStudyData = {
  title: 'Annapurna Events',
  client: 'Annapurna Events',
  studio: 'Social Studio',
  projectType: 'Social Media & Creative Design',
  visualDirection: 'Champagne Luxury',
  clientLabel: 'Client Work',
  category: 'Event Management',
  coverImage: '/portfolio/annapurna-events/cover.jpg',
  description:
    'Creating engaging digital experiences for an event management brand through creative social media content, festive campaigns and premium visual storytelling.',
  overview: {
    badge: 'ABOUT THE BRAND',
    headline: 'Elevating Grand Celebrations to Digital Elegance',
    introduction:
      'Annapurna Events is a distinguished event management brand celebrated for orchestrating grand weddings, milestone celebrations, bespoke stage and floral decor, and high-impact corporate events.',
    detail:
      'Operating at the intersection of lavish hospitality, grand stagecraft, and unforgettable guest experiences, Social Studio partnered with Annapurna Events to create an elevated digital brand presence worthy of the grandeur they deliver offline.',
    pillars: [
      {
        title: 'Luxury Weddings',
        description: 'Bespoke ceremonies, grand stage setups, and unforgettable bridal moments.',
        icon: 'Crown',
      },
      {
        title: 'Milestone Celebrations',
        description: 'Private anniversaries, intimate galas, and festive family occasions.',
        icon: 'Sparkles',
      },
      {
        title: 'Bespoke Stage & Decor',
        description: 'Artisanal floral architecture, thematic lighting, and opulent backdrops.',
        icon: 'Palette',
      },
      {
        title: 'Corporate Events',
        description: 'Seamless award ceremonies, corporate summits, and executive gatherings.',
        icon: 'Building2',
      },
    ],
  },
  contributions: [
    {
      id: 'social-creative',
      title: 'Social Media Creative Design',
      description:
        'Crafting high-impact editorial feed posts, highlight covers, and grid architecture aligned with a luxury celebratory aesthetic.',
      tag: 'Feed & Grid Curation',
    },
    {
      id: 'festive-campaigns',
      title: 'Festive Campaign Creatives',
      description:
        'Developing bespoke seasonal campaign series for Diwali, New Year, and wedding season celebrations that blend cultural warmth with modern polish.',
      tag: 'Seasonal Series',
    },
    {
      id: 'event-promotions',
      title: 'Event Promotional Posts',
      description:
        'Designing announcement flyers, date-reservation teasers, behind-the-scenes showcases, and client inquiry drivers.',
      tag: 'Promotions & Teasers',
    },
    {
      id: 'instagram-planning',
      title: 'Instagram Content Planning',
      description:
        'Structuring monthly content calendars, theme sequencing, story flows, and strategic visual pacing to keep audiences engaged.',
      tag: 'Content Architecture',
    },
    {
      id: 'brand-communication',
      title: 'Brand Communication',
      description:
        'Refining brand messaging, celebratory copy tone, and audience-first communication that conveys warmth, trust, and luxury hospitality.',
      tag: 'Tone of Voice',
    },
    {
      id: 'visual-storytelling',
      title: 'Visual Storytelling',
      description:
        'Translating fleeting event moments, intricate decor details, and celebration highlights into immersive, scroll-stopping visual narratives.',
      tag: 'Story & Narrative',
    },
  ],
  creativeDirection: {
    theme: 'Champagne Luxury',
    subtitle: 'Warmth • Refinement • Timeless Grandeur',
    description:
      'The Champagne Luxury visual direction was curated specifically for Annapurna Events to reflect the warmth of traditional celebrations through an understated, contemporary high-end aesthetic.',
    principles: [
      {
        title: 'Elegant Visual Compositions',
        description:
          'Generous breathing room, refined borders, and thoughtful focal points that place celebration craftsmanship in the spotlight.',
      },
      {
        title: 'Premium Typography',
        description:
          'High-contrast editorial serif headers paired with clean architectural sans-serif subtexts for an unmistakably upscale aesthetic.',
      },
      {
        title: 'Luxury-Inspired Layouts',
        description:
          'Sophisticated magazine-style editorial frames, subtle gilded accents, and balanced asymmetrical collage arrangements.',
      },
      {
        title: 'Festive Campaign Styling',
        description:
          'Warm golden lighting, delicate floral embellishments, and contemporary cultural detailing without visual clutter.',
      },
      {
        title: 'Consistent Visual Identity',
        description:
          'A unified creative language across every post, story, reel thumbnail, poster, and digital brand touchpoint.',
      },
    ],
    palette: [
      {
        name: 'Champagne Gold',
        hex: '#E5C378',
        role: 'Primary luxury accent & celebratory highlights',
      },
      {
        name: 'Warm Ivory Paper',
        hex: '#FAF6EE',
        role: 'Studio cream background & tactile canvas',
        border: true,
      },
      {
        name: 'Editorial Noir',
        hex: '#141416',
        role: 'High-contrast typography & structural frames',
      },
      {
        name: 'Celebratory Rose Blush',
        hex: '#FFB8D2',
        role: 'Social Studio warmth & romantic accent',
      },
      {
        name: 'Imperial Pearl',
        hex: '#FFFDF9',
        role: 'Luminous highlights & card surfaces',
        border: true,
      },
    ],
  },
};

/**
 * ACTUAL UPLOADED MEDIA ASSETS
 * 
 * Add your real uploaded files from `/public/portfolio/annapurna-events/` here.
 * If empty, the portfolio displays a clean, on-brand editable placeholder frame
 * rather than fabricated or AI-generated work.
 */
export const annapurnaMediaItems: AnnapurnaMediaItem[] = [
  // Examples to uncomment or replace with your actual files:
  /*
  {
    id: 'annapurna-post-1',
    title: 'Luxury Wedding Stage Design',
    category: 'Instagram Posts',
    src: '/portfolio/annapurna-events/wedding-stage.jpg',
    type: 'image',
    caption: 'Champagne Luxury stage decor design creative for Instagram feed',
  },
  {
    id: 'annapurna-festive-1',
    title: 'Diwali Celebration Campaign',
    category: 'Festive Creatives',
    src: '/portfolio/annapurna-events/festive-diwali.jpg',
    type: 'image',
    caption: 'Bespoke festive greeting and wedding season booking announcement',
  },
  {
    id: 'annapurna-poster-1',
    title: 'Royal Mandapam Showcase',
    category: 'Promotional Posters',
    src: '/portfolio/annapurna-events/royal-mandapam.jpg',
    type: 'image',
    caption: 'Promotional poster spotlighting handcrafted floral architecture',
  },
  {
    id: 'annapurna-carousel-1',
    title: '5 Steps to a Flawless Wedding',
    category: 'Carousel Designs',
    src: '/portfolio/annapurna-events/wedding-carousel-cover.jpg',
    type: 'image',
    caption: 'Educational carousel slide series for event planning clients',
  },
  {
    id: 'annapurna-story-1',
    title: 'Behind the Scenes: Decor Setup',
    category: 'Stories',
    src: '/portfolio/annapurna-events/story-decor-bts.jpg',
    type: 'image',
    caption: 'Interactive Instagram Story countdown creative',
  },
  {
    id: 'annapurna-reel-1',
    title: 'Grand Entrance & Night Ambiance',
    category: 'Reels & Videos',
    src: '/portfolio/annapurna-events/grand-entrance.mp4',
    type: 'video',
    caption: 'Short-form cinematic video reel highlighting lighting design',
  },
  */
];
