/**
 * SOCIAL STUDIO — PORTFOLIO DATA FILE
 * Highly curated, aesthetic showcase across all studio disciplines:
 * - EVENT MANAGEMENT (Client Work)
 * - SOCIAL MEDIA
 * - CONTENT
 * - BRANDING
 * - CAMPAIGNS
 * - WEB DESIGN
 */

export type ProjectCategory =
  | 'ALL'
  | 'EVENT MANAGEMENT'
  | 'SOCIAL MEDIA'
  | 'CONTENT'
  | 'BRANDING'
  | 'CAMPAIGNS'
  | 'WEB DESIGN';

export interface Project {
  id: string;
  title: string;
  client?: string;
  category: Exclude<ProjectCategory, 'ALL'>;
  additionalCategories?: Exclude<ProjectCategory, 'ALL'>[];
  description: string;
  services: string[];
  coverImage?: string;
  gallery?: string[];
  video?: string;
  date?: string;
  result?: string;
  link?: string;
  featured?: boolean;
  badge?: string;
  visualDirection?: string;
  projectType?: string;
}

export const CATEGORIES: readonly ProjectCategory[] = [
  'ALL',
  'EVENT MANAGEMENT',
  'SOCIAL MEDIA',
  'CONTENT',
  'BRANDING',
  'CAMPAIGNS',
  'WEB DESIGN',
] as const;

export const projects: Project[] = [
  {
    id: 'annapurna-events',
    title: 'Annapurna Events',
    client: 'Client Work',
    category: 'EVENT MANAGEMENT',
    additionalCategories: ['SOCIAL MEDIA', 'CAMPAIGNS'],
    description: 'Creating engaging digital experiences for an event management brand through creative social media content, festive campaigns and premium visual storytelling.',
    services: [
      'Social Media Creative Design',
      'Festive Campaign Creatives',
      'Event Promotional Posts',
      'Instagram Content Planning',
      'Brand Communication',
      'Visual Storytelling',
    ],
    coverImage: '/portfolio/annapurna-events/cover.jpg',
    gallery: [],
    date: '2026',
    result: 'Champagne Luxury Direction',
    badge: 'Client Work',
    visualDirection: 'Champagne Luxury',
    projectType: 'Social Media & Creative Design',
    link: '#',
    featured: true,
  },
  {
    id: 'viral-reels-growth',
    title: 'Viral Reels & Community Engine',
    client: 'Luna Creates / Lifestyle & Fashion',
    category: 'SOCIAL MEDIA',
    description: 'A complete short-form video takeover engineered for 3-second thumb stopping power. We orchestrated trending audio curation, rapid dynamic text hooks, and aesthetic on-screen sticker annotations resulting in millions of organic views.',
    services: ['Reels / Shorts Direction', 'Viral Hook Architecture', 'Audio Syncing', 'Story Sequences'],
    coverImage: '/portfolio/portfolio_social_reels.jpg',
    gallery: ['/portfolio/portfolio_social_reels.jpg'],
    date: '2026',
    result: '+3.8M Views • 95K Shares',
    link: '#',
    featured: true,
  },
  {
    id: 'high-retention-carousels',
    title: 'Editorial Educational Carousels',
    client: 'The Creator Growth Hub',
    category: 'CONTENT',
    description: 'Multi-slide swipeable educational carousel series breaking down complex digital marketing frameworks into delicious, bite-sized visual notes with signature scrapbook doodles, high-contrast typography, and washi tape aesthetics.',
    services: ['Content Creation', 'Carousel Architecture', 'Copywriting & Hooks', 'Infographic Design'],
    coverImage: '/portfolio/portfolio_carousel_content.jpg',
    gallery: ['/portfolio/portfolio_carousel_content.jpg'],
    date: '2026',
    result: '14.2K Saves • 4.6x Reach',
    link: '#',
    featured: true,
  },
  {
    id: 'bloom-cafe-branding',
    title: 'Bloom Artisan Café & Roasters',
    client: 'Bloom Coffee Co.',
    category: 'BRANDING',
    description: 'Complete brand universe overhaul for an indie aesthetic café: custom hand-drawn cup stickers, pastel menu hierarchy, Instagram grid identity, bespoke typography, and physical packaging tape that makes every cup Instagrammable.',
    services: ['Brand Identity', 'Sticker Design', 'Packaging Suite', 'Menu Typography'],
    coverImage: '/portfolio/portfolio_branding_cafe.jpg',
    gallery: ['/portfolio/portfolio_branding_cafe.jpg'],
    date: '2026',
    result: 'Full Visual Identity & Packaging',
    link: '#',
    featured: true,
  },
  {
    id: 'glowlab-skincare-launch',
    title: 'GlowLab Dewy Skin Campaign',
    client: 'GlowLab Clean Beauty',
    category: 'CAMPAIGNS',
    description: 'Multi-channel product launch campaign combining organic UGC hooks, aesthetic texture B-roll, and high-converting paid social ad creatives with soft pastel aesthetics that generated record return on ad spend.',
    services: ['Campaign Strategy', 'UGC Art Direction', 'Paid Meta Creatives', 'Launch Sequence'],
    coverImage: '/portfolio/portfolio_campaign_skincare.jpg',
    gallery: ['/portfolio/portfolio_campaign_skincare.jpg'],
    date: '2026',
    result: '3.8x ROAS • Sold Out in 48hrs',
    link: '#',
    featured: true,
  },
  {
    id: 'creator-academy-platform',
    title: 'The Creator Academy Sanctuary',
    client: 'Creator Academy Global',
    category: 'WEB DESIGN',
    description: 'High-speed, motion-rich digital home crafted like an interactive digital scrapbook. Features fluid micro-interactions, responsive creator workspace, bespoke sticker treatments, and high-converting enrollment funnels.',
    services: ['Modern Web Design', 'Interactive Motion', 'Mobile Optimization', 'Editorial UX'],
    coverImage: '/portfolio/portfolio_web_academy.jpg',
    gallery: ['/portfolio/portfolio_web_academy.jpg'],
    date: '2026',
    result: '184% Enrollment Lift',
    link: '#',
    featured: true,
  },
  {
    id: 'social-studio-sanctuary',
    title: 'Social Studio Digital Sanctuary',
    client: 'Social Studio Official',
    category: 'WEB DESIGN',
    description: 'The bespoke interactive digital home for Social Studio. Blending motion design, scrapbook desk elements, custom typography, browser voice narration, and creator storytelling.',
    services: ['Web Design', 'Interactive Motion', 'Voice Dubbing Experience', 'Creative Direction'],
    coverImage: '/mansi-full-cutout.png',
    gallery: ['/mansi-portrait.png', '/stickers/founder-cutout.png'],
    date: '2026',
    result: 'Official Studio Home ♡',
    link: '#hero',
    featured: true,
  },
];
