import React from 'react';
import { Sparkles, Heart } from 'lucide-react';

interface MarqueeProps {
  reverse?: boolean;
  bg?: string;
  textColor?: string;
  borderColor?: string;
}

export const Marquee: React.FC<MarqueeProps> = ({
  reverse = false,
  bg = "bg-studio-dark",
  textColor = "text-white",
  borderColor = "border-studio-dark"
}) => {
  const items = [
    "CONTENT",
    "DESIGN",
    "STRATEGY",
    "REELS",
    "BRANDING",
    "SOCIAL MEDIA",
    "WEB",
    "GROWTH",
    "STORIES",
    "COPYWRITING",
    "PERFORMANCE",
  ];

  return (
    <div className={`relative overflow-hidden py-3 sm:py-4 border-y-3 ${borderColor} ${bg} select-none`}>
      <div className={`flex w-max ${reverse ? 'animate-marquee-reverse' : 'animate-marquee'} hover:[animation-play-state:paused]`}>
        {[...Array(4)].map((_, listIdx) => (
          <div key={listIdx} className="flex items-center shrink-0">
            {items.map((item, idx) => (
              <div key={idx} className="flex items-center mx-3 sm:mx-6">
                <span className={`font-display font-black text-sm sm:text-lg lg:text-xl tracking-wider uppercase ${textColor}`}>
                  {item}
                </span>
                <span className="mx-3 sm:mx-6 text-studio-pink font-bold">
                  {idx % 2 === 0 ? "♡" : "•"}
                </span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
