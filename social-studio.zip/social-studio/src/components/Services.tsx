import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Sparkles, 
  Video, 
  Palette, 
  Compass, 
  PenTool, 
  TrendingUp, 
  Globe, 
  ArrowUpRight,
  CheckCircle2,
  XCircle,
  Heart,
  Star,
  Zap,
  Smile
} from 'lucide-react';
import { UnderlineScribble, ArrowDoodle, SparkleDoodle, HeartDoodle } from './Doodles';
import { sound } from '../utils/sound';

interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string; // Exact quote from prompt
  extendedDesc: string;
  genericWay: string;
  studioWay: string;
  icon: React.ReactNode;
  tags: string[];
  deliverables: string[];
  doodleText: string;
  doodleIcon: React.ReactNode;
  badgeBg: string;
}

// 3D Tilt Bento Card Component
const TiltCard: React.FC<{
  service: ServiceItem;
  idx: number;
  comparisonMode: 'studio' | 'vs';
}> = ({ service, idx, comparisonMode }) => {
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    // Tilt angle limited to subtle ±8 degrees for a premium feel
    const rotX = ((y - centerY) / centerY) * -8;
    const rotY = ((x - centerX) / centerX) * 8;
    setRotateX(rotX);
    setRotateY(rotY);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setIsHovered(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: idx * 0.08, duration: 0.4 }}
      style={{ perspective: 1000 }}
      className="group"
    >
      <motion.div
        animate={{
          rotateX,
          rotateY,
          transformStyle: 'preserve-3d',
        }}
        transition={{ type: 'spring', damping: 20, stiffness: 300, mass: 0.1 }}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => {
          sound.playPop();
          setIsHovered(true);
        }}
        onMouseLeave={handleMouseLeave}
        className={`relative h-full p-6 sm:p-7 rounded-3xl border-3 border-studio-dark bg-white shadow-sticker group-hover:shadow-sticker-lg transition-all duration-300 group-hover:-translate-y-2 flex flex-col justify-between overflow-hidden cursor-pointer`}
      >
        {/* Top Accent Strip */}
        <div className="washi-tape washi-tape-pink !top-[-10px] !w-24 opacity-0 group-hover:opacity-100 transition-opacity" />

        <div>
          {/* Card Top: Icon, Unique Doodle & Moving Arrow */}
          <div className="flex items-center justify-between gap-4 mb-4">
            <div className={`p-3 rounded-2xl border-2 border-studio-dark ${service.badgeBg} shadow-sticker-sm flex items-center justify-center group-hover:scale-110 transition-transform`}>
              {service.icon}
            </div>

            <div className="flex items-center gap-2">
              <span className="font-hand text-xl font-bold text-studio-dark/80 -rotate-3 select-none flex items-center gap-1">
                {service.doodleIcon}
                <span>{service.doodleText}</span>
              </span>

              {/* Moving Arrow following hover state */}
              <div className="w-8 h-8 rounded-full bg-studio-cream border-2 border-studio-dark flex items-center justify-center group-hover:bg-studio-pink group-hover:text-white transition-all duration-300 group-hover:translate-x-1 group-hover:-translate-y-1">
                <ArrowUpRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Service Title */}
          <h3 className="font-display font-black text-2xl text-studio-dark tracking-tight uppercase group-hover:text-studio-pink transition-colors">
            {service.title}
          </h3>

          {/* Exact Quote from User Prompt */}
          <p className="font-hand text-xl text-studio-pink font-bold mt-1 mb-3 leading-snug">
            “{service.shortDesc}”
          </p>

          <p className="text-xs sm:text-sm text-studio-dark/75 font-medium leading-relaxed mb-6">
            {service.extendedDesc}
          </p>
        </div>

        {/* Comparison or Deliverables Breakdown */}
        {comparisonMode === 'vs' ? (
          <div className="space-y-2 pt-3 border-t-2 border-dashed border-studio-dark/15 text-xs">
            <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-900 flex items-start gap-2">
              <XCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-black block uppercase text-[10px]">Generic Agency:</span>
                <span>{service.genericWay}</span>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-950 flex items-start gap-2 font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-black block uppercase text-[10px] text-emerald-700">Social Studio:</span>
                <span>{service.studioWay}</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="pt-3 border-t-2 border-dashed border-studio-dark/15 space-y-3">
            {/* Revealing Deliverables */}
            <div className="space-y-1.5">
              {service.deliverables.map((deliv, i) => (
                <div key={i} className="flex items-center gap-2 text-xs font-bold text-studio-dark/90">
                  <CheckCircle2 className="w-3.5 h-3.5 text-studio-pink-hot shrink-0" />
                  <span>{deliv}</span>
                </div>
              ))}
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {service.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-0.5 rounded-full bg-studio-cream border border-studio-dark/20 text-[10px] font-black text-studio-dark"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        )}

      </motion.div>
    </motion.div>
  );
};

export const Services: React.FC = () => {
  const [comparisonMode, setComparisonMode] = useState<'studio' | 'vs'>('studio');

  // Exact 6 services specified by user:
  const servicesData: ServiceItem[] = [
    {
      id: "content-creation",
      title: "CONTENT CREATION",
      shortDesc: "Reels, carousels, stories, campaigns and scroll-stopping content.",
      extendedDesc: "High-retention video edits, custom sound design, typography animations, and hooks engineered to stop thumbs in under 1.5 seconds.",
      genericWay: "Recycled Canva templates that get scrolled past.",
      studioWay: "Bespoke cinematic edits tailored to current audio trends.",
      icon: <Video className="w-6 h-6 text-studio-dark" />,
      tags: ["Reels / Shorts", "Carousels", "Story Drops", "UGC Production"],
      deliverables: ["Viral Hook Architecture", "Audio Syncing", "Thumb-stopping Cover Art"],
      doodleText: "3-second hook ♡",
      doodleIcon: <Heart className="w-4 h-4 text-studio-pink fill-studio-pink" />,
      badgeBg: "bg-studio-pink-soft",
    },
    {
      id: "graphic-design",
      title: "GRAPHIC DESIGN",
      shortDesc: "Creative visuals that make your brand instantly recognizable.",
      extendedDesc: "Unmistakable brand visuals that make you instantly recognizable across every Instagram grid, packaging box, and feed story.",
      genericWay: "Generic corporate color schemes and stock graphics.",
      studioWay: "Curated Gen-Z palettes, custom stickers & editorial layouts.",
      icon: <Palette className="w-6 h-6 text-studio-dark" />,
      tags: ["Brand Identity", "Packaging", "Sticker Kits", "Feed Layouts"],
      deliverables: ["Custom Color Harmonies", "Signature Doodles", "Social Styleguide"],
      doodleText: "aesthetic AF ✨",
      doodleIcon: <Sparkles className="w-4 h-4 text-amber-500" />,
      badgeBg: "bg-studio-yellow-soft",
    },
    {
      id: "social-media-strategy",
      title: "SOCIAL MEDIA STRATEGY",
      shortDesc: "Content pillars, calendars, positioning and growth-focused planning.",
      extendedDesc: "A crystal-clear roadmap that turns passive viewers into obsessed brand advocates through calculated positioning and cadence.",
      genericWay: "Posting randomly and praying the algorithm helps.",
      studioWay: "Strategic 4-pillar monthly calendar with clear KPIs.",
      icon: <Compass className="w-6 h-6 text-studio-dark" />,
      tags: ["Content Calendar", "Audience DNA", "Trend Spotting"],
      deliverables: ["Monthly Planning Blueprints", "Competitor Gap Matrix", "Audio Spotlights"],
      doodleText: "growth roadmap 📈",
      doodleIcon: <TrendingUp className="w-4 h-4 text-emerald-600" />,
      badgeBg: "bg-studio-green-soft",
    },
    {
      id: "copywriting",
      title: "COPYWRITING",
      shortDesc: "Hooks, captions, CTAs and messaging that sound like your brand.",
      extendedDesc: "No corporate marketing speak. We write relatable, punchy hooks and captions that build intimate community trust and trigger clicks.",
      genericWay: "Robotic ChatGPT captions filled with 30 useless hashtags.",
      studioWay: "Witty, human, voice-matched storytelling that converts.",
      icon: <PenTool className="w-6 h-6 text-studio-dark" />,
      tags: ["Hook Writing", "Story Sequences", "Newsletters", "CTAs"],
      deliverables: ["Irresistible 3s Hooks", "Relatable Captions", "Direct-Response CTAs"],
      doodleText: "words that hit ♡",
      doodleIcon: <Heart className="w-4 h-4 text-purple-600 fill-purple-600" />,
      badgeBg: "bg-studio-purple-soft",
    },
    {
      id: "performance-marketing",
      title: "PERFORMANCE MARKETING",
      shortDesc: "Creative campaigns designed around attention and action.",
      extendedDesc: "Paid creative campaigns built to look native to the feed—maximizing ROAS without looking like desperate advertisements.",
      genericWay: "Ugly banner ads that get 0.2% click-through rate.",
      studioWay: "Native-feeling UGC and aesthetic creatives with 3.8x ROAS.",
      icon: <TrendingUp className="w-6 h-6 text-studio-dark" />,
      tags: ["Meta Ads", "A/B Testing", "Funnel Creatives"],
      deliverables: ["High-CTR Video Hooks", "Audience Retargeting", "Fortnightly Reports"],
      doodleText: "high ROAS 🎯",
      doodleIcon: <Zap className="w-4 h-4 text-amber-500" />,
      badgeBg: "bg-studio-pink-soft",
    },
    {
      id: "website-building",
      title: "WEBSITE BUILDING",
      shortDesc: "Modern websites that give your brand a digital home.",
      extendedDesc: "High-speed, motion-rich websites that feel alive. Designed to showcase your portfolio, sell products, and convert visitors into clients.",
      genericWay: "Slow, clunky WordPress sites with broken mobile views.",
      studioWay: "Motion-first, ultra-responsive, scrapbook-inspired homes.",
      icon: <Globe className="w-6 h-6 text-studio-dark" />,
      tags: ["Modern Web", "Portfolios", "Landing Pages", "SEO"],
      deliverables: ["Custom Micro-Interactions", "Mobile-First UX", "Speed Optimization"],
      doodleText: "digital sanctuary 💻",
      doodleIcon: <Smile className="w-4 h-4 text-blue-500" />,
      badgeBg: "bg-studio-blue-soft",
    },
  ];

  return (
    <section id="services" className="relative py-24 sm:py-32 bg-studio-cream bg-grid-paper overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-studio-pink-soft text-studio-pink-hot border-2 border-studio-dark shadow-sticker-sm text-xs font-black uppercase tracking-wider mb-4">
            <Sparkles className="w-4 h-4" />
            <span>FULL CREATIVE ECOSYSTEM</span>
          </div>

          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl text-studio-dark tracking-tight uppercase">
            WHAT CAN WE CREATE <br />
            <span className="relative inline-block text-studio-pink font-editorial italic lowercase text-5xl sm:text-7xl font-normal">
              for you?
            </span>
          </h2>
          <UnderlineScribble className="w-52 sm:w-72 mx-auto mt-2 text-studio-pink-hot" />

          {/* Perspective Switcher */}
          <div className="inline-flex items-center gap-2 p-1.5 rounded-2xl bg-white border-2 border-studio-dark shadow-sticker-sm mt-8">
            <button
              onClick={() => {
                sound.playClick();
                setComparisonMode('studio');
              }}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase transition-all ${
                comparisonMode === 'studio'
                  ? 'bg-studio-pink text-white shadow-sticker-sm'
                  : 'text-studio-dark hover:bg-studio-cream'
              }`}
            >
              ✦ Social Studio Standard
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setComparisonMode('vs');
              }}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase transition-all ${
                comparisonMode === 'vs'
                  ? 'bg-studio-dark text-white shadow-sticker-sm'
                  : 'text-studio-dark hover:bg-studio-cream'
              }`}
            >
              ⚡ The Generic Agency vs. Us
            </button>
          </div>
        </div>

        {/* 3D Tilt Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {servicesData.map((service, idx) => (
            <TiltCard
              key={service.id}
              service={service}
              idx={idx}
              comparisonMode={comparisonMode}
            />
          ))}
        </div>

        {/* Retainers Callout */}
        <div className="mt-14 text-center">
          <div className="inline-flex flex-wrap items-center justify-center gap-3 px-6 py-3 rounded-2xl bg-white border-2 border-studio-dark shadow-sticker">
            <span className="font-hand text-2xl font-bold text-studio-pink">
              Every package is bespoke to your growth goals ♡
            </span>
            <a
              href="#packages"
              onClick={() => sound.playClick()}
              className="font-black text-xs sm:text-sm text-studio-dark hover:text-studio-pink underline underline-offset-4"
            >
              Explore Monthly Retainers ↓
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
