import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Check, Flame, ArrowRight, Heart, ShieldCheck, Zap } from 'lucide-react';
import { UnderlineScribble } from './Doodles';
import { sound } from '../utils/sound';

interface PackageProps {
  onSelectPackage: (name: string) => void;
}

export const Packages: React.FC<PackageProps> = ({ onSelectPackage }) => {
  const [isQuarterly, setIsQuarterly] = useState(false);

  const calculatePrice = (monthly: number) => {
    if (!isQuarterly) return `₹${monthly.toLocaleString()}`;
    const discounted = Math.round(monthly * 0.85);
    return `₹${discounted.toLocaleString()}`;
  };

  const packages = [
    {
      name: "STARTER",
      basePrice: 8500,
      subtitle: "Best for businesses launching their social media journey",
      popular: false,
      badge: "Launch Pad",
      cardBg: "bg-white",
      btnBg: "bg-white hover:bg-studio-pink hover:text-white text-studio-dark",
      features: [
        "10-12 High-Retention Static Posts",
        "8 Aesthetic Reels / Shorts",
        "10 Story Drop Sequences",
        "Captions, SEO & Hashtag Research",
        "Monthly Content Blueprint Calendar",
        "Publishing & Grid Curation",
        "Monthly Performance Breakdown",
        "1 Revision Round per Creative",
      ],
    },
    {
      name: "GROWTH",
      basePrice: 14500,
      subtitle: "For brands looking to build consistent, viral community",
      popular: true,
      badge: "Most Popular ♡",
      cardBg: "bg-studio-pink-soft",
      btnBg: "bg-studio-pink hover:bg-studio-pink-hot text-white",
      features: [
        "15 High-Retention Static Posts",
        "10 Aesthetic Reels / Shorts",
        "12 Story Drop Sequences",
        "Captions, SEO & Hashtag Research",
        "Monthly Content Blueprint Calendar",
        "Publishing & Grid Curation",
        "Community & Comment Management",
        "Competitor Gap & Trend Research",
        "Monthly Performance Breakdown",
        "2 Revision Rounds per Creative",
      ],
    },
    {
      name: "PREMIUM",
      basePrice: 25000,
      subtitle: "Comprehensive, full-scale digital studio takeover",
      popular: false,
      badge: "Full Scale Takeover",
      cardBg: "bg-white",
      btnBg: "bg-studio-dark hover:bg-studio-pink text-white",
      features: [
        "18-20 High-Retention Static Posts",
        "15 Viral Reels / Shorts",
        "20 Story Drop Sequences",
        "Captions, SEO & Hashtag Research",
        "Advanced Content & Funnel Planning",
        "Publishing & Grid Curation",
        "Full Community & DM Management",
        "Competitor Gap & Trend Research",
        "Monthly 1-on-1 Strategy Video Call",
        "Detailed Performance & ROI Report",
        "2 Revision Rounds per Creative",
      ],
    },
  ];

  return (
    <section id="packages" className="relative py-24 sm:py-32 bg-white border-y-3 border-studio-dark overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-studio-yellow border-2 border-studio-dark shadow-sticker-sm text-xs font-black uppercase tracking-wider mb-4">
            <Sparkles className="w-4 h-4 text-studio-dark" />
            <span>TRANSPARENT MONTHLY RETAINERS</span>
          </div>

          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl text-studio-dark tracking-tight uppercase">
            MONTHLY <br />
            <span className="relative inline-block text-studio-pink font-editorial italic lowercase text-5xl sm:text-7xl font-normal">
              packages ♡
            </span>
          </h2>
          <UnderlineScribble className="w-48 sm:w-64 mx-auto mt-2 text-studio-pink-hot" />

          {/* Billing Cycle Toggle */}
          <div className="mt-8 inline-flex items-center gap-3 p-1.5 rounded-2xl bg-studio-cream border-2 border-studio-dark shadow-sticker-sm">
            <button
              onClick={() => {
                sound.playClick();
                setIsQuarterly(false);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase transition-all ${
                !isQuarterly
                  ? 'bg-studio-dark text-white shadow-sticker-sm'
                  : 'text-studio-dark hover:bg-white'
              }`}
            >
              Monthly Retainer
            </button>
            <button
              onClick={() => {
                sound.playSparkle();
                setIsQuarterly(true);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase transition-all flex items-center gap-1.5 ${
                isQuarterly
                  ? 'bg-studio-pink text-white shadow-sticker-sm'
                  : 'text-studio-dark hover:bg-white'
              }`}
            >
              <span>3-Month Partnership</span>
              <span className="px-1.5 py-0.5 rounded-md bg-studio-yellow text-studio-dark text-[10px] font-black">
                SAVE 15%
              </span>
            </button>
          </div>

          <p className="font-hand text-xl text-studio-pink font-bold mt-3">
            {isQuarterly ? "✨ 15% discount applied across all retainer tiers!" : "♡ Flexible monthly rolling agreements • No long-term handcuffs"}
          </p>
        </div>

        {/* 3 Tier Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 sm:gap-10 items-stretch">
          {packages.map((pkg, idx) => (
            <motion.div
              key={pkg.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.12, duration: 0.4 }}
              className={`relative rounded-3xl border-3 border-studio-dark ${pkg.cardBg} ${
                pkg.popular ? 'shadow-sticker-lg -translate-y-2' : 'shadow-sticker'
              } p-6 sm:p-8 flex flex-col justify-between`}
            >
              {/* Top Washi Tape or Popular Ribbon */}
              {pkg.popular && (
                <>
                  <div className="washi-tape washi-tape-pink !top-[-10px] !w-32" />
                  <div className="absolute -top-4 right-6 bg-studio-yellow px-4 py-1 rounded-full border-2 border-studio-dark text-xs font-black uppercase tracking-wider shadow-sticker-sm flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-orange-500 fill-orange-500" />
                    <span>{pkg.badge}</span>
                  </div>
                </>
              )}

              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-display font-black text-2xl text-studio-dark tracking-tight uppercase">
                    {pkg.name}
                  </h3>
                  {!pkg.popular && (
                    <span className="px-3 py-1 rounded-full bg-studio-cream border border-studio-dark/30 text-[10px] font-black uppercase text-studio-dark/70">
                      {pkg.badge}
                    </span>
                  )}
                </div>

                <div className="flex items-baseline gap-1 mb-2">
                  <span className="font-display font-black text-4xl sm:text-5xl text-studio-dark">
                    {calculatePrice(pkg.basePrice)}
                  </span>
                  <span className="text-xs font-bold text-studio-dark/60 uppercase">
                    / month
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-studio-dark/75 font-medium mb-6">
                  {pkg.subtitle}
                </p>

                {/* Features List */}
                <div className="space-y-2.5 pt-4 border-t-2 border-dashed border-studio-dark/20 mb-8">
                  {pkg.features.map((feature, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-xs sm:text-sm font-bold text-studio-dark">
                      <div className="w-4 h-4 rounded-full bg-studio-green-soft border border-studio-dark flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-3 h-3 text-emerald-800 stroke-[3]" />
                      </div>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <button
                onClick={() => {
                  sound.playSparkle();
                  onSelectPackage(`${pkg.name} (${calculatePrice(pkg.basePrice)}/mo)`);
                }}
                className={`w-full py-4 rounded-2xl font-black text-sm uppercase tracking-wider border-2 border-studio-dark shadow-sticker-sm hover:shadow-sticker transition-all duration-200 flex items-center justify-center gap-2 group ${pkg.btnBg}`}
              >
                <span>BOOK {pkg.name}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </motion.div>
          ))}
        </div>

        {/* Studio Retainer Perks */}
        <div className="mt-14 max-w-4xl mx-auto p-5 rounded-2xl bg-studio-cream border-2 border-studio-dark shadow-sticker grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
          <div className="flex items-center justify-center gap-2 text-xs font-bold text-studio-dark">
            <ShieldCheck className="w-4 h-4 text-studio-pink" />
            <span>Official Quotation Ref #SS-001</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-xs font-bold text-studio-dark">
            <Zap className="w-4 h-4 text-amber-500" />
            <span>Direct Access to Mansi</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-xs font-bold text-studio-dark">
            <Heart className="w-4 h-4 text-studio-pink fill-studio-pink" />
            <span>Zero Long-Term Lock-in</span>
          </div>
        </div>

      </div>
    </section>
  );
};
