import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  Sparkles,
  Heart,
  Crown,
  Palette,
  Building2,
  Calendar,
  CheckCircle2,
  FolderOpen,
  Upload,
  Play,
  Maximize2,
  ArrowRight,
  ExternalLink,
  Layers,
  Sparkle,
  Image as ImageIcon,
  Video as VideoIcon
} from 'lucide-react';
import {
  annapurnaCaseStudyData,
  annapurnaMediaItems,
  AnnapurnaMediaCategory,
  AnnapurnaMediaItem,
} from '../data/annapurnaEvents';
import { UnderlineScribble, HeartDoodle, SparkleDoodle, ArrowDoodle } from './Doodles';
import { sound } from '../utils/sound';

interface AnnapurnaCaseStudyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenContact: () => void;
}

const GALLERY_CATEGORIES: AnnapurnaMediaCategory[] = [
  'ALL',
  'Instagram Posts',
  'Festive Creatives',
  'Promotional Posters',
  'Carousel Designs',
  'Stories',
  'Reels & Videos',
];

export const AnnapurnaCaseStudyModal: React.FC<AnnapurnaCaseStudyModalProps> = ({
  isOpen,
  onClose,
  onOpenContact,
}) => {
  const [activeTab, setActiveTab] = useState<AnnapurnaMediaCategory>('ALL');
  const [activeLightboxMedia, setActiveLightboxMedia] = useState<AnnapurnaMediaItem | null>(null);
  const [coverFailed, setCoverFailed] = useState<boolean>(false);

  if (!isOpen) return null;

  const data = annapurnaCaseStudyData;
  const filteredMedia = activeTab === 'ALL'
    ? annapurnaMediaItems
    : annapurnaMediaItems.filter((item) => item.category === activeTab);

  const getPillarIcon = (name: string) => {
    switch (name) {
      case 'Crown':
        return <Crown className="w-5 h-5 text-amber-700" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-studio-pink" />;
      case 'Palette':
        return <Palette className="w-5 h-5 text-studio-dark" />;
      case 'Building2':
        return <Building2 className="w-5 h-5 text-blue-700" />;
      default:
        return <Sparkles className="w-5 h-5 text-studio-pink" />;
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-studio-dark/80 backdrop-blur-md overflow-y-auto">
        
        {/* Click outside backdrop */}
        <div className="fixed inset-0" onClick={() => { sound.playClick(); onClose(); }} />

        {/* Modal Window Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 30 }}
          transition={{ type: 'spring', damping: 26, stiffness: 320 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-5xl bg-studio-cream rounded-3xl border-4 border-studio-dark shadow-2xl p-5 sm:p-8 md:p-10 my-8 max-h-[92vh] overflow-y-auto z-10 custom-scrollbar"
        >
          {/* Top Washi Tape */}
          <div className="washi-tape washi-tape-pink !top-[-12px] !w-36" />

          {/* Close Button */}
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="sticky top-0 float-right z-30 p-2.5 rounded-full bg-white border-2 border-studio-dark shadow-sticker-sm hover:bg-studio-pink hover:text-white transition-all hover:rotate-90 -mr-2 -mt-2 sm:mr-0 sm:mt-0"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* ==================================================================== */}
          {/* MODAL HEADER: Title, Badges, Tagline */}
          {/* ==================================================================== */}
          <div className="space-y-4 pt-2">
            
            {/* Badges Bar */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3.5 py-1 rounded-full bg-studio-pink text-white border-2 border-studio-dark font-black text-[11px] uppercase tracking-wider shadow-sticker-sm flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                <span>{data.clientLabel}</span>
              </span>

              <span className="px-3.5 py-1 rounded-full bg-studio-yellow border-2 border-studio-dark font-black text-[11px] uppercase tracking-wider text-studio-dark shadow-sticker-sm">
                {data.category}
              </span>

              <span className="px-3.5 py-1 rounded-full bg-[#F5EAD4] text-amber-950 border-2 border-studio-dark font-black text-[11px] uppercase tracking-wider shadow-sticker-sm flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-700" />
                <span>Visual Direction: {data.visualDirection}</span>
              </span>
            </div>

            {/* Title & Tagline */}
            <div>
              <div className="flex items-center gap-3">
                <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl text-studio-dark uppercase tracking-tight">
                  {data.title}
                </h2>
                <span className="font-editorial italic text-3xl sm:text-5xl text-studio-pink">
                  ♡
                </span>
              </div>
              <UnderlineScribble className="w-56 sm:w-72 mt-2 text-studio-pink-hot" />

              <p className="mt-4 font-editorial italic text-xl sm:text-2xl text-studio-dark/90 leading-relaxed max-w-3xl">
                “{data.description}”
              </p>
            </div>
          </div>

          {/* ==================================================================== */}
          {/* 4E. PROJECT DETAILS BENTO BAR (Strictly requested data, NO fake stats) */}
          {/* ==================================================================== */}
          <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 p-4 sm:p-5 rounded-2xl bg-white border-3 border-studio-dark shadow-sticker">
            <div className="p-3 rounded-xl bg-studio-cream-paper border border-studio-dark/15">
              <span className="block text-[10px] font-black uppercase tracking-widest text-studio-dark/60">
                Client
              </span>
              <span className="font-display font-black text-base sm:text-lg text-studio-dark">
                {data.client}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-studio-cream-paper border border-studio-dark/15">
              <span className="block text-[10px] font-black uppercase tracking-widest text-studio-dark/60">
                Studio
              </span>
              <span className="font-display font-black text-base sm:text-lg text-studio-pink">
                {data.studio} ♡
              </span>
            </div>

            <div className="p-3 rounded-xl bg-studio-cream-paper border border-studio-dark/15">
              <span className="block text-[10px] font-black uppercase tracking-widest text-studio-dark/60">
                Project Type
              </span>
              <span className="font-display font-bold text-sm sm:text-base text-studio-dark">
                {data.projectType}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-studio-cream-paper border border-studio-dark/15">
              <span className="block text-[10px] font-black uppercase tracking-widest text-studio-dark/60">
                Visual Direction
              </span>
              <span className="font-display font-black text-base sm:text-lg text-amber-800 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-600 inline" />
                {data.visualDirection}
              </span>
            </div>
          </div>

          {/* ==================================================================== */}
          {/* 4A. PROJECT INTRODUCTION: Annapurna Events Brand Overview */}
          {/* ==================================================================== */}
          <div className="mt-12 space-y-6">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-studio-pink-soft text-studio-pink-hot border-2 border-studio-dark text-[11px] font-black uppercase tracking-wider shadow-sticker-sm">
                01 / Brand Overview
              </span>
              <div className="h-0.5 flex-1 bg-studio-dark/10" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-7 space-y-4">
                <h3 className="font-display font-black text-2xl sm:text-3xl text-studio-dark uppercase">
                  {data.overview.headline}
                </h3>
                
                <p className="text-base sm:text-lg font-medium text-studio-dark/85 leading-relaxed">
                  {data.overview.introduction}
                </p>

                <p className="text-sm sm:text-base text-studio-dark/75 leading-relaxed font-sans">
                  {data.overview.detail}
                </p>
              </div>

              {/* Scrapbook Note Quote */}
              <div className="lg:col-span-5 relative p-5 rounded-2xl bg-studio-yellow border-3 border-studio-dark shadow-sticker rotate-1">
                <div className="washi-tape washi-tape-pink !top-[-10px] !w-24" />
                <span className="text-[11px] font-black uppercase tracking-wider text-studio-dark/70 block mb-1">
                  Creative Direction Brief
                </span>
                <p className="font-hand text-xl sm:text-2xl font-bold text-studio-dark leading-snug">
                  “Translate the grand physical scale of luxury weddings & galas into intimate, scroll-stopping digital content.”
                </p>
                <div className="mt-3 flex items-center justify-between text-xs font-bold text-studio-dark/70 border-t border-studio-dark/20 pt-2">
                  <span>Social Studio x Annapurna Events</span>
                  <span>✨ 2026 Archive</span>
                </div>
              </div>
            </div>

            {/* 4 Core Pillars of the Brand */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 pt-2">
              {data.overview.pillars.map((pillar, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-white border-2 border-studio-dark/25 shadow-sticker-sm hover:border-studio-dark transition-all space-y-2 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-studio-cream border-2 border-studio-dark flex items-center justify-center group-hover:scale-110 transition-transform">
                    {getPillarIcon(pillar.icon)}
                  </div>
                  <h4 className="font-display font-black text-sm uppercase tracking-tight text-studio-dark">
                    {pillar.title}
                  </h4>
                  <p className="text-xs text-studio-dark/75 leading-normal">
                    {pillar.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* ==================================================================== */}
          {/* 4B. MY CONTRIBUTION: What I Designed & Executed */}
          {/* ==================================================================== */}
          <div className="mt-14 space-y-6">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-studio-yellow text-studio-dark border-2 border-studio-dark text-[11px] font-black uppercase tracking-wider shadow-sticker-sm">
                02 / My Contribution
              </span>
              <div className="h-0.5 flex-1 bg-studio-dark/10" />
            </div>

            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
              <div>
                <h3 className="font-display font-black text-2xl sm:text-3xl text-studio-dark uppercase">
                  Social Studio Creative Scope
                </h3>
                <p className="text-sm text-studio-dark/70 font-medium">
                  End-to-end creative direction, graphic architecture, and content storytelling delivered for Annapurna Events:
                </p>
              </div>
              <span className="font-hand text-lg font-bold text-studio-pink shrink-0">
                Crafted with love & strategy ♡
              </span>
            </div>

            {/* 6 Contribution Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {data.contributions.map((c, i) => (
                <div
                  key={c.id}
                  className="p-5 rounded-2xl bg-white border-3 border-studio-dark shadow-sticker hover:shadow-sticker-lg transition-all duration-200 flex flex-col justify-between group"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full bg-studio-pink-soft text-studio-pink-hot border border-studio-pink/30 text-[10px] font-black uppercase tracking-wider">
                        {c.tag}
                      </span>
                      <span className="text-xs font-display font-black text-studio-dark/40">
                        0{i + 1}
                      </span>
                    </div>

                    <h4 className="font-display font-black text-lg text-studio-dark group-hover:text-studio-pink transition-colors">
                      {c.title}
                    </h4>

                    <p className="text-xs sm:text-sm text-studio-dark/75 leading-relaxed">
                      {c.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-dashed border-studio-dark/15 flex items-center gap-2 text-xs font-bold text-studio-dark/70">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Delivered for Brand Archive</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ==================================================================== */}
          {/* 4C. CREATIVE DIRECTION: Champagne Luxury Identity */}
          {/* ==================================================================== */}
          <div className="mt-14 space-y-6">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-[#F5EAD4] text-amber-950 border-2 border-studio-dark text-[11px] font-black uppercase tracking-wider shadow-sticker-sm flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                <span>03 / Creative Direction</span>
              </span>
              <div className="h-0.5 flex-1 bg-studio-dark/10" />
            </div>

            {/* Creative Direction Header Banner */}
            <div className="relative p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#FFFDF9] via-[#FAF6EE] to-[#F5EAD4] border-3 border-studio-dark shadow-sticker overflow-hidden">
              <div className="washi-tape washi-tape-yellow !top-[-10px] !w-32" />
              
              <div className="max-w-2xl space-y-3">
                <div className="inline-block px-3 py-1 rounded-full bg-amber-100 border border-amber-300 text-[11px] font-black uppercase tracking-wider text-amber-900">
                  Visual Direction Monograph
                </div>

                <h3 className="font-display font-black text-3xl sm:text-4xl text-studio-dark uppercase tracking-tight">
                  {data.creativeDirection.theme}
                </h3>

                <p className="font-editorial italic text-xl text-amber-900">
                  {data.creativeDirection.subtitle}
                </p>

                <p className="text-sm sm:text-base text-studio-dark/80 leading-relaxed font-sans">
                  {data.creativeDirection.description}
                </p>
              </div>

              {/* Decorative Luxury Monogram Stamp */}
              <div className="absolute right-4 bottom-4 opacity-15 pointer-events-none hidden md:block">
                <div className="w-40 h-40 rounded-full border-8 border-amber-800 flex items-center justify-center font-editorial italic text-6xl font-bold">
                  AE
                </div>
              </div>
            </div>

            {/* 5 Core Principles */}
            <div className="space-y-3">
              <h4 className="font-display font-black text-sm uppercase tracking-wider text-studio-dark">
                The 5 Visual Principles
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {data.creativeDirection.principles.map((pr, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-white border-2 border-studio-dark/25 shadow-sticker-sm space-y-1.5"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-amber-500" />
                      <h5 className="font-display font-black text-xs uppercase tracking-tight text-studio-dark">
                        {pr.title}
                      </h5>
                    </div>
                    <p className="text-xs text-studio-dark/75 leading-relaxed">
                      {pr.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Champagne Luxury Palette Swatches */}
            <div className="space-y-3">
              <h4 className="font-display font-black text-sm uppercase tracking-wider text-studio-dark">
                Curated Color Harmonies
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                {data.creativeDirection.palette.map((color, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-2xl bg-white border-2 border-studio-dark shadow-sticker-sm space-y-2 flex flex-col justify-between"
                  >
                    <div
                      className="w-full h-14 rounded-xl border-2 border-studio-dark/20 shadow-inner flex items-end justify-end p-1.5"
                      style={{ backgroundColor: color.hex }}
                    >
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-white/90 text-studio-dark shadow-sm">
                        {color.hex}
                      </span>
                    </div>

                    <div>
                      <div className="font-display font-black text-xs uppercase text-studio-dark leading-tight">
                        {color.name}
                      </div>
                      <p className="text-[10px] text-studio-dark/70 mt-1 leading-tight">
                        {color.role}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ==================================================================== */}
          {/* 4D. CREATIVE GALLERY: Assets from /public/portfolio/annapurna-events/ */}
          {/* ==================================================================== */}
          <div className="mt-14 space-y-6">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-studio-pink text-white border-2 border-studio-dark text-[11px] font-black uppercase tracking-wider shadow-sticker-sm">
                04 / Creative Gallery
              </span>
              <div className="h-0.5 flex-1 bg-studio-dark/10" />
            </div>

            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
              <div>
                <h3 className="font-display font-black text-2xl sm:text-3xl text-studio-dark uppercase">
                  Actual Creative Archive
                </h3>
                <p className="text-xs sm:text-sm text-studio-dark/70 font-medium">
                  Showcasing Instagram posts, festive creatives, posters, carousels, stories & video reels.
                </p>
              </div>

              {/* Supported formats indicator */}
              <div className="flex items-center gap-1.5 text-xs font-mono font-bold bg-white px-3 py-1.5 rounded-full border border-studio-dark/30 shadow-sticker-sm shrink-0">
                <span className="text-studio-pink">Formats:</span>
                <span>JPG • PNG • WebP • MP4</span>
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-2">
              {GALLERY_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    sound.playClick();
                    setActiveTab(cat);
                  }}
                  className={`px-3 py-1.5 rounded-full font-display font-bold text-[11px] uppercase tracking-wider border-2 border-studio-dark transition-all ${
                    activeTab === cat
                      ? 'bg-studio-dark text-white shadow-sticker-sm -translate-y-0.5'
                      : 'bg-white hover:bg-studio-cream text-studio-dark'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Gallery Media Grid OR Clean Editable Placeholder */}
            {filteredMedia.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredMedia.map((item) => (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="group relative rounded-2xl bg-white border-3 border-studio-dark shadow-sticker hover:shadow-sticker-lg transition-all duration-300 p-3 flex flex-col justify-between"
                  >
                    <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-studio-cream-paper border border-studio-dark/20 mb-3 flex items-center justify-center">
                      {item.type === 'video' ? (
                        <video
                          src={item.src}
                          controls
                          playsInline
                          preload="metadata"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <img
                          src={item.src}
                          alt={item.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                          onClick={() => {
                            sound.playCamera();
                            setActiveLightboxMedia(item);
                          }}
                        />
                      )}

                      {/* Top category sticker */}
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-white/95 border border-studio-dark text-[10px] font-black uppercase text-studio-dark shadow-sm">
                        {item.category}
                      </span>

                      {/* Zoom click indicator for images */}
                      {item.type === 'image' && (
                        <button
                          onClick={() => {
                            sound.playCamera();
                            setActiveLightboxMedia(item);
                          }}
                          className="absolute bottom-2 right-2 p-1.5 rounded-lg bg-white/90 border border-studio-dark/40 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-studio-pink hover:text-white"
                          title="View Full Size"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <div className="space-y-1">
                      <h4 className="font-display font-black text-sm text-studio-dark uppercase">
                        {item.title}
                      </h4>
                      {item.caption && (
                        <p className="text-xs text-studio-dark/70 font-medium line-clamp-2">
                          {item.caption}
                        </p>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              /* CLEAN EDITABLE PLACEHOLDER (No AI fabricated images) */
              <div className="p-6 sm:p-8 rounded-3xl bg-white border-3 border-dashed border-studio-dark/40 shadow-sm space-y-6">
                
                {/* Notice Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-studio-cream-paper border-2 border-studio-dark/20">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-studio-yellow border-2 border-studio-dark flex items-center justify-center shrink-0">
                      <FolderOpen className="w-6 h-6 text-studio-dark" />
                    </div>
                    <div>
                      <h4 className="font-display font-black text-base uppercase text-studio-dark">
                        Creative Assets Directory
                      </h4>
                      <code className="text-xs font-mono font-bold text-studio-pink bg-studio-pink-soft px-2 py-0.5 rounded border border-studio-pink/30">
                        /public/portfolio/annapurna-events/
                      </code>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[11px] font-bold text-studio-dark/60 block">
                      Authentic Portfolio Guarantee
                    </span>
                    <span className="text-xs font-black text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300">
                      ✓ No AI-generated filler work
                    </span>
                  </div>
                </div>

                {/* 3 Step Instructions for Adding Media */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  
                  {/* Step 1 */}
                  <div className="p-4 rounded-2xl bg-studio-cream/60 border border-studio-dark/20 space-y-2">
                    <span className="w-6 h-6 rounded-full bg-studio-dark text-white font-black text-xs flex items-center justify-center">
                      1
                    </span>
                    <h5 className="font-display font-black text-xs uppercase text-studio-dark">
                      Drop Your Real Files
                    </h5>
                    <p className="text-xs text-studio-dark/75 leading-relaxed">
                      Copy your Instagram posts, festive designs, posters, stories, or MP4 video reels into <code className="text-studio-pink font-bold">/public/portfolio/annapurna-events/</code>.
                    </p>
                  </div>

                  {/* Step 2 */}
                  <div className="p-4 rounded-2xl bg-studio-cream/60 border border-studio-dark/20 space-y-2">
                    <span className="w-6 h-6 rounded-full bg-studio-dark text-white font-black text-xs flex items-center justify-center">
                      2
                    </span>
                    <h5 className="font-display font-black text-xs uppercase text-studio-dark">
                      Update Project Config
                    </h5>
                    <p className="text-xs text-studio-dark/75 leading-relaxed">
                      Open <code className="text-studio-pink font-bold">src/data/annapurnaEvents.ts</code> and add your file names to <code className="text-studio-dark font-mono font-bold">annapurnaMediaItems</code>.
                    </p>
                  </div>

                  {/* Step 3 */}
                  <div className="p-4 rounded-2xl bg-studio-cream/60 border border-studio-dark/20 space-y-2">
                    <span className="w-6 h-6 rounded-full bg-studio-dark text-white font-black text-xs flex items-center justify-center">
                      3
                    </span>
                    <h5 className="font-display font-black text-xs uppercase text-studio-dark">
                      Instant Live Gallery
                    </h5>
                    <p className="text-xs text-studio-dark/75 leading-relaxed">
                      Your authentic creative work appears right here with category filters, video playback, and full-screen preview!
                    </p>
                  </div>

                </div>

                {/* Visual Placeholder Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  <div className="aspect-[4/3] rounded-2xl border-2 border-dashed border-studio-dark/25 bg-studio-cream/30 flex flex-col items-center justify-center p-4 text-center space-y-2">
                    <ImageIcon className="w-8 h-8 text-studio-dark/40" />
                    <span className="font-display font-black text-xs uppercase text-studio-dark/70">
                      Instagram Posts & Carousels
                    </span>
                    <span className="text-[10px] text-studio-dark/50 font-mono">
                      .jpg / .png / .webp
                    </span>
                  </div>

                  <div className="aspect-[4/3] rounded-2xl border-2 border-dashed border-studio-dark/25 bg-studio-cream/30 flex flex-col items-center justify-center p-4 text-center space-y-2">
                    <Sparkles className="w-8 h-8 text-amber-600/50" />
                    <span className="font-display font-black text-xs uppercase text-studio-dark/70">
                      Festive Campaign Creatives
                    </span>
                    <span className="text-[10px] text-studio-dark/50 font-mono">
                      Champagne Luxury Styling
                    </span>
                  </div>

                  <div className="aspect-[4/3] rounded-2xl border-2 border-dashed border-studio-dark/25 bg-studio-cream/30 flex flex-col items-center justify-center p-4 text-center space-y-2">
                    <VideoIcon className="w-8 h-8 text-studio-pink/50" />
                    <span className="font-display font-black text-xs uppercase text-studio-dark/70">
                      Reels & Event Video Showcases
                    </span>
                    <span className="text-[10px] text-studio-dark/50 font-mono">
                      .mp4 format supported
                    </span>
                  </div>
                </div>

              </div>
            )}
          </div>

          {/* ==================================================================== */}
          {/* MODAL FOOTER & CALL TO ACTION */}
          {/* ==================================================================== */}
          <div className="mt-14 pt-6 border-t-3 border-dashed border-studio-dark/20 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <p className="font-hand text-2xl font-bold text-studio-dark">
                Loved this client showcase? Let’s collaborate! ♡
              </p>
              <p className="text-xs text-studio-dark/70 font-medium">
                Elevating brands across hospitality, event management, and lifestyle.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  sound.playClick();
                  onClose();
                }}
                className="px-5 py-3 rounded-2xl bg-white hover:bg-studio-cream text-studio-dark font-black text-xs uppercase tracking-wider border-2 border-studio-dark shadow-sticker-sm transition-all"
              >
                Close Archive
              </button>

              <button
                onClick={() => {
                  sound.playSparkle();
                  onClose();
                  onOpenContact();
                }}
                className="px-6 py-3 rounded-2xl bg-studio-pink hover:bg-studio-pink-hot text-white font-black text-xs uppercase tracking-wider border-2 border-studio-dark shadow-sticker hover:shadow-sticker-lg transition-all flex items-center gap-2 group"
              >
                <span>Start a project with Mansi</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

        </motion.div>

        {/* ==================================================================== */}
        {/* LIGHTBOX MODAL FOR FULL-SIZE IMAGE PREVIEW */}
        {/* ==================================================================== */}
        <AnimatePresence>
          {activeLightboxMedia && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveLightboxMedia(null)}
              className="fixed inset-0 z-60 bg-studio-dark/90 backdrop-blur-lg flex items-center justify-center p-4 sm:p-8 cursor-zoom-out"
            >
              <div
                onClick={(e) => e.stopPropagation()}
                className="relative max-w-4xl max-h-[88vh] bg-white rounded-3xl border-4 border-studio-dark shadow-2xl p-4 sm:p-6 overflow-hidden flex flex-col items-center"
              >
                <button
                  onClick={() => setActiveLightboxMedia(null)}
                  className="absolute top-4 right-4 p-2 rounded-full bg-studio-dark text-white hover:bg-studio-pink transition-colors z-20"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="w-full flex-1 overflow-auto flex items-center justify-center max-h-[70vh]">
                  {activeLightboxMedia.type === 'video' ? (
                    <video
                      src={activeLightboxMedia.src}
                      controls
                      autoPlay
                      playsInline
                      className="max-h-[68vh] max-w-full rounded-xl"
                    />
                  ) : (
                    <img
                      src={activeLightboxMedia.src}
                      alt={activeLightboxMedia.title}
                      className="max-h-[68vh] max-w-full object-contain rounded-xl"
                    />
                  )}
                </div>

                <div className="w-full mt-4 pt-3 border-t-2 border-studio-dark/15 flex items-center justify-between text-left">
                  <div>
                    <h4 className="font-display font-black text-lg text-studio-dark uppercase">
                      {activeLightboxMedia.title}
                    </h4>
                    {activeLightboxMedia.caption && (
                      <p className="text-xs text-studio-dark/70 font-medium">
                        {activeLightboxMedia.caption}
                      </p>
                    )}
                  </div>
                  <span className="px-3 py-1 rounded-full bg-studio-yellow border border-studio-dark text-[10px] font-black uppercase text-studio-dark">
                    {activeLightboxMedia.category}
                  </span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </AnimatePresence>
  );
};
