import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, ArrowRight, ArrowDown, Award, Zap, Heart } from 'lucide-react';
import { ArrowDoodle, SparkleDoodle, UnderlineScribble, HeartDoodle } from './Doodles';
import { sound } from '../utils/sound';

interface HeroProps {
  onOpenContact: () => void;
  onPlayVoiceNote?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenContact }) => {
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);

  // All 7 required stickers from prompt:
  // CONTENT CREATOR, STRATEGIST, DESIGNER, CREATIVE MIND, SOCIAL MEDIA, WEB DESIGN, LET'S GROW ♡
  const stickers = [
    {
      id: 'creative-mind',
      label: 'CREATIVE MIND',
      detail: 'Hook architecture & aesthetic visual systems',
      bg: 'bg-studio-pink text-white',
      top: '6%',
      left: '-8%',
      rotate: '-rotate-6',
    },
    {
      id: 'strategist',
      label: 'STRATEGIST',
      detail: 'Data-informed content pillars & algorithmic growth',
      bg: 'bg-studio-yellow text-studio-dark',
      top: '18%',
      right: '-8%',
      rotate: 'rotate-6',
    },
    {
      id: 'content-creator',
      label: 'CONTENT CREATOR',
      detail: 'High-retention Reels & swipeable carousels',
      bg: 'bg-studio-green-soft text-emerald-950',
      bottom: '32%',
      left: '-10%',
      rotate: 'rotate-4',
    },
    {
      id: 'designer',
      label: 'DESIGNER',
      detail: 'Bespoke typography, color harmonies & brand kits',
      bg: 'bg-studio-purple-soft text-purple-950',
      top: '38%',
      right: '-10%',
      rotate: '-rotate-8',
    },
    {
      id: 'social-media',
      label: 'SOCIAL MEDIA',
      detail: 'Active community cultivation & daily cadence',
      bg: 'bg-white text-studio-dark',
      bottom: '16%',
      right: '-8%',
      rotate: 'rotate-4',
    },
    {
      id: 'web-design',
      label: 'WEB DESIGN',
      detail: 'Digital sanctuaries built for seamless conversion',
      bg: 'bg-studio-blue-soft text-blue-950',
      bottom: '6%',
      left: '-4%',
      rotate: '-rotate-3',
    },
    {
      id: 'lets-grow',
      label: 'LET’S GROW ♡',
      detail: 'Ready to elevate your digital presence together',
      bg: 'bg-studio-pink-hot text-white',
      bottom: '-4%',
      right: '6%',
      rotate: 'rotate-8',
    },
  ];

  const proofPillars = [
    { label: 'Creative Direction', sub: 'High-retention content', icon: <Sparkles className="w-3.5 h-3.5 text-studio-pink" /> },
    { label: 'Strategy + Design', sub: 'Every decision has purpose', icon: <Zap className="w-3.5 h-3.5 text-amber-500" /> },
    { label: '0% Generic Templates', sub: 'Bespoke brand DNA', icon: <Award className="w-3.5 h-3.5 text-emerald-600" /> },
  ];

  return (
    <section
      id="hero"
      className="relative min-h-screen pt-28 pb-16 sm:pt-36 sm:pb-24 overflow-hidden bg-grid-paper flex items-center"
    >
      {/* Editorial Watermark Background Aura */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[850px] h-[850px] bg-studio-pink/15 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        
        {/* Studio Availability Top Ribbon */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-8 pb-4 border-b border-studio-dark/15">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border-2 border-emerald-400 text-emerald-900 text-[11px] font-black uppercase tracking-wider shadow-sm">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            <span>AVAILABLE FOR CLIENT WORK • ACCEPTING 2 NEW BRANDS FOR Q4/Q1</span>
          </div>

          <div className="hidden md:flex items-center gap-4 text-xs font-bold text-studio-dark/70">
            <span className="font-hand text-xl text-studio-pink font-bold">Bespoke Creative Retainers</span>
            <span>•</span>
            <span>Based in India, Scaling Worldwide 🌍</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headline, Subheading, CTAs */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-7 text-center lg:text-left">
            
            {/* Founder Tag */}
            <div className="space-y-1">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-studio-yellow border-2 border-studio-dark font-black text-xs uppercase tracking-wider shadow-sticker-sm">
                <Sparkles className="w-3.5 h-3.5 text-studio-dark" />
                <span>MANSI’S CREATIVE STUDIO</span>
              </div>
              
              <p className="font-hand text-2xl sm:text-3xl text-studio-pink font-bold block pt-2 -rotate-1">
                “Your brand shouldn't look like everyone else on the feed.” ♡
              </p>
            </div>

            {/* Main Headline */}
            <div className="space-y-3">
              <h1 className="font-display font-black text-4xl sm:text-6xl xl:text-7xl leading-[1.05] tracking-tight text-studio-dark uppercase">
                YOUR BRAND. <br />
                <span className="relative inline-block text-studio-pink">
                  OUR CREATIVITY.
                  <UnderlineScribble className="absolute -bottom-2 left-0 w-full h-3 sm:h-5 text-studio-pink-hot" />
                </span> <br />
                <span className="italic font-editorial font-normal tracking-normal lowercase text-5xl sm:text-7xl xl:text-8xl text-studio-dark">
                  let’s make it move.
                </span>
              </h1>
              
              {/* Exact Requested Subheading */}
              <p className="text-base sm:text-xl text-studio-dark/85 max-w-xl mx-auto lg:mx-0 font-medium leading-relaxed pt-2">
                Turning ideas into scroll-stopping content, memorable brands and digital experiences.
              </p>
            </div>

            {/* Proof Value Pillars */}
            <div className="grid grid-cols-3 gap-3 max-w-lg mx-auto lg:mx-0 py-2">
              {proofPillars.map((p, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-2xl bg-white border-2 border-studio-dark shadow-sticker-sm flex flex-col justify-center"
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    {p.icon}
                    <span className="font-display font-black text-xs sm:text-sm text-studio-dark uppercase">
                      {p.label}
                    </span>
                  </div>
                  <span className="text-[10px] sm:text-[11px] font-semibold text-studio-dark/65 leading-tight">
                    {p.sub}
                  </span>
                </div>
              ))}
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-2">
              <button
                onClick={() => {
                  sound.playClick();
                  onOpenContact();
                }}
                className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-studio-pink hover:bg-studio-pink-hot text-white font-black text-base border-3 border-studio-dark shadow-sticker hover:shadow-sticker-lg transition-all duration-200 hover:-translate-y-1 active:translate-y-0.5 flex items-center justify-center gap-3 group"
              >
                <span>LET’S GROW YOUR BRAND →</span>
              </button>

              <a
                href="#portfolio"
                onClick={() => sound.playClick()}
                className="w-full sm:w-auto px-7 py-4 rounded-2xl bg-white hover:bg-studio-cream-paper text-studio-dark font-extrabold text-base border-3 border-studio-dark shadow-sticker-sm hover:shadow-sticker transition-all duration-200 hover:-translate-y-0.5 flex items-center justify-center gap-2 group"
              >
                <span>EXPLORE OUR WORK ↓</span>
              </a>
            </div>

          </div>

          {/* Right Column: Prominent Photo with Floating Stickers & Doodle Arrows */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            
            {/* Doodle Arrows pointing toward Mansi's photo */}
            <div className="hidden sm:block absolute -top-14 -left-10 z-30 pointer-events-none">
              <span className="font-hand text-2xl font-bold text-studio-pink block -rotate-12">
                Hi, I'm Mansi! ♡
              </span>
              <ArrowDoodle className="w-20 h-14 text-studio-dark -rotate-45" direction="curved" />
            </div>

            <div className="hidden lg:block absolute -bottom-10 -left-12 z-30 pointer-events-none">
              <ArrowDoodle className="w-16 h-12 text-studio-pink rotate-45" direction="up" />
              <span className="font-hand text-xl font-bold text-studio-dark block rotate-6">
                Creative Director ✍️
              </span>
            </div>

            {/* Scrapbook Polaroid & Vinyl Sticker Framing */}
            <div className="relative w-full max-w-[410px] sm:max-w-[450px] aspect-[4/5] flex items-center justify-center">
              
              {/* Layered Backing Polaroid Card */}
              <div className="absolute inset-0 bg-white rounded-3xl border-4 border-studio-dark shadow-sticker-lg rotate-2" />
              
              {/* Washi Tape on top */}
              <div className="washi-tape washi-tape-pink !top-[-10px] !w-32" />

              {/* Inner Frame */}
              <div className="absolute inset-3 sm:inset-4 rounded-2xl bg-gradient-to-b from-studio-pink-soft via-white to-studio-cream overflow-hidden border-2 border-studio-dark/20 flex flex-col justify-between p-4">
                
                {/* Top Badge */}
                <div className="flex items-center justify-between z-20">
                  <span className="font-hand text-xl text-studio-dark/70 font-bold select-none">
                    Social Studio Official ♡
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-white/95 border-2 border-studio-dark text-[10px] font-black uppercase text-studio-dark shadow-sm">
                    Verified Founder
                  </span>
                </div>

                {/* Prominent Photo with Sticker Cutout Treatment */}
                <motion.div
                  whileHover={{ scale: 1.03 }}
                  transition={{ type: "spring", stiffness: 300, damping: 15 }}
                  className="relative z-10 w-full h-[88%] flex items-end justify-center filter drop-shadow-[0_12px_24px_rgba(20,20,22,0.18)]"
                >
                  <img
                    src="/mansi-full-cutout.png"
                    alt="Mansi - Founder of Social Studio"
                    className="w-[92%] sm:w-[88%] h-auto max-h-full object-contain filter drop-shadow-[0_4px_16px_rgba(255,100,150,0.35)]"
                    loading="eager"
                  />
                </motion.div>

                {/* Bottom Barcode Stamp */}
                <div className="flex items-center justify-between text-[10px] font-bold text-studio-dark/50 pt-2 border-t border-dashed border-studio-dark/20 z-20">
                  <span className="barcode-font font-mono tracking-widest">|||| ||| ||||||| ||</span>
                  <span>EST. 2024 • SOCIAL STUDIO ♡</span>
                </div>
              </div>

              {/* All 7 Floating Stickers surrounding Mansi */}
              {stickers.map((pin) => (
                <div
                  key={pin.id}
                  className={`absolute z-30 select-none cursor-pointer ${pin.rotate}`}
                  style={{
                    top: pin.top,
                    bottom: pin.bottom,
                    left: pin.left,
                    right: pin.right,
                  }}
                  onClick={() => {
                    sound.playPop();
                    setActiveTooltip(activeTooltip === pin.id ? null : pin.id);
                  }}
                >
                  <motion.div
                    whileHover={{ scale: 1.14, rotate: 0 }}
                    whileTap={{ scale: 0.95 }}
                    className={`px-3 py-1.5 rounded-xl font-display font-black text-[10px] sm:text-xs tracking-wider border-2 border-studio-dark shadow-sticker-sm ${pin.bg} sticker-peel flex items-center gap-1.5`}
                  >
                    <span>{pin.label}</span>
                  </motion.div>

                  {/* Tooltip detail bubble on click */}
                  {activeTooltip === pin.id && (
                    <motion.div
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="absolute left-1/2 -translate-x-1/2 top-full mt-2 w-48 p-2.5 rounded-xl bg-studio-dark text-white text-[11px] font-semibold border-2 border-studio-pink shadow-xl z-50 pointer-events-none"
                    >
                      <p>{pin.detail}</p>
                    </motion.div>
                  )}
                </div>
              ))}

              {/* Coffee Cup Sticker */}
              <motion.img
                animate={{ y: [0, -6, 0], rotate: [-2, 2, -2] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                src="/stickers/coffee-cup.png"
                alt="Fueling Dreams Coffee"
                className="absolute -bottom-7 -left-7 w-20 sm:w-24 z-30 filter drop-shadow-md pointer-events-none"
              />

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
