import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Heart, Check, Coffee, Quote, Star, Award, ShieldAlert, Mic } from 'lucide-react';
import { VoicePlayer } from './VoicePlayer';
import { ArrowDoodle, UnderlineScribble, CheckmarkDoodle } from './Doodles';
import { sound } from '../utils/sound';
import { mansiVoice } from '../utils/mansiVoice';

export const Founder: React.FC = () => {
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  useEffect(() => {
    // Keep in sync with the global speech controller
    const unsubscribe = mansiVoice.subscribe({
      onStateChange: (state) => {
        setIsSpeaking(state === 'speaking');
      }
    });
    return () => unsubscribe();
  }, []);

  const notes = [
    { text: "Creative brain ♡", color: "bg-studio-pink-soft text-studio-pink-hot", rotate: "-rotate-6", pos: "top-4 -left-6 sm:-left-12" },
    { text: "Too many ideas 💡", color: "bg-studio-yellow text-studio-dark", rotate: "rotate-6", pos: "top-1/3 -right-6 sm:-right-10" },
    { text: "Always creating ✨", color: "bg-studio-green-soft text-emerald-900", rotate: "-rotate-3", pos: "bottom-24 -left-4 sm:-left-8" },
    { text: "Strategy + Creativity = Impact", color: "bg-studio-purple-soft text-purple-900", rotate: "rotate-4", pos: "-bottom-4 right-2 sm:right-6" },
  ];

  const studioNotes = [
    {
      author: "Mansi's Creative Philosophy",
      quote: "“Your brand should make people stop, look, and feel something real. When you show up with consistency and soul, growth naturally follows.”",
      tag: "Studio Mantra ♡",
      color: "bg-studio-pink-soft",
      rotate: "-rotate-1"
    },
    {
      author: "Core Studio Value",
      quote: "“Good design is not just aesthetic—it communicates who you are before you even say a word. We craft content that feels unmistakably yours.”",
      tag: "Authentic Design ✨",
      color: "bg-studio-yellow-soft",
      rotate: "rotate-2"
    },
  ];

  return (
    <section id="founder" className="relative py-24 sm:py-32 bg-studio-cream-paper border-y-3 border-studio-dark overflow-hidden">
      {/* Subtle dotted background */}
      <div className="absolute inset-0 bg-dot-paper opacity-50 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading Tag */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-studio-yellow border-2 border-studio-dark shadow-sticker-sm text-xs font-black uppercase tracking-wider mb-4">
            <Sparkles className="w-4 h-4 text-studio-dark" />
            <span>FOUNDER & CREATIVE DIRECTOR</span>
          </div>

          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl text-studio-dark tracking-tight uppercase">
            MEET THE MIND BEHIND <br />
            <span className="relative inline-block text-studio-pink font-editorial italic lowercase text-5xl sm:text-7xl font-normal">
              social studio
            </span>
          </h2>
          <UnderlineScribble className="w-48 sm:w-64 mx-auto mt-2 text-studio-pink-hot" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Mansi Cutout with Scrapbook treatment & dynamic audio reactivity */}
          <div className="lg:col-span-5 space-y-8 flex flex-col items-center">
            
            <div className="relative w-full max-w-[380px] sm:max-w-[420px]">
              {/* Backing paper card */}
              <div className="absolute inset-0 bg-white rounded-3xl border-4 border-studio-dark shadow-sticker-lg -rotate-2" />
              <div className="washi-tape washi-tape-pink !top-[-10px] !w-28" />

              {/* Mansi photo cutout framed with subtle pulse animation when speaking */}
              <div
                className={`relative z-10 p-4 sm:p-5 rounded-3xl bg-gradient-to-b from-studio-pink-soft/60 via-white to-studio-cream/80 flex flex-col items-center transition-all duration-500 ${
                  isSpeaking
                    ? 'ring-4 ring-studio-pink/50 shadow-[0_0_40px_rgba(255,100,150,0.35)] scale-[1.01]'
                    : ''
                }`}
              >
                {/* Live audio speaking badge */}
                <AnimatePresence>
                  {isSpeaking && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute top-6 left-6 z-30 flex items-center gap-1.5 px-3 py-1 rounded-full bg-studio-pink text-white text-[11px] font-black uppercase tracking-wider shadow-sticker-sm border-2 border-studio-dark select-none"
                    >
                      <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                      <span>Speaking live ♡</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="relative w-full aspect-[4/5] overflow-hidden rounded-2xl flex items-end justify-center">
                  <img
                    src="/mansi-portrait.png"
                    alt="Mansi - Creative Director of Social Studio"
                    className={`w-full h-full object-contain filter drop-shadow-[0_8px_16px_rgba(20,20,22,0.15)] transition-transform duration-500 ${
                      isSpeaking ? 'scale-105' : 'scale-100'
                    }`}
                    loading="lazy"
                  />
                </div>

                <div className="w-full pt-4 pb-2 text-center border-t-2 border-dashed border-studio-dark/20 mt-3">
                  <p className="font-hand text-2xl font-bold text-studio-dark">
                    Mansi ♡ <span className="text-xs text-studio-pink font-sans font-black uppercase ml-1.5 px-2 py-0.5 rounded-full bg-studio-pink-soft border border-studio-dark">Founder & Strategist</span>
                  </p>
                  <p className="text-xs text-studio-dark/70 font-semibold tracking-wide mt-1">
                    Direct access • No junior account managers
                  </p>
                </div>
              </div>

              {/* Animated Floating Hearts and Stars (Active only while speaking) */}
              <AnimatePresence>
                {isSpeaking && (
                  <>
                    <motion.div
                      initial={{ opacity: 0, scale: 0.4, y: 10 }}
                      animate={{ opacity: [0.8, 1, 0.8], y: [-8, 6, -8], scale: [1, 1.15, 1] }}
                      exit={{ opacity: 0, scale: 0.3 }}
                      transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
                      className="absolute -top-4 -left-4 z-40 text-2xl text-studio-pink pointer-events-none select-none drop-shadow-md"
                    >
                      ♡
                    </motion.div>

                    <motion.div
                      initial={{ opacity: 0, scale: 0.4 }}
                      animate={{ opacity: [0.7, 1, 0.7], y: [6, -6, 6], scale: [1, 1.2, 1] }}
                      exit={{ opacity: 0, scale: 0.3 }}
                      transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut', delay: 0.3 }}
                      className="absolute -top-5 right-12 z-40 text-xl text-amber-400 pointer-events-none select-none drop-shadow-md"
                    >
                      ✨
                    </motion.div>

                    <motion.div
                      initial={{ opacity: 0, scale: 0.4 }}
                      animate={{ opacity: [0.8, 1, 0.8], y: [-6, 6, -6] }}
                      exit={{ opacity: 0, scale: 0.3 }}
                      transition={{ duration: 2.8, repeat: Infinity, ease: 'easeInOut', delay: 0.6 }}
                      className="absolute bottom-28 -right-6 z-40 text-2xl text-studio-pink-hot pointer-events-none select-none drop-shadow-md"
                    >
                      ♡
                    </motion.div>

                    <motion.div
                      initial={{ opacity: 0, scale: 0.4 }}
                      animate={{ opacity: [0.7, 1, 0.7], y: [5, -5, 5] }}
                      exit={{ opacity: 0, scale: 0.3 }}
                      transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut', delay: 0.9 }}
                      className="absolute -bottom-2 -left-3 z-40 text-lg text-studio-yellow pointer-events-none select-none drop-shadow-md"
                    >
                      ⭐
                    </motion.div>
                  </>
                )}
              </AnimatePresence>

              {/* Animated Handwritten Floating Notes */}
              {notes.map((note) => (
                <div
                  key={note.text}
                  onClick={() => sound.playPop()}
                  className={`absolute z-30 px-3.5 py-1.5 rounded-xl font-hand text-lg sm:text-xl font-bold border-2 border-studio-dark shadow-sticker-sm cursor-pointer select-none ${note.color} ${note.rotate} ${note.pos} sticker-peel`}
                >
                  {note.text}
                </div>
              ))}

              {/* Small Sony camera sticker on the corner */}
              <img
                src="/stickers/camera.png"
                alt="Camera sticker"
                className="absolute -top-6 -right-6 w-16 sm:w-20 z-30 filter drop-shadow-md rotate-12"
              />
            </div>

            {/* Studio Philosophy Sticky Notes */}
            <div className="w-full max-w-md space-y-4 pt-4">
              <span className="font-hand text-xl text-studio-dark/70 font-bold block text-center">
                Studio Creative Notes 💌
              </span>
              {studioNotes.map((rev, i) => (
                <div
                  key={i}
                  className={`p-4 rounded-2xl border-2 border-studio-dark shadow-sticker-sm relative ${rev.color} ${rev.rotate}`}
                >
                  <div className="washi-tape washi-tape-yellow !top-[-10px] !w-20" />
                  <p className="font-hand text-lg text-studio-dark font-bold leading-snug">
                    {rev.quote}
                  </p>
                  <div className="flex items-center justify-between pt-2 mt-2 border-t border-studio-dark/15 text-[11px] font-black text-studio-dark/80">
                    <span>{rev.author}</span>
                    <span className="text-studio-pink uppercase">{rev.tag}</span>
                  </div>
                </div>
              ))}
            </div>

          </div>

          {/* Right Column: Personal Story, Voice Dubbing, Core Philosophy */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8">
            
            <div className="space-y-3">
              <span className="font-hand text-2xl sm:text-3xl text-studio-pink font-bold block -rotate-1">
                Hey there! Welcome to my creative world ♡
              </span>
              <h3 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl text-studio-dark tracking-tight leading-tight">
                “Hi, I’m Mansi — the creative mind behind Social Studio.”
              </h3>
            </div>

            <p className="text-lg sm:text-xl text-studio-dark/90 leading-relaxed font-medium">
              I combine <strong className="text-studio-pink font-bold">creativity, content, design and strategy</strong> to help brands build an online presence that actually feels like them.
            </p>

            {/* The Anti-Agency Manifesto Card */}
            <div className="p-5 rounded-2xl bg-white border-3 border-studio-dark shadow-sticker space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-studio-pink" />
                <h4 className="font-display font-black text-sm uppercase tracking-wider text-studio-dark">
                  THE SOCIAL STUDIO PROMISE
                </h4>
              </div>
              <p className="text-sm text-studio-dark/80 font-medium leading-relaxed">
                Most agencies outsource your account to tired interns who churn out lifeless Canva carousels that nobody saves or shares. At Social Studio, I personally direct your strategy, script your hooks, and craft visual identities that make your competitors look obsolete.
              </p>
            </div>

            {/* Voice Dubbing Feature Widget with Live Audio Sync */}
            <div className="pt-2">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-hand text-2xl text-studio-pink font-bold block">
                  Hear from me directly 🎙️
                </span>
                <span className="px-2 py-0.5 rounded-full bg-studio-yellow text-[10px] font-black uppercase text-studio-dark border border-studio-dark">
                  Personal Voice Memo
                </span>
              </div>
              <VoicePlayer onSpeakingChange={setIsSpeaking} />
            </div>

            {/* 4 Pillars of Execution */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {[
                { title: "Direct Collaboration", desc: "You work directly with Mansi, not a rotating chain of middlemen." },
                { title: "Retention-First Editing", desc: "Every video cut and sound hit is engineered for high watch-time." },
                { title: "Bespoke Typography", desc: "No generic templates. Your brand gets its own signature visual DNA." },
                { title: "Community Obsessed", desc: "Turning passive viewers into loyal buyers who champion your brand." },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-white border-2 border-studio-dark shadow-sticker-sm text-xs font-bold text-studio-dark space-y-1"
                >
                  <div className="flex items-center gap-2 text-studio-pink-hot font-black uppercase text-[11px]">
                    <CheckmarkDoodle className="w-4 h-4" />
                    <span>{item.title}</span>
                  </div>
                  <p className="text-studio-dark/75 font-medium leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              ))}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
