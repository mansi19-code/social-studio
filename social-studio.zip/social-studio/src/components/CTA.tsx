import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { UnderlineScribble, ArrowDoodle, SparkleDoodle } from './Doodles';
import { sound } from '../utils/sound';

interface CTAProps {
  onOpenContact: () => void;
}

export const CTA: React.FC<CTAProps> = ({ onOpenContact }) => {
  const triggerConfetti = () => {
    sound.playSparkle();
    confetti({
      particleCount: 140,
      spread: 75,
      origin: { y: 0.6 },
      colors: ['#FF6496', '#FF2A7A', '#FDE047', '#72C29B', '#C084FC']
    });
    onOpenContact();
  };

  // 4 Floating Pink Stickers required by user prompt:
  // "LET'S CREATE ♡", "BIG IDEAS", "GOOD CONTENT", "REAL GROWTH"
  const pinkStickers = [
    { text: "LET’S CREATE ♡", rotate: "-rotate-12", pos: "top-8 left-4 sm:left-12", bg: "bg-studio-pink-hot text-white" },
    { text: "BIG IDEAS", rotate: "rotate-8", pos: "top-14 right-6 sm:right-16", bg: "bg-studio-pink text-white" },
    { text: "GOOD CONTENT", rotate: "-rotate-6", pos: "bottom-12 left-6 sm:left-16", bg: "bg-studio-pink-soft text-studio-pink-hot" },
    { text: "REAL GROWTH", rotate: "rotate-12", pos: "bottom-16 right-4 sm:right-20", bg: "bg-studio-pink text-white" },
  ];

  return (
    <section id="contact" className="relative py-28 sm:py-36 bg-studio-cream bg-grid-paper overflow-hidden border-t-4 border-studio-dark">
      
      {/* Background Soft Pink Glow Aura */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-studio-pink/20 rounded-full blur-[140px] pointer-events-none" />

      {/* Floating Pink Stickers */}
      {pinkStickers.map((badge, i) => (
        <motion.div
          key={badge.text}
          animate={{ y: [0, -8, 0], rotate: [0, 2, 0] }}
          transition={{ duration: 4 + i, repeat: Infinity, ease: 'easeInOut' }}
          className={`hidden sm:inline-block absolute z-20 px-4 py-2 rounded-2xl font-display font-black text-xs sm:text-sm border-3 border-studio-dark shadow-sticker select-none pointer-events-none ${badge.bg} ${badge.rotate} ${badge.pos}`}
        >
          {badge.text}
        </motion.div>
      ))}

      <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10 text-center">
        
        {/* Mansi Photo Cutout Cameo */}
        <div className="relative inline-block mb-6">
          <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-studio-pink-soft border-3 border-studio-dark shadow-sticker overflow-hidden mx-auto flex items-end justify-center">
            <img
              src="/stickers/headshot.png"
              alt="Mansi - Founder of Social Studio"
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </div>
          <div className="absolute -bottom-2 -right-2 bg-studio-yellow px-3.5 py-1 rounded-full border-2 border-studio-dark font-black text-[11px] shadow-sticker-sm rotate-6">
            Mansi is ready! ♡
          </div>
        </div>

        {/* Headline */}
        <h2 className="font-display font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl text-studio-dark uppercase tracking-tight leading-[0.95]">
          READY TO <br />
          <span className="text-studio-pink italic font-editorial font-normal lowercase text-6xl sm:text-8xl md:text-9xl">
            grow your
          </span> <br />
          BRAND?
        </h2>

        <UnderlineScribble className="w-64 sm:w-80 mx-auto mt-4 text-studio-pink-hot" />

        {/* Subtext */}
        <p className="text-lg sm:text-2xl text-studio-dark/85 font-medium max-w-xl mx-auto mt-6 mb-10 leading-relaxed">
          Let’s turn your ideas into content people actually <span className="font-bold underline decoration-studio-pink decoration-wavy">want to see</span>.
        </p>

        {/* Action Button */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={triggerConfetti}
            className="w-full sm:w-auto px-10 py-5 rounded-2xl bg-studio-pink hover:bg-studio-pink-hot text-white font-display font-black text-lg sm:text-xl border-3 border-studio-dark shadow-sticker hover:shadow-sticker-lg hover:-translate-y-1 active:translate-y-0.5 transition-all duration-200 flex items-center justify-center gap-3 group"
          >
            <span>START A PROJECT →</span>
            <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
          </button>
        </div>

        {/* Response Guarantee */}
        <div className="pt-8">
          <p className="font-hand text-xl sm:text-2xl text-studio-dark/70 font-bold">
            Average response time: &lt; 24 hours • Free 20-min discovery call included ♡
          </p>
        </div>

      </div>
    </section>
  );
};
