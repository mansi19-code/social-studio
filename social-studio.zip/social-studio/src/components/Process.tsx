import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Search, Calendar, Wand2, Send, BarChart2, Rocket } from 'lucide-react';
import { UnderlineScribble, ArrowDoodle } from './Doodles';
import { sound } from '../utils/sound';

interface Step {
  num: string;
  title: string;
  tagline: string;
  desc: string;
  icon: React.ReactNode;
  note: string;
  badgeBg: string;
}

export const Process: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);

  const steps: Step[] = [
    {
      num: "01",
      title: "DISCOVER",
      tagline: "Unearthing your true brand voice",
      desc: "We dive deep into your brand identity, current visual gaps, target audience cravings, and competitive whitespace.",
      icon: <Search className="w-5 h-5 text-studio-dark" />,
      note: "Find the vibe ♡",
      badgeBg: "bg-studio-yellow",
    },
    {
      num: "02",
      title: "PLAN",
      tagline: "The strategic content blueprint",
      desc: "We architect your monthly content pillars, scripting frameworks, publishing calendar, and hashtag/keyword systems.",
      icon: <Calendar className="w-5 h-5 text-studio-dark" />,
      note: "Calendar ready 📅",
      badgeBg: "bg-studio-pink-soft",
    },
    {
      num: "03",
      title: "CREATE",
      tagline: "Magic happens on the editing timeline",
      desc: "High-retention reel edits, custom sound design, aesthetic typography, thumbnail covers, and scroll-stopping hooks.",
      icon: <Wand2 className="w-5 h-5 text-studio-dark" />,
      note: "Pure creativity ✨",
      badgeBg: "bg-studio-green-soft",
    },
    {
      num: "04",
      title: "POST",
      tagline: "Seamless scheduling & distribution",
      desc: "Optimized delivery times, engaging first-hour comment strategies, and coordinated story countdown drops.",
      icon: <Send className="w-5 h-5 text-studio-dark" />,
      note: "Send it live 🚀",
      badgeBg: "bg-studio-purple-soft",
    },
    {
      num: "05",
      title: "ANALYZE",
      tagline: "Unpacking what worked and why",
      desc: "Comprehensive monthly performance report: retention curves, share velocity, save ratios, and follower conversions.",
      icon: <BarChart2 className="w-5 h-5 text-studio-dark" />,
      note: "Data + insights 📊",
      badgeBg: "bg-studio-blue-soft",
    },
    {
      num: "06",
      title: "GROW",
      tagline: "Scaling momentum into community",
      desc: "Iterating based on top-performing creative winners to turn fleeting viral spikes into long-term community loyalty.",
      icon: <Rocket className="w-5 h-5 text-studio-dark" />,
      note: "To the moon 🌙",
      badgeBg: "bg-studio-pink",
    },
  ];

  return (
    <section id="process" className="relative py-24 sm:py-32 bg-studio-cream bg-dot-paper overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-studio-pink-soft text-studio-pink-hot border-2 border-studio-dark shadow-sticker-sm text-xs font-black uppercase tracking-wider mb-4">
            <Sparkles className="w-4 h-4" />
            <span>HOW WE OPERATE</span>
          </div>

          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl text-studio-dark tracking-tight uppercase">
            HOW WE MAKE IT <br />
            <span className="relative inline-block text-studio-pink font-editorial italic lowercase text-5xl sm:text-7xl font-normal">
              happen
            </span>
          </h2>
          <UnderlineScribble className="w-52 sm:w-72 mx-auto mt-2 text-studio-pink-hot" />

          {/* Interactive Progress Indicator Ribbon */}
          <div className="flex items-center justify-center gap-2 sm:gap-3 mt-8 flex-wrap">
            {steps.map((st, i) => (
              <button
                key={st.num}
                onClick={() => {
                  sound.playPop();
                  setActiveStep(i);
                }}
                className={`px-3 sm:px-4 py-1.5 rounded-full text-xs font-black tracking-wider transition-all border-2 border-studio-dark ${
                  activeStep === i
                    ? 'bg-studio-pink text-white shadow-sticker-sm -translate-y-0.5'
                    : 'bg-white text-studio-dark/70 hover:bg-studio-pink-soft'
                }`}
              >
                <span>{st.num} — {st.title}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Animated Connecting Timeline */}
        <div className="relative">
          
          {/* Animated Connecting Path for Desktop */}
          <div className="hidden lg:block absolute top-1/2 left-8 right-8 -translate-y-1/2 h-2 z-0 pointer-events-none">
            <div className="w-full h-full bg-studio-dark/15 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-studio-pink"
                initial={{ width: '0%' }}
                whileInView={{ width: '100%' }}
                viewport={{ once: true }}
                transition={{ duration: 1.5, ease: 'easeInOut' }}
              />
            </div>
          </div>

          {/* Steps Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 relative z-10">
            {steps.map((step, idx) => {
              const isActive = activeStep === idx;

              return (
                <motion.div
                  key={step.num}
                  initial={{ opacity: 0, y: 25 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1, duration: 0.4 }}
                  onMouseEnter={() => setActiveStep(idx)}
                  className="relative group cursor-pointer"
                >
                  <div
                    onClick={() => {
                      sound.playPop();
                      setActiveStep(idx);
                    }}
                    className={`p-6 sm:p-7 rounded-3xl border-3 border-studio-dark bg-white shadow-sticker group-hover:shadow-sticker-lg transition-all duration-300 group-hover:-translate-y-2 h-full flex flex-col justify-between ${
                      isActive ? 'ring-4 ring-studio-pink shadow-sticker-lg' : ''
                    }`}
                  >
                    
                    {/* Washi tapes */}
                    {(idx === 0 || idx === 3) && (
                      <div className="washi-tape washi-tape-yellow !top-[-10px] !w-24" />
                    )}
                    {(idx === 2 || idx === 5) && (
                      <div className="washi-tape washi-tape-pink !top-[-10px] !w-24" />
                    )}

                    <div>
                      {/* Top Bar: Step Number & Icon */}
                      <div className="flex items-center justify-between mb-5">
                        <div className="flex items-center gap-2">
                          <span className={`font-display font-black text-3xl sm:text-4xl tracking-tight transition-colors ${
                            isActive ? 'text-studio-pink' : 'text-studio-dark'
                          }`}>
                            {step.num}
                          </span>
                          <span className="text-xs font-bold text-studio-dark/40 uppercase">
                            — STAGE
                          </span>
                        </div>

                        <div className={`p-3 rounded-2xl border-2 border-studio-dark ${step.badgeBg} shadow-sticker-sm group-hover:scale-110 transition-transform`}>
                          {step.icon}
                        </div>
                      </div>

                      <h3 className="font-display font-black text-xl sm:text-2xl text-studio-dark uppercase tracking-tight mb-1 group-hover:text-studio-pink transition-colors">
                        {step.num} — {step.title}
                      </h3>

                      <p className="font-hand text-xl text-studio-dark/75 font-bold mb-3">
                        {step.tagline}
                      </p>

                      <p className="text-xs sm:text-sm text-studio-dark/80 font-medium leading-relaxed">
                        {step.desc}
                      </p>
                    </div>

                    {/* Bottom Doodle Note */}
                    <div className="pt-4 mt-6 border-t-2 border-dashed border-studio-dark/15 flex items-center justify-between">
                      <span className="font-hand text-lg font-bold text-studio-pink">
                        {step.note}
                      </span>
                      <span className="text-[10px] font-black uppercase tracking-widest text-studio-dark/40">
                        Step {step.num}/06
                      </span>
                    </div>

                  </div>
                </motion.div>
              );
            })}
          </div>

        </div>

        {/* Process Guarantee Banner */}
        <div className="mt-14 max-w-2xl mx-auto p-5 rounded-2xl bg-studio-yellow border-3 border-studio-dark shadow-sticker text-center">
          <p className="font-hand text-2xl font-bold text-studio-dark">
            “No ghosting, no endless delays, no guesswork. Just pure creative clarity.” ♡
          </p>
        </div>

      </div>
    </section>
  );
};
