import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  Camera, 
  Smartphone, 
  Check, 
  Coffee, 
  Calendar, 
  Heart, 
  Copy, 
  X,
  PenTool,
  Bookmark
} from 'lucide-react';
import { UnderlineScribble } from './Doodles';
import { sound } from '../utils/sound';

export const CreativeDesk: React.FC = () => {
  const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0 });
  const [cameraActive, setCameraActive] = useState(false);
  const [photoSnapped, setPhotoSnapped] = useState(false);
  const [reelLikes, setReelLikes] = useState(12840);
  const [reelLiked, setReelLiked] = useState(false);
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const [tasks, setTasks] = useState([
    { id: 1, text: "Brainstorm 5 viral hook concepts", done: true },
    { id: 2, text: "Shoot Bloom Café aesthetic B-roll", done: true },
    { id: 3, text: "Edit GlowLab ASMR texture Reel", done: true },
    { id: 4, text: "Client onboarding & strategy call", done: true },
    { id: 5, text: "Design monthly carousel templates", done: true },
    { id: 6, text: "Grow Social Studio ♡", done: true },
  ]);

  const brandSwatches = [
    { name: "Studio Pink", hex: "#FF6496", bg: "bg-[#FF6496]" },
    { name: "Cream Paper", hex: "#FAF6EE", bg: "bg-[#FAF6EE] text-studio-dark" },
    { name: "Matcha Sage", hex: "#72C29B", bg: "bg-[#72C29B]" },
    { name: "Lemon Note", hex: "#FDE047", bg: "bg-[#FDE047] text-studio-dark" },
  ];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 32;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 32;
    setMouseOffset({ x, y });
  };

  const handleSnapPhoto = () => {
    sound.playCamera();
    setPhotoSnapped(true);
    setTimeout(() => {
      setPhotoSnapped(false);
      setCameraActive(true);
    }, 180);
  };

  const toggleTask = (id: number) => {
    sound.playPop();
    const newTasks = tasks.map(t => t.id === id ? { ...t, done: !t.done } : t);
    setTasks(newTasks);
    if (newTasks.every(t => t.done)) {
      sound.playSparkle();
    }
  };

  const copyHex = (hex: string) => {
    sound.playPop();
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 1800);
  };

  const toggleReelLike = () => {
    sound.playPop();
    if (!reelLiked) {
      setReelLikes(prev => prev + 1);
      setReelLiked(true);
    } else {
      setReelLikes(prev => prev - 1);
      setReelLiked(false);
    }
  };

  // 5 Handwritten Notes required by prompt: PLAN, CREATE, POST, REPEAT, GROW
  const deskNotes = [
    { text: "PLAN 📝", bg: "bg-studio-yellow text-studio-dark", rotate: "-rotate-6", style: { top: "4%", left: "4%" }, speed: 0.7 },
    { text: "CREATE ✨", bg: "bg-studio-pink text-white", rotate: "rotate-6", style: { top: "5%", right: "6%" }, speed: 0.5 },
    { text: "POST 🚀", bg: "bg-studio-green-soft text-emerald-950", rotate: "-rotate-3", style: { bottom: "4%", left: "26%" }, speed: 0.8 },
    { text: "REPEAT ↻", bg: "bg-studio-purple-soft text-purple-950", rotate: "rotate-4", style: { bottom: "5%", right: "24%" }, speed: 0.6 },
    { text: "GROW ♡", bg: "bg-studio-pink-hot text-white", rotate: "-rotate-8", style: { top: "46%", left: "0%" }, speed: 0.85 },
  ];

  return (
    <section
      id="creative-desk"
      onMouseMove={handleMouseMove}
      className="relative py-24 sm:py-32 bg-[#19191E] text-white border-y-4 border-studio-dark overflow-hidden"
    >
      {/* Viewfinder Flash Overlay */}
      {photoSnapped && (
        <div className="fixed inset-0 bg-white z-[9999] pointer-events-none opacity-90 transition-opacity duration-150" />
      )}

      {/* Atmospheric lighting glows */}
      <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-studio-pink/15 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-studio-green/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-studio-pink text-white border-2 border-white shadow-sticker-sm text-xs font-black uppercase tracking-wider mb-4">
            <Sparkles className="w-4 h-4 animate-wiggle" />
            <span>INTERACTIVE WORKSTATION</span>
          </div>

          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl text-white tracking-tight uppercase">
            MY CREATIVE <br />
            <span className="relative inline-block text-studio-pink font-editorial italic lowercase text-5xl sm:text-7xl font-normal">
              desk setup
            </span>
          </h2>
          <UnderlineScribble className="w-48 sm:w-64 mx-auto mt-2 text-studio-pink" />
          
          <p className="text-sm sm:text-base text-white/70 font-medium max-w-xl mx-auto mt-4">
            Glide your cursor across Mansi’s physical workspace. Snap a 4K photo, test the live Reel, inspect notebooks, grab brand swatches, and tick off the daily agenda.
          </p>
        </div>

        {/* The Digital Desk Stage */}
        <div className="relative max-w-6xl mx-auto bg-[#23232A] rounded-3xl sm:rounded-[40px] border-4 border-studio-pink/40 shadow-2xl p-6 sm:p-10 overflow-hidden">
          
          <div className="absolute inset-0 bg-dot-paper opacity-20 pointer-events-none" />

          {/* 3-Column Desk Setup Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-20">
            
            {/* Left Column: Camera + Notebook Stack + Brand Swatches */}
            <div className="lg:col-span-4 space-y-6">
              
              {/* Sony Camera Interactive Card */}
              <motion.div
                style={{
                  transform: `translate(${mouseOffset.x * 0.45}px, ${mouseOffset.y * 0.45}px)`
                }}
                whileHover={{ scale: 1.02 }}
                onClick={handleSnapPhoto}
                className="p-5 rounded-3xl bg-white text-studio-dark border-3 border-studio-dark shadow-sticker cursor-pointer relative overflow-hidden group"
              >
                <div className="washi-tape washi-tape-pink !top-[-10px] !w-24" />
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-studio-pink-soft flex items-center justify-center border border-studio-dark">
                      <Camera className="w-4 h-4 text-studio-pink-hot" />
                    </div>
                    <span className="font-extrabold text-xs uppercase tracking-wider">Sony Alpha 4K</span>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-red-100 text-red-600 text-[10px] font-black animate-pulse">
                    READY ●
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <img
                    src="/stickers/camera.png"
                    alt="Camera"
                    className="w-16 h-14 object-contain group-hover:rotate-6 transition-transform"
                  />
                  <div>
                    <p className="font-hand text-lg font-bold text-studio-dark leading-tight">
                      “Click to snap B-roll shot”
                    </p>
                    <p className="text-[11px] font-bold text-studio-pink mt-1">
                      📸 Tap for real shutter snap!
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* Physical Notebook & Planner Stack */}
              <motion.div
                style={{
                  transform: `translate(${mouseOffset.x * 0.3}px, ${mouseOffset.y * 0.3}px)`
                }}
                className="p-4 rounded-3xl bg-[#2C2C36] border-2 border-white/20 text-white flex items-center gap-4"
              >
                <img
                  src="/stickers/notebook-stack.png"
                  alt="Notebook stack"
                  className="w-16 h-16 object-contain filter drop-shadow-md shrink-0"
                />
                <div>
                  <div className="flex items-center gap-1.5 text-studio-yellow text-xs font-black uppercase">
                    <PenTool className="w-3.5 h-3.5" />
                    <span>Ideas Notebook & Pens</span>
                  </div>
                  <p className="font-hand text-lg text-white font-bold leading-tight mt-0.5">
                    “Never let a good hook slip away” ♡
                  </p>
                </div>
              </motion.div>

              {/* Brand Palette Swatches */}
              <div className="p-4 sm:p-5 rounded-3xl bg-[#2D2D36] border-2 border-white/20 text-white space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-black uppercase tracking-wider text-studio-pink">
                    Studio Brand DNA Swatches
                  </span>
                  {copiedHex && (
                    <span className="text-[10px] font-bold text-emerald-400 animate-pulse">
                      Copied {copiedHex}!
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {brandSwatches.map((swatch) => (
                    <button
                      key={swatch.hex}
                      onClick={() => copyHex(swatch.hex)}
                      className={`p-2.5 rounded-xl border border-white/20 text-left transition-all hover:scale-105 active:scale-95 ${swatch.bg}`}
                    >
                      <span className="text-[10px] font-black uppercase block leading-tight">
                        {swatch.name}
                      </span>
                      <span className="text-[11px] font-mono font-bold opacity-80 flex items-center justify-between">
                        <span>{swatch.hex}</span>
                        <Copy className="w-3 h-3 opacity-60" />
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Coffee Fuel Cup */}
              <motion.div
                style={{
                  transform: `translate(${mouseOffset.x * 0.65}px, ${mouseOffset.y * 0.65}px)`
                }}
                className="p-4 rounded-2xl bg-studio-yellow text-studio-dark border-3 border-studio-dark shadow-sticker flex items-center gap-3 relative"
              >
                <div className="relative">
                  <img
                    src="/stickers/coffee-cup.png"
                    alt="Coffee Cup"
                    className="w-10 h-14 object-contain"
                  />
                  <span className="absolute -top-2 left-2 w-1.5 h-1.5 bg-studio-dark/40 rounded-full animate-ping" />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-studio-dark/60 block">Fueling Big Dreams</span>
                  <p className="font-hand text-lg font-bold leading-tight">
                    Iced Oat Matcha Latte ♡
                  </p>
                </div>
              </motion.div>

            </div>

            {/* Center Column: Mansi at Desk + Laptop + Parallax Stickers */}
            <div className="lg:col-span-4 relative flex flex-col items-center justify-center my-6 lg:my-0">
              <motion.div
                style={{
                  transform: `translate(${mouseOffset.x * 0.2}px, ${mouseOffset.y * 0.2}px)`
                }}
                className="relative w-full max-w-[340px] sm:max-w-[400px] flex items-center justify-center"
              >
                <img
                  src="/mansi-full-cutout.png"
                  alt="Mansi at Creative Desk with Laptop"
                  className="w-full h-auto object-contain filter drop-shadow-[0_15px_30px_rgba(255,100,150,0.25)] select-none"
                  loading="lazy"
                />

                <div className="absolute -top-3 right-4 bg-studio-pink text-white px-3 py-1 rounded-full text-xs font-black border-2 border-white shadow-sticker-sm select-none">
                  MANSI'S DESK ♡
                </div>

                {/* Laptop Doodle Sticker */}
                <motion.img
                  src="/stickers/laptop-doodle.png"
                  alt="Laptop"
                  style={{
                    transform: `translate(${mouseOffset.x * 0.35}px, ${mouseOffset.y * 0.35}px)`
                  }}
                  className="absolute -bottom-4 -left-6 w-24 sm:w-28 filter drop-shadow-lg z-20 pointer-events-none"
                />

                {/* Social Media Icons Sticker */}
                <motion.img
                  src="/stickers/social-icons.png"
                  alt="Social Icons"
                  style={{
                    transform: `translate(${mouseOffset.x * 0.5}px, ${mouseOffset.y * 0.5}px)`
                  }}
                  className="absolute -top-6 -left-4 w-16 sm:w-20 filter drop-shadow-md z-20 pointer-events-none rotate-12"
                />
              </motion.div>
            </div>

            {/* Right Column: Live Reel Simulator + Daily Content Agenda Calendar */}
            <div className="lg:col-span-4 space-y-6">
              
              {/* iPhone 16 Pro Live Reel Simulator */}
              <motion.div
                style={{
                  transform: `translate(${mouseOffset.x * 0.55}px, ${mouseOffset.y * 0.55}px)`
                }}
                className="p-4 rounded-3xl bg-white text-studio-dark border-3 border-studio-dark shadow-sticker space-y-3"
              >
                <div className="flex items-center justify-between text-xs font-bold border-b border-studio-dark/15 pb-2">
                  <div className="flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 text-studio-pink" />
                    <span className="font-display font-black uppercase text-[11px]">Live Reel Simulator</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-studio-pink-soft text-studio-pink-hot text-[10px] font-bold">
                    Viral Audio 🎵
                  </span>
                </div>

                <div className="relative rounded-2xl overflow-hidden bg-studio-dark text-white p-3 aspect-[16/10] flex flex-col justify-between">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-studio-pink" />
                      @socialstudio.creative
                    </span>
                    <span className="text-[10px] text-white/70">Sponsored</span>
                  </div>

                  <div className="space-y-1">
                    <p className="font-hand text-lg text-studio-yellow leading-tight">
                      “3 seconds to stop the scroll. Here’s how we did it...”
                    </p>
                    <p className="text-[10px] text-white/70">
                      Tap heart to test interactive engagement!
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-white/10 text-xs">
                    <button
                      onClick={toggleReelLike}
                      className="flex items-center gap-1.5 text-xs font-bold hover:text-studio-pink transition-colors"
                    >
                      <Heart className={`w-4 h-4 ${reelLiked ? 'fill-studio-pink text-studio-pink' : 'text-white'}`} />
                      <span>{reelLikes.toLocaleString()}</span>
                    </button>
                    <span className="text-[10px] text-white/80">3,490 shares</span>
                  </div>
                </div>
              </motion.div>

              {/* Daily Content Calendar & Agenda Checklist */}
              <div className="p-5 rounded-3xl bg-studio-cream text-studio-dark border-3 border-studio-dark shadow-sticker relative">
                <div className="washi-tape washi-tape-yellow !top-[-10px] !w-24" />
                
                <div className="flex items-center justify-between border-b-2 border-studio-dark/20 pb-3 mb-3">
                  <div>
                    <span className="font-hand text-2xl font-bold text-studio-dark">Content Calendar:</span>
                    <p className="text-[10px] font-bold text-studio-dark/60 uppercase">
                      Studio Task Priority
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-studio-pink-soft border border-studio-dark text-xs font-black text-studio-pink-hot">
                    {tasks.filter(t => t.done).length}/{tasks.length} Done
                  </span>
                </div>

                <div className="space-y-2">
                  {tasks.map((task) => (
                    <button
                      key={task.id}
                      onClick={() => toggleTask(task.id)}
                      className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-bold transition-all ${
                        task.done
                          ? 'bg-studio-green-soft/80 text-emerald-950 line-through decoration-studio-pink decoration-2'
                          : 'bg-white hover:bg-studio-cream-paper text-studio-dark'
                      } border border-studio-dark/20`}
                    >
                      <div className={`w-4 h-4 rounded border-2 border-studio-dark flex items-center justify-center shrink-0 ${task.done ? 'bg-studio-green' : 'bg-white'}`}>
                        {task.done && <Check className="w-3 h-3 text-studio-dark stroke-[3]" />}
                      </div>
                      <span className="font-hand text-base leading-none">{task.text}</span>
                    </button>
                  ))}
                </div>

                <p className="text-[10px] text-center font-bold text-studio-dark/50 mt-3">
                  Click any item to check off with sound feedback!
                </p>
              </div>

            </div>

          </div>

          {/* 5 Floating Handwritten Notes: PLAN, CREATE, POST, REPEAT, GROW */}
          {deskNotes.map((note, idx) => (
            <motion.div
              key={idx}
              style={{
                ...note.style,
                transform: `translate(${mouseOffset.x * note.speed}px, ${mouseOffset.y * note.speed}px)`
              }}
              whileHover={{ scale: 1.15, rotate: 0 }}
              onClick={() => sound.playPop()}
              className={`hidden md:flex absolute z-30 px-3.5 py-1.5 rounded-xl font-hand text-lg font-bold border-2 border-studio-dark shadow-sticker-sm cursor-pointer select-none ${note.bg} ${note.rotate} sticker-peel items-center gap-1`}
            >
              <span>{note.text}</span>
            </motion.div>
          ))}

        </div>

      </div>

      {/* Camera Snapshot Preview Modal */}
      <AnimatePresence>
        {cameraActive && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-studio-dark/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="relative p-6 bg-white text-studio-dark rounded-3xl border-4 border-studio-dark shadow-2xl max-w-sm text-center space-y-4"
            >
              <div className="washi-tape washi-tape-pink !top-[-10px] !w-24" />
              <button
                onClick={() => setCameraActive(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full border border-studio-dark hover:bg-studio-pink-soft"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="p-3 bg-studio-cream rounded-2xl border-2 border-studio-dark">
                <img
                  src="/mansi-portrait.png"
                  alt="Snapshot"
                  className="w-full aspect-square object-contain"
                />
              </div>

              <div>
                <p className="font-hand text-2xl font-bold text-studio-dark">
                  “Shot on Sony Alpha 4K” ♡
                </p>
                <p className="text-xs text-studio-dark/70 font-semibold mt-1">
                  1/250s • f/1.8 • ISO 200 • High Retention Studio Lighting
                </p>
              </div>

              <button
                onClick={() => {
                  sound.playPop();
                  setCameraActive(false);
                }}
                className="w-full py-2.5 rounded-xl bg-studio-pink text-white font-black text-xs uppercase border-2 border-studio-dark shadow-sticker-sm"
              >
                Close Snapshot →
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </section>
  );
};
