import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  ArrowUpRight, 
  X, 
  ExternalLink, 
  Heart, 
  TrendingUp, 
  Image as ImageIcon,
  CheckCircle2,
  Crown
} from 'lucide-react';
import { UnderlineScribble, ArrowDoodle, SparkleDoodle } from './Doodles';
import { sound } from '../utils/sound';
import { projects, CATEGORIES, Project } from '../data/projects';
import { AnnapurnaCaseStudyModal } from './AnnapurnaCaseStudyModal';

interface PortfolioProps {
  onOpenContact?: () => void;
}

// 3D Tilt Portfolio Card
const TiltPortfolioCard: React.FC<{
  project: Project;
  idx: number;
  onSelect: (p: Project) => void;
}> = ({ project, idx, onSelect }) => {
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [imgError, setImgError] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    const rotX = ((y - centerY) / centerY) * -6;
    const rotY = ((x - centerX) / centerX) * 6;
    setRotateX(rotX);
    setRotateY(rotY);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
  };

  const isAnnapurna = project.id === 'annapurna-events';
  const isLarge = idx === 0 || idx === 1 || idx === 5 || idx === 6;
  const colSpan = isLarge ? "lg:col-span-6" : "lg:col-span-4";
  const defaultRotation = idx % 2 === 0 ? "-rotate-0.5" : "rotate-0.5";

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4 }}
      className={`${colSpan} group`}
      style={{ perspective: 1000 }}
    >
      <motion.div
        animate={{
          rotateX,
          rotateY,
          transformStyle: 'preserve-3d',
        }}
        transition={{ type: 'spring', damping: 20, stiffness: 300, mass: 0.1 }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onClick={() => {
          sound.playPop();
          onSelect(project);
        }}
        data-cursor="view"
        className={`relative bg-studio-cream rounded-3xl border-3 border-studio-dark shadow-sticker group-hover:shadow-sticker-lg transition-all duration-300 p-4 sm:p-5 flex flex-col justify-between cursor-pointer ${defaultRotation} group-hover:scale-[1.01]`}
      >
        {/* Washi Tape on top */}
        <div className="washi-tape washi-tape-pink !top-[-10px] !w-24 opacity-0 group-hover:opacity-100 transition-opacity" />

        {/* Category Sticker Badge */}
        <div className="absolute top-7 left-7 z-20 px-3 py-1 rounded-full bg-white/95 backdrop-blur-sm border-2 border-studio-dark font-black text-[11px] uppercase tracking-wider text-studio-dark shadow-sticker-sm flex items-center gap-1.5 group-hover:scale-105 transition-transform">
          <span className="w-2 h-2 rounded-full bg-studio-pink animate-pulse" />
          <span>{project.category}</span>
        </div>

        {/* Result or Visual Direction Badge */}
        {project.result && (
          <div
            className={`absolute top-7 right-7 z-20 px-3 py-1 rounded-full border-2 border-studio-dark font-black text-[11px] uppercase tracking-wider shadow-sticker-sm flex items-center gap-1 group-hover:scale-105 transition-transform ${
              isAnnapurna ? 'bg-[#F5EAD4] text-amber-950' : 'bg-studio-yellow text-studio-dark'
            }`}
          >
            {isAnnapurna ? (
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
            ) : (
              <TrendingUp className="w-3.5 h-3.5 text-studio-dark" />
            )}
            <span>{project.result}</span>
          </div>
        )}

        {/* Project Image Frame with Zoom */}
        <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden border-2 border-studio-dark/20 mb-5 bg-studio-cream-paper flex items-center justify-center">
          {project.coverImage && !imgError ? (
            <img
              src={project.coverImage}
              alt={project.title}
              onError={() => setImgError(true)}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108"
              loading="lazy"
            />
          ) : isAnnapurna ? (
            /* Clean Champagne Luxury preview artwork for Annapurna Events when assets are awaiting upload */
            <div className="w-full h-full p-6 bg-gradient-to-br from-[#FFFDF9] via-[#FAF6EE] to-[#F5EAD4] flex flex-col items-center justify-center text-center space-y-3 relative overflow-hidden group-hover:scale-105 transition-transform duration-500">
              <div className="washi-tape washi-tape-yellow !top-[-10px] !w-24" />
              <div className="w-14 h-14 rounded-2xl bg-white border-2 border-studio-dark shadow-sticker-sm flex items-center justify-center">
                <Crown className="w-7 h-7 text-amber-700" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-300">
                  Champagne Luxury Direction
                </span>
                <h4 className="font-display font-black text-xl text-studio-dark uppercase mt-1.5">
                  Annapurna Events
                </h4>
                <p className="font-editorial italic text-sm text-studio-dark/80 mt-0.5">
                  Weddings • Celebrations • Decor • Corporate
                </p>
              </div>
              <span className="text-[10px] font-mono text-studio-dark/60 bg-white/70 px-2 py-0.5 rounded border border-studio-dark/20">
                📁 /public/portfolio/annapurna-events/
              </span>
            </div>
          ) : (
            <img
              src="/portfolio/portfolio_social_reels.jpg"
              alt={project.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108"
              loading="lazy"
            />
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-studio-dark/75 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
            <span className="text-white text-xs font-bold font-hand text-xl">
              {isAnnapurna ? "Tap to view full case study & gallery →" : "Tap to view full case study & results →"}
            </span>
          </div>
        </div>

        {/* Project Meta Details */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-studio-pink uppercase tracking-widest">
              {project.client || "Client Retainer"}
            </span>
            <div className="w-8 h-8 rounded-full bg-white border-2 border-studio-dark flex items-center justify-center group-hover:bg-studio-pink group-hover:text-white transition-all duration-300 group-hover:rotate-45">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>

          <h3 className="font-display font-black text-2xl text-studio-dark uppercase tracking-tight group-hover:text-studio-pink transition-colors">
            {project.title}
          </h3>

          <p className="text-sm text-studio-dark/75 font-medium line-clamp-2">
            {project.description}
          </p>
        </div>

        {/* Deliverables tags */}
        <div className="flex flex-wrap gap-1.5 pt-4 mt-3 border-t-2 border-dashed border-studio-dark/15">
          {project.services.slice(0, 4).map((d) => (
            <span
              key={d}
              className="px-2.5 py-0.5 rounded-md bg-white border border-studio-dark/20 text-[10px] font-bold text-studio-dark/80"
            >
              {d}
            </span>
          ))}
          {project.services.length > 4 && (
            <span className="px-2 py-0.5 rounded-md bg-studio-pink-soft text-studio-pink-hot border border-studio-pink/30 text-[10px] font-bold">
              +{project.services.length - 4} more
            </span>
          )}
        </div>

      </motion.div>
    </motion.div>
  );
};

export const Portfolio: React.FC<PortfolioProps> = ({ onOpenContact }) => {
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const filteredProjects = activeCategory === 'ALL'
    ? projects
    : projects.filter(
        p => p.category === activeCategory || p.additionalCategories?.includes(activeCategory as any)
      );

  const isAnnapurnaSelected = selectedProject?.id === 'annapurna-events';

  return (
    <section id="portfolio" className="relative py-24 sm:py-32 bg-white border-y-3 border-studio-dark overflow-hidden">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 sm:mb-16">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-studio-pink-soft text-studio-pink-hot border-2 border-studio-dark shadow-sticker-sm text-xs font-black uppercase tracking-wider mb-4">
              <Sparkles className="w-4 h-4" />
              <span>SELECTED CREATIVE ARCHIVE</span>
            </div>

            <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl text-studio-dark tracking-tight uppercase">
              THINGS WE’VE <br />
              <span className="relative inline-block text-studio-pink font-editorial italic lowercase text-5xl sm:text-7xl font-normal">
                made ♡
              </span>
            </h2>
            <UnderlineScribble className="w-48 sm:w-60 mt-2 text-studio-pink-hot" />
          </div>

          {/* Right hand note */}
          <div className="relative p-4 rounded-2xl bg-studio-yellow border-2 border-studio-dark shadow-sticker-sm rotate-2 max-w-xs">
            <div className="washi-tape washi-tape-pink !top-[-10px] !w-20" />
            <p className="font-hand text-xl font-bold text-studio-dark leading-tight">
              “Every project is built from scratch with soul, strategy and style!”
            </p>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-12">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                sound.playClick();
                setActiveCategory(cat);
              }}
              className={`px-4 sm:px-5 py-2 rounded-full font-display font-black text-xs uppercase tracking-wider border-2 border-studio-dark transition-all duration-200 ${
                activeCategory === cat
                  ? 'bg-studio-pink text-white shadow-sticker-sm -translate-y-0.5'
                  : 'bg-studio-cream hover:bg-white text-studio-dark shadow-[2px_2px_0px_#141416]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Editorial Masonry Grid with 3D Tilt */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-10">
          {filteredProjects.map((project, idx) => (
            <TiltPortfolioCard
              key={project.id}
              project={project}
              idx={idx}
              onSelect={setSelectedProject}
            />
          ))}
        </div>

      </div>

      {/* Dedicated Annapurna Events Case Study Modal */}
      <AnnapurnaCaseStudyModal
        isOpen={isAnnapurnaSelected}
        onClose={() => setSelectedProject(null)}
        onOpenContact={() => {
          setSelectedProject(null);
          if (onOpenContact) {
            onOpenContact();
          } else {
            const el = document.getElementById('contact');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }
        }}
      />

      {/* Case Study Interactive Modal for Other Projects */}
      <AnimatePresence>
        {selectedProject && !isAnnapurnaSelected && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-studio-dark/75 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-3xl bg-studio-cream rounded-3xl border-4 border-studio-dark shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto"
            >
              <div className="washi-tape washi-tape-pink !top-[-12px] !w-32" />
              
              <button
                onClick={() => {
                  sound.playClick();
                  setSelectedProject(null);
                }}
                className="absolute top-5 right-5 p-2 rounded-full bg-white border-2 border-studio-dark shadow-sticker-sm hover:bg-studio-pink hover:text-white transition-colors"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 rounded-full bg-studio-yellow border-2 border-studio-dark text-xs font-black uppercase tracking-wider text-studio-dark shadow-sticker-sm">
                      {selectedProject.category}
                    </span>
                    {selectedProject.client && (
                      <span className="text-xs font-bold text-studio-dark/60 font-sans">
                        Client: {selectedProject.client} {selectedProject.date ? `• ${selectedProject.date}` : ''}
                      </span>
                    )}
                  </div>
                  
                  <h3 className="font-display font-black text-3xl sm:text-4xl text-studio-dark uppercase">
                    {selectedProject.title}
                  </h3>
                </div>

                {/* Cover Image */}
                <div className="relative rounded-2xl overflow-hidden border-3 border-studio-dark shadow-sticker min-h-[260px] bg-white flex items-center justify-center">
                  <img
                    src={selectedProject.coverImage || '/portfolio/portfolio_social_reels.jpg'}
                    alt={selectedProject.title}
                    className="w-full max-h-[380px] object-contain"
                  />

                  {selectedProject.result && (
                    <div className="absolute bottom-4 right-4 bg-studio-pink text-white px-4 py-1.5 rounded-full border-2 border-studio-dark font-black text-xs shadow-sticker-sm">
                      {selectedProject.result}
                    </div>
                  )}
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <h4 className="font-display font-black text-sm uppercase tracking-wider text-studio-dark">
                    Overview & Strategy
                  </h4>
                  <p className="text-sm sm:text-base text-studio-dark/80 font-medium leading-relaxed">
                    {selectedProject.description}
                  </p>
                </div>

                {/* Services */}
                <div className="space-y-2">
                  <h4 className="font-display font-black text-sm uppercase tracking-wider text-studio-dark">
                    Services Delivered
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {selectedProject.services.map((srv, i) => (
                      <div
                        key={i}
                        className="p-2.5 rounded-xl bg-white border border-studio-dark/20 text-xs font-bold text-studio-dark flex items-center gap-2"
                      >
                        <Heart className="w-3.5 h-3.5 text-studio-pink fill-studio-pink shrink-0" />
                        <span>{srv}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer Action */}
                <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t-2 border-dashed border-studio-dark/20">
                  <span className="font-hand text-xl font-bold text-studio-dark/70">
                    Want content like this for your brand?
                  </span>
                  <button
                    onClick={() => {
                      sound.playSparkle();
                      setSelectedProject(null);
                      if (onOpenContact) {
                        onOpenContact();
                      } else {
                        const el = document.getElementById('contact');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className="px-6 py-3 rounded-2xl bg-studio-pink hover:bg-studio-pink-hot text-white font-black text-xs uppercase tracking-wider border-2 border-studio-dark shadow-sticker hover:shadow-sticker-lg transition-all"
                  >
                    Start a project with Mansi →
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </section>
  );
};
