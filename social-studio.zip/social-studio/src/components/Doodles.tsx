import React from 'react';

export const HeartDoodle: React.FC<{ className?: string }> = ({ className = "w-6 h-6 text-studio-pink" }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
  </svg>
);

export const StarDoodle: React.FC<{ className?: string }> = ({ className = "w-6 h-6 text-studio-yellow" }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M12 1.5l2.7 6.8 7.3.6-5.5 4.8 1.6 7.2L12 17.1l-6.1 3.8 1.6-7.2-5.5-4.8 7.3-.6L12 1.5z" />
  </svg>
);

export const SparkleDoodle: React.FC<{ className?: string }> = ({ className = "w-6 h-6 text-studio-pink" }) => (
  <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" className={className}>
    <path d="M16 2v28M2 16h28M6 6l20 20M6 26L26 6" />
  </svg>
);

export const ArrowDoodle: React.FC<{ className?: string; direction?: 'right' | 'down' | 'curved' | 'up' }> = ({ className = "w-12 h-12 text-studio-dark", direction = 'curved' }) => {
  if (direction === 'curved') {
    return (
      <svg viewBox="0 0 100 60" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M10 45 C 30 10, 70 10, 85 35" />
        <path d="M72 35 L 87 35 L 85 20" />
      </svg>
    );
  }
  if (direction === 'right') {
    return (
      <svg viewBox="0 0 60 30" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M5 15 Q 30 10, 50 15" />
        <path d="M40 8 L 52 15 L 40 22" />
      </svg>
    );
  }
  if (direction === 'down') {
    return (
      <svg viewBox="0 0 40 60" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M20 5 Q 15 30, 20 50" />
        <path d="M10 40 L 20 52 L 30 40" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 60 60" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" className={className}>
      <path d="M10 50 Q 30 20, 48 12" />
      <path d="M35 12 L 50 10 L 48 25" />
    </svg>
  );
};

export const UnderlineScribble: React.FC<{ className?: string }> = ({ className = "w-full h-4 text-studio-pink" }) => (
  <svg viewBox="0 0 200 16" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" className={className} preserveAspectRatio="none">
    <path d="M3 11 C 45 4, 120 15, 197 7 C 150 14, 80 12, 35 13" />
  </svg>
);

export const CheckmarkDoodle: React.FC<{ className?: string }> = ({ className = "w-6 h-6 text-studio-green" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M5 13l4 4L19 7" />
  </svg>
);
