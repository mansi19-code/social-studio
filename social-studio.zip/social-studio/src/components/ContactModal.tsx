import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles, Send, CheckCircle2, Heart } from 'lucide-react';
import confetti from 'canvas-confetti';
import { UnderlineScribble } from './Doodles';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedPackage?: string;
}

export const ContactModal: React.FC<ContactModalProps> = ({
  isOpen,
  onClose,
  preselectedPackage = ""
}) => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    brandType: 'Creator / Personal Brand',
    services: [] as string[],
    package: preselectedPackage || 'GROWTH (₹14,500/mo)',
    message: '',
  });

  const serviceOptions = [
    'Content Creation',
    'Graphic Design',
    'Social Media Strategy',
    'Copywriting',
    'Performance Marketing',
    'Website Building',
    'Reels / Shorts Direction',
    'Full Monthly Management',
  ];

  const brandTypes = [
    'Creator / Personal Brand',
    'Café / Restaurant',
    'Local Business',
    'Coach / Consultant',
    'Educational Brand',
    'E-Commerce / Retail',
  ];

  const toggleService = (srv: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(srv)
        ? prev.services.filter(s => s !== srv)
        : [...prev.services, srv]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    confetti({
      particleCount: 150,
      spread: 80,
      origin: { y: 0.6 }
    });
    setSubmitted(true);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-studio-dark/75 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-2xl bg-studio-cream rounded-3xl border-4 border-studio-dark shadow-2xl p-6 sm:p-8 my-8 max-h-[90vh] overflow-y-auto"
      >
        <div className="washi-tape washi-tape-pink !top-[-12px] !w-32" />

        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white border-2 border-studio-dark shadow-sticker-sm hover:bg-studio-pink hover:text-white transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="text-center py-12 space-y-4">
            <div className="w-20 h-20 bg-studio-green-soft rounded-full border-3 border-studio-dark flex items-center justify-center mx-auto shadow-sticker">
              <CheckCircle2 className="w-10 h-10 text-emerald-700 stroke-[2.5]" />
            </div>

            <h3 className="font-display font-black text-3xl sm:text-4xl text-studio-dark uppercase">
              Message Received! ♡
            </h3>

            <p className="font-hand text-2xl text-studio-pink font-bold">
              “Thank you for reaching out! Mansi will get back to you within 24 hours.”
            </p>

            <p className="text-sm text-studio-dark/70 font-medium max-w-md mx-auto">
              We’re already dreaming up scroll-stopping ideas for your brand. Check your email for our initial questionnaire and scheduling link!
            </p>

            <button
              onClick={() => {
                setSubmitted(false);
                onClose();
              }}
              className="mt-6 px-8 py-3 rounded-2xl bg-studio-pink hover:bg-studio-pink-hot text-white font-black text-sm uppercase tracking-wider border-2 border-studio-dark shadow-sticker"
            >
              Back to Studio →
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-studio-yellow border-2 border-studio-dark text-[10px] font-black uppercase tracking-wider text-studio-dark shadow-sticker-sm mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>START YOUR PROJECT</span>
              </div>
              
              <h3 className="font-display font-black text-2xl sm:text-4xl text-studio-dark uppercase">
                LET’S MAKE SOMETHING <br />
                <span className="text-studio-pink font-editorial italic lowercase text-4xl sm:text-5xl font-normal">
                  memorable ♡
                </span>
              </h3>
              <p className="text-xs sm:text-sm text-studio-dark/70 font-medium mt-1">
                Tell Mansi about your brand, what you need, and your vision.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-black uppercase text-studio-dark">Your Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Maya Sharma"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-white border-2 border-studio-dark text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-studio-pink"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-black uppercase text-studio-dark">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="e.g. maya@brand.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-white border-2 border-studio-dark text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-studio-pink"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-black uppercase text-studio-dark">Brand Type</label>
                  <select
                    value={formData.brandType}
                    onChange={(e) => setFormData({ ...formData, brandType: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-white border-2 border-studio-dark text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-studio-pink"
                  >
                    {brandTypes.map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-black uppercase text-studio-dark">Desired Package</label>
                  <select
                    value={formData.package}
                    onChange={(e) => setFormData({ ...formData, package: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-white border-2 border-studio-dark text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-studio-pink"
                  >
                    <option value="STARTER (₹8,500/mo)">STARTER — ₹8,500/mo</option>
                    <option value="GROWTH (₹14,500/mo)">GROWTH — ₹14,500/mo (Recommended)</option>
                    <option value="PREMIUM (₹25,000/mo)">PREMIUM — ₹25,000/mo</option>
                    <option value="Custom Project">Custom Project / Retainer</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase text-studio-dark">What do you need help with?</label>
                <div className="flex flex-wrap gap-2">
                  {serviceOptions.map((srv) => (
                    <button
                      type="button"
                      key={srv}
                      onClick={() => toggleService(srv)}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold border border-studio-dark transition-all ${
                        formData.services.includes(srv)
                          ? 'bg-studio-pink text-white shadow-sticker-sm'
                          : 'bg-white hover:bg-studio-pink-soft text-studio-dark'
                      }`}
                    >
                      {srv}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black uppercase text-studio-dark">Tell Mansi about your vision *</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Tell us about your brand, current challenges, and goals..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white border-2 border-studio-dark text-sm font-medium focus:outline-none focus:ring-2 focus:ring-studio-pink"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-2xl bg-studio-pink hover:bg-studio-pink-hot text-white font-display font-black text-sm uppercase tracking-wider border-3 border-studio-dark shadow-sticker hover:shadow-sticker-lg transition-all duration-200 flex items-center justify-center gap-2 group"
              >
                <span>SEND INQUIRY TO MANSI</span>
                <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
          </div>
        )}
      </motion.div>
    </div>
  );
};
