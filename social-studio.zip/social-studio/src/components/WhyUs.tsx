import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Check, ShieldCheck, Zap, Smile } from 'lucide-react';
import { UnderlineScribble, ArrowDoodle, CheckmarkDoodle } from './Doodles';
import { sound } from '../utils/sound';

export const WhyUs: React.FC = () => {
  const cards = [
    {
      title: "CREATIVE",
      tagline: "“Because boring content is not an option.”",
      desc: "In an endless ocean of generic stock graphics, we create visuals that turn heads, stop thumbs, and spark genuine conversations.",
      icon: <Sparkles className="w-6 h-6 text-studio-pink-hot" />,
      color: "bg-white",
      badgeBg: "bg-studio-pink-soft",
      note: "100% original ♡",
      rotate: "hover:-rotate-2",
    },
    {
      title: "STRATEGIC",
      tagline: "“Every creative decision has a purpose.”",
      desc: "Aesthetic visuals without strategy are just pretty pictures. We align every color, hook, and caption with tangible business objectives.",
      icon: <Zap className="w-6 h-6 text-amber-600" />,
      color: "bg-white",
      badgeBg: "bg-studio-yellow-soft",
      note: "ROI-driven 🎯",
      rotate: "hover:rotate-2",
    },
    {
      title: "CONSISTENT",
      tagline: "“Strong brands show up consistently.”",
      desc: "Never leave your feed dry again. We maintain rigid editorial calendars so your audience always knows when to expect your best work.",
      icon: <ShieldCheck className="w-6 h-6 text-emerald-600" />,
      color: "bg-white",
      badgeBg: "bg-studio-green-soft",
      note: "Never dry 🗓️",
      rotate: "hover:-rotate-2",
    },
    {
      title: "PERSONAL",
      tagline: "“Your brand should still feel like YOU.”",
      desc: "We don't impose cookie-cutter formulas. We capture your authentic quirks, founder energy, and unique community language.",
      icon: <Smile className="w-6 h-6 text-purple-600" />,
      color: "bg-white",
      badgeBg: "bg-studio-purple-soft",
      note: "True to you ✨",
      rotate: "hover:rotate-2",
    },
  ];

  return (
    <section className="relative py-24 sm:py-32 bg-studio-cream bg-grid-paper overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20 relative">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-studio-pink-soft text-studio-pink-hot border-2 border-studio-dark shadow-sticker-sm text-xs font-black uppercase tracking-wider mb-4">
            <Sparkles className="w-4 h-4" />
            <span>THE SOCIAL STUDIO ADVANTAGE</span>
          </div>

          <h2 className="font-display font-black text-3xl sm:text-5xl lg:text-6xl text-studio-dark tracking-tight uppercase">
            WHY SOCIAL <br />
            <span className="relative inline-block text-studio-pink font-editorial italic lowercase text-5xl sm:text-7xl font-normal">
              studio?
            </span>
          </h2>
          <UnderlineScribble className="w-48 sm:w-60 mx-auto mt-2 text-studio-pink-hot" />

          {/* Hand drawn arrows pointing to the cards */}
          <div className="hidden lg:block absolute -bottom-8 -left-6 pointer-events-none">
            <ArrowDoodle className="w-16 h-12 text-studio-dark -rotate-12" direction="curved" />
            <span className="font-hand text-lg font-bold text-studio-pink block">Our 4 Core Rules ♡</span>
          </div>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {cards.map((card, idx) => (
            <motion.div
              key={card.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.4 }}
              onClick={() => sound.playPop()}
              className={`p-6 sm:p-7 rounded-3xl border-3 border-studio-dark ${card.color} shadow-sticker hover:shadow-sticker-lg transition-all duration-300 flex flex-col justify-between ${card.rotate} cursor-pointer hover:-translate-y-2`}
            >
              <div>
                <div className="flex items-center justify-between mb-5">
                  <div className={`p-3 rounded-2xl border-2 border-studio-dark ${card.badgeBg} shadow-sticker-sm`}>
                    {card.icon}
                  </div>
                  <span className="font-hand text-lg font-bold text-studio-pink">
                    {card.note}
                  </span>
                </div>

                <h3 className="font-display font-black text-2xl text-studio-dark uppercase tracking-tight mb-2">
                  {card.title}
                </h3>

                <p className="font-hand text-xl font-bold text-studio-dark/90 mb-3 leading-snug">
                  {card.tagline}
                </p>

                <p className="text-xs sm:text-sm text-studio-dark/75 font-medium leading-relaxed">
                  {card.desc}
                </p>
              </div>

              <div className="pt-4 mt-6 border-t-2 border-dashed border-studio-dark/15 flex items-center gap-2">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: idx * 0.3 }}
                >
                  <CheckmarkDoodle className="w-5 h-5 text-studio-green" />
                </motion.div>
                <span className="text-[11px] font-bold text-studio-dark/70 uppercase tracking-wider">
                  Verified Studio Promise
                </span>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
