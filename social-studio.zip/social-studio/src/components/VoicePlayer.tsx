import React, { useState, useEffect } from 'react';
import { Play, Pause, Square, RefreshCw, Heart, Volume2, Sparkles, Mic } from 'lucide-react';
import { sound } from '../utils/sound';
import {
  mansiVoice,
  MANSI_SCRIPT,
  VoiceState,
  speakIntroduction,
  stopIntroduction,
  pauseIntroduction,
  resumeIntroduction
} from '../utils/mansiVoice';

export {
  speakIntroduction,
  stopIntroduction,
  pauseIntroduction,
  resumeIntroduction
};

interface VoicePlayerProps {
  onSpeakingChange?: (isSpeaking: boolean) => void;
}

export const VoicePlayer: React.FC<VoicePlayerProps> = ({ onSpeakingChange }) => {
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const [activeParaIdx, setActiveParaIdx] = useState<number>(-1);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [isSupported, setIsSupported] = useState<boolean>(true);

  useEffect(() => {
    setIsSupported(mansiVoice.isSupported());

    const unsubscribe = mansiVoice.subscribe({
      onStateChange: (state) => {
        setVoiceState(state);
        if (onSpeakingChange) {
          onSpeakingChange(state === 'speaking');
        }
      },
      onParagraphChange: (idx) => {
        setActiveParaIdx(idx);
      },
      onVoiceLoaded: (voice) => {
        setSelectedVoice(voice);
      }
    });

    return () => {
      unsubscribe();
      // Clean up speech when the component unmounts as required
      mansiVoice.stopIntroduction();
    };
  }, [onSpeakingChange]);

  const handlePlayClick = () => {
    sound.playClick();
    speakIntroduction();
  };

  const handlePauseClick = () => {
    sound.playClick();
    pauseIntroduction();
  };

  const handleResumeClick = () => {
    sound.playClick();
    resumeIntroduction();
  };

  const handleStopClick = () => {
    sound.playClick();
    stopIntroduction();
  };

  const handleReplayClick = () => {
    sound.playSparkle();
    speakIntroduction();
  };

  const isSpeaking = voiceState === 'speaking';
  const isPaused = voiceState === 'paused';
  const isFinished = voiceState === 'finished';
  const isBusy = isSpeaking || isPaused;

  if (!isSupported) {
    return (
      <div className="p-4 rounded-2xl bg-studio-cream border-2 border-studio-dark/20 text-xs font-semibold text-studio-dark/60">
        Web Speech API is not supported in this browser.
      </div>
    );
  }

  // Voice name label for display
  const voiceLabel = selectedVoice
    ? selectedVoice.name.replace(/Microsoft|Google|Apple|Desktop|Online \(Natural\)/gi, '').trim()
    : 'Default Voice';

  return (
    <div className="w-full max-w-xl rounded-3xl bg-studio-cream-paper border-3 border-studio-dark shadow-sticker p-5 sm:p-6 space-y-4 relative overflow-hidden transition-all duration-300">
      
      {/* Decorative top accent tape */}
      <div className="washi-tape washi-tape-pink !top-[-10px] !w-28" />

      {/* Status Bar / Equalizer Reactivity Banner */}
      {isSpeaking && (
        <div className="flex items-center justify-between px-4 py-2.5 rounded-2xl bg-studio-pink-soft border-2 border-studio-dark shadow-sticker-sm animate-fadeIn">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-studio-pink opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-studio-pink-hot" />
            </span>
            <span className="font-display font-black text-xs sm:text-sm tracking-wider uppercase text-studio-dark flex items-center gap-1.5">
              <span>● MANSI IS SPEAKING</span>
            </span>
          </div>

          {/* Smooth animated audio waveform bars */}
          <div className="flex items-center gap-1 h-6 px-1">
            {[10, 22, 14, 26, 18, 24, 12, 26, 16, 20, 24, 12].map((maxH, i) => (
              <span
                key={i}
                className="w-1 bg-studio-pink-hot rounded-full"
                style={{
                  height: `${maxH}px`,
                  animation: 'wavePulse 0.45s ease-in-out infinite alternate',
                  animationDelay: `${(i % 5) * 80}ms`
                }}
              />
            ))}
          </div>
        </div>
      )}

      {isPaused && (
        <div className="flex items-center justify-between px-4 py-2 rounded-2xl bg-studio-yellow-soft border-2 border-studio-dark shadow-sticker-sm">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span className="font-display font-black text-xs uppercase tracking-wider text-studio-dark">
              ❚❚ MANSI IS PAUSED • READY TO RESUME
            </span>
          </div>
          <span className="text-[11px] font-bold text-studio-dark/60 font-hand text-base">
            take your time ♡
          </span>
        </div>
      )}

      {/* Main Action Button Area */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        
        {/* The Exact Required Button Format:
            ┌──────────────────────────────┐
            │  ♡  HEAR MANSI SPEAK     ▶  │
            └──────────────────────────────┘
            Transitions to:
            ❚❚ PAUSE when speaking, and back to ▶ HEAR MANSI SPEAK when finished
        */}
        {!isSpeaking && !isPaused && (
          <button
            onClick={handlePlayClick}
            className="w-full sm:w-auto min-w-[280px] px-6 sm:px-7 py-4 rounded-2xl bg-studio-pink hover:bg-studio-pink-hot text-white border-3 border-studio-dark shadow-sticker hover:shadow-sticker-lg transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5 flex items-center justify-between gap-4 font-display font-black text-sm sm:text-base tracking-wider uppercase select-none group"
            aria-label="Hear Mansi Speak"
          >
            <span className="text-xl leading-none text-white/90 group-hover:scale-125 transition-transform">
              ♡
            </span>
            <span className="font-black tracking-wide text-white">
              HEAR MANSI SPEAK
            </span>
            <Play className="w-5 h-5 fill-white text-white group-hover:translate-x-1 transition-transform" />
          </button>
        )}

        {isSpeaking && (
          <button
            onClick={handlePauseClick}
            className="w-full sm:w-auto min-w-[280px] px-6 sm:px-7 py-4 rounded-2xl bg-studio-dark hover:bg-studio-dark-surface text-studio-pink border-3 border-studio-dark shadow-sticker hover:shadow-sticker-lg transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5 flex items-center justify-between gap-4 font-display font-black text-sm sm:text-base tracking-wider uppercase select-none group"
            aria-label="Pause Voice"
          >
            <Pause className="w-5 h-5 fill-studio-pink text-studio-pink" />
            <span className="font-black tracking-wide text-white">
              ❚❚ PAUSE
            </span>
            <Pause className="w-5 h-5 fill-studio-pink text-studio-pink" />
          </button>
        )}

        {isPaused && (
          <button
            onClick={handleResumeClick}
            className="w-full sm:w-auto min-w-[280px] px-6 sm:px-7 py-4 rounded-2xl bg-studio-yellow hover:bg-studio-yellow-soft text-studio-dark border-3 border-studio-dark shadow-sticker hover:shadow-sticker-lg transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5 flex items-center justify-between gap-4 font-display font-black text-sm sm:text-base tracking-wider uppercase select-none group"
            aria-label="Resume Voice"
          >
            <Play className="w-5 h-5 fill-studio-dark text-studio-dark" />
            <span className="font-black tracking-wide text-studio-dark">
              RESUME SPEAKING
            </span>
            <Play className="w-5 h-5 fill-studio-dark text-studio-dark" />
          </button>
        )}

        {/* Secondary Controls: Replay and Stop */}
        <div className="flex items-center gap-2">
          {/* ↻ PLAY AGAIN button */}
          {(isBusy || isFinished) && (
            <button
              onClick={handleReplayClick}
              className="flex-1 sm:flex-initial px-4 py-4 rounded-2xl bg-white hover:bg-studio-cream text-studio-dark border-2 border-studio-dark shadow-sticker-sm hover:shadow-sticker transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5 flex items-center justify-center gap-2 font-display font-black text-xs uppercase tracking-wider select-none"
              title="Play from start"
            >
              <RefreshCw className="w-4 h-4 text-studio-pink animate-spin-hover" />
              <span>PLAY AGAIN</span>
            </button>
          )}

          {/* Stop Button */}
          {isBusy && (
            <button
              onClick={handleStopClick}
              className="px-4 py-4 rounded-2xl bg-white hover:bg-rose-50 text-rose-600 border-2 border-studio-dark shadow-sticker-sm hover:shadow-sticker transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5 flex items-center justify-center gap-1.5 font-display font-black text-xs uppercase tracking-wider select-none"
              title="Stop speaking"
            >
              <Square className="w-3.5 h-3.5 fill-rose-600" />
              <span>STOP</span>
            </button>
          )}
        </div>

      </div>

      {/* Premium Handwritten Note & Transparent Disclaimer */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-dashed border-studio-dark/15 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-hand text-xl sm:text-2xl text-studio-pink font-bold -rotate-1 select-none">
            “yes, that's actually me-ish ♡”
          </span>
        </div>

        <div className="flex items-center gap-1 text-[11px] font-medium text-studio-dark/60">
          <span>Voice: {voiceLabel}</span>
          <span>•</span>
          <span className="italic">Browser TTS generated</span>
        </div>
      </div>

      {/* Interactive Teleprompter Transcript Card */}
      <div className="rounded-2xl bg-white border-2 border-studio-dark/30 p-4 space-y-2.5 max-h-56 overflow-y-auto custom-scrollbar">
        <div className="flex items-center justify-between pb-1.5 mb-1 border-b border-studio-dark/10 text-[10px] font-black uppercase tracking-wider text-studio-dark/50">
          <span className="flex items-center gap-1">
            <Mic className="w-3 h-3 text-studio-pink" />
            <span>Introduction Script</span>
          </span>
          <span>6 Paragraphs</span>
        </div>

        {MANSI_SCRIPT.map((p, idx) => {
          const isCurrent = idx === activeParaIdx && isBusy;
          const isPast = activeParaIdx !== -1 && idx < activeParaIdx;

          return (
            <div
              key={p.id}
              onClick={() => {
                sound.playPop();
                mansiVoice.speakIntroduction(idx);
              }}
              className={`p-2.5 rounded-xl transition-all duration-200 cursor-pointer select-none border ${
                isCurrent
                  ? 'bg-studio-pink-soft/80 border-studio-pink shadow-sm translate-x-1'
                  : isPast
                  ? 'bg-studio-cream/40 border-transparent opacity-75'
                  : 'bg-transparent border-transparent hover:bg-studio-cream/60 opacity-60 hover:opacity-100'
              }`}
            >
              <p
                className={`text-xs sm:text-[13px] leading-relaxed transition-colors ${
                  isCurrent
                    ? 'text-studio-dark font-bold'
                    : 'text-studio-dark/85 font-medium'
                }`}
              >
                {p.display}
              </p>

              {isCurrent && (
                <div className="flex items-center gap-2 mt-1.5 text-[10px] font-black uppercase text-studio-pink tracking-wider">
                  <span className="w-1.5 h-1.5 rounded-full bg-studio-pink animate-ping" />
                  <span>{p.vibe}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

    </div>
  );
};
