import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Heart } from 'lucide-react';
import { UnderlineScribble, ArrowDoodle } from './Doodles';

export const Philosophy: React.FC = () => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const pillars = [
    {
      word: "ATTRACTIVE.",
      handNote: "“Make them stop scrolling.” ♡",
      desc: "If it doesn't catch the eye within 1.5 seconds, the message is lost. We craft scroll-stopping visual hooks that demand immediate visual intrigue.",
      noteRotate: "-rotate-3",
      accent: "text-studio-pink",
    },
    {
      word: "INFORMATIVE.",
      handNote: "“Give them a reason to stay.” 💡",
      desc: "Pretty visuals without substance are forgotten in minutes. Every piece of content delivers actionable clarity, educational value, or insight.",
      noteRotate: "rotate-2",
      accent: "text-amber-500",
    },
    {
      word: "CONSISTENT.",
      handNote: "“Make them remember you.” ✨",
      desc: "Brand recognition isn't built overnight. Regular posting cadence, unwavering visual guidelines, and an unmistakable tone of voice build true loyalty.",
      noteRotate: "-rotate-2",
      accent: "text-studio-green",
    },
    {
      word: "STUDENT-FOCUSED.",
      handNote: "“Always curious, always learning.” 📚",
      desc: "Algorithms change every week. We approach every platform with a student's curiosity: testing new formats, studying user psychology, and staying ahead of trends.",
      noteRotate: "rotate-3",
      accent: "text-studio-purple",
    },
  ];

  return (
    <section className="relative py-24 sm:py-36 bg-studio-dark text-white border-y-4 border-studio-dark overflow-hidden">
      
      {/* Background glow aura */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-studio-pink/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Pill */}
        <div className="text-center mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-studio-pink text-white border-2 border-white shadow-sticker-sm text-xs font-black uppercase tracking-wider mb-4">
            <Sparkles className="w-4 h-4 animate-wiggle" />
            <span>OUR NORTH STAR</span>
          </div>

          <h2 className="font-display font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
            BRAND <span className="font-editorial italic font-normal text-studio-pink lowercase text-5xl sm:text-7xl">philosophy</span>
          </h2>
          <p className="font-hand text-2xl sm:text-3xl text-studio-pink-light font-bold mt-2">
            ATTRACTIVE → INFORMATIVE → CONSISTENT → STUDENT-FOCUSED ♡
          </p>
        </div>

        {/* Huge Typography Stacks Revealed Individually During Scroll */}
        <div className="space-y-6 sm:space-y-10">
          {pillars.map((pillar, idx) => (
            <motion.div
              key={pillar.word}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className="relative group p-6 sm:p-10 rounded-3xl border-3 border-white/20 bg-studio-dark-surface/60 hover:border-studio-pink hover:bg-studio-dark-card transition-all duration-300"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                
                {/* Main Word */}
                <div className="space-y-2">
                  <div className="flex items-center gap-4">
                    <span className="text-xs font-black tracking-widest text-studio-pink uppercase px-2.5 py-0.5 rounded-full bg-studio-pink/20 border border-studio-pink/40">
                      PILLAR 0{idx + 1}
                    </span>
                    <span className="font-hand text-xl sm:text-2xl text-studio-yellow font-bold">
                      {pillar.handNote}
                    </span>
                  </div>

                  <h3 className="font-display font-black text-4xl sm:text-6xl lg:text-7xl xl:text-8xl tracking-tight uppercase group-hover:text-studio-pink transition-colors">
                    {pillar.word}
                  </h3>
                </div>

                {/* Description Box */}
                <div className="lg:max-w-md bg-white/5 p-5 rounded-2xl border border-white/10 group-hover:border-studio-pink/40 transition-colors">
                  <p className="text-sm sm:text-base text-white/80 font-medium leading-relaxed">
                    {pillar.desc}
                  </p>
                </div>

              </div>

              {/* Floating Doodle Arrow on First Element */}
              {idx === 0 && (
                <div className="hidden lg:block absolute -top-4 right-10 pointer-events-none">
                  <ArrowDoodle className="w-16 h-10 text-studio-pink -rotate-12" direction="down" />
                </div>
              )}
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
