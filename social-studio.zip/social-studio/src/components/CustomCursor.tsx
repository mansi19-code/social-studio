import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export const CustomCursor: React.FC = () => {
  const [mousePosition, setMousePosition] = useState({ x: -100, y: -100 });
  const [cursorText, setCursorText] = useState('');
  const [cursorVariant, setCursorVariant] = useState<'default' | 'link' | 'view' | 'button'>('default');
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    // Detect touch device
    if (window.matchMedia('(pointer: coarse)').matches) {
      setIsTouch(true);
      return;
    }

    const onMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });

      // Determine element being hovered
      const target = e.target as HTMLElement | null;
      if (!target) return;

      const portfolioEl = target.closest('[data-cursor="view"]');
      const buttonEl = target.closest('button, [role="button"], a');
      const textEl = target.closest('[data-cursor="text"]');

      if (portfolioEl) {
        setCursorVariant('view');
        setCursorText('VIEW →');
      } else if (textEl) {
        setCursorVariant('default');
        setCursorText((textEl as HTMLElement).dataset.cursorText || '');
      } else if (buttonEl) {
        setCursorVariant('button');
        setCursorText('');
      } else {
        setCursorVariant('default');
        setCursorText('');
      }
    };

    window.addEventListener('mousemove', onMouseMove);
    return () => window.removeEventListener('mousemove', onMouseMove);
  }, []);

  if (isTouch) return null;

  return (
    <>
      {/* Outer cursor dot/ring */}
      <motion.div
        className="fixed top-0 left-0 pointer-events-none z-[9999] flex items-center justify-center font-bold text-[10px] tracking-widest text-studio-dark"
        animate={{
          x: mousePosition.x - (cursorVariant === 'view' ? 36 : cursorVariant === 'button' ? 24 : 10),
          y: mousePosition.y - (cursorVariant === 'view' ? 36 : cursorVariant === 'button' ? 24 : 10),
          width: cursorVariant === 'view' ? 72 : cursorVariant === 'button' ? 48 : 20,
          height: cursorVariant === 'view' ? 72 : cursorVariant === 'button' ? 48 : 20,
          backgroundColor: cursorVariant === 'view' ? '#FF6496' : cursorVariant === 'button' ? 'rgba(255, 100, 150, 0.25)' : '#FF2A7A',
          borderColor: cursorVariant === 'button' ? '#FF2A7A' : '#141416',
          borderWidth: cursorVariant === 'button' ? 2 : cursorVariant === 'view' ? 2 : 0,
        }}
        transition={{
          type: 'spring',
          damping: 28,
          stiffness: 400,
          mass: 0.15
        }}
        style={{
          borderRadius: '9999px',
          color: cursorVariant === 'view' ? '#FFFFFF' : '#141416',
        }}
      >
        {cursorText && (
          <span className="font-sans font-extrabold uppercase select-none">{cursorText}</span>
        )}
      </motion.div>

      {/* Tiny inner center dot */}
      {cursorVariant === 'default' && (
        <motion.div
          className="fixed top-0 left-0 w-1.5 h-1.5 bg-white rounded-full pointer-events-none z-[10000]"
          animate={{
            x: mousePosition.x - 3,
            y: mousePosition.y - 3,
          }}
          transition={{
            type: 'spring',
            damping: 35,
            stiffness: 800,
            mass: 0.05
          }}
        />
      )}
    </>
  );
};
