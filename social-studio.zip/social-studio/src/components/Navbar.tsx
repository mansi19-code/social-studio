import React, { useState, useEffect } from 'react';
import { Menu, X, Sparkles, Volume2, VolumeX, ArrowRight } from 'lucide-react';
import { sound } from '../utils/sound';

interface NavbarProps {
  onOpenContact: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenContact }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [soundOn, setSoundOn] = useState(true);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleSound = () => {
    sound.enabled = !soundOn;
    setSoundOn(!soundOn);
    if (!soundOn) {
      sound.playPop();
    }
  };

  // Exact links from user prompt: Home, About, Services, Work, Process, Contact
  const navLinks = [
    { name: 'Home', href: '#hero' },
    { name: 'About', href: '#founder' },
    { name: 'Services', href: '#services' },
    { name: 'Work', href: '#portfolio' },
    { name: 'Process', href: '#process' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-4 sm:px-8 ${
          scrolled ? 'py-2.5 sm:py-3' : 'py-4 sm:py-5'
        }`}
      >
        <div
          className={`max-w-7xl mx-auto flex items-center justify-between px-5 py-2.5 sm:py-3 rounded-full transition-all duration-300 border-2 ${
            scrolled
              ? 'glass-nav border-studio-dark shadow-sticker-sm'
              : 'bg-white/90 backdrop-blur-md border-studio-dark/20 shadow-sm'
          }`}
        >
          {/* Brand Logo: Social Studio ♡ */}
          <a
            href="#hero"
            onClick={() => sound.playClick()}
            className="flex items-center gap-1.5 group font-display font-black text-xl sm:text-2xl tracking-tight text-studio-dark"
          >
            <span>Social Studio</span>
            <span className="text-studio-pink group-hover:scale-125 transition-transform duration-300 inline-block">
              ♡
            </span>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => sound.playClick()}
                className="px-3.5 py-1.5 rounded-full text-xs font-bold text-studio-dark/80 hover:text-studio-dark hover:bg-studio-pink-soft transition-all duration-200"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Right Action Controls: SFX Audio Switch & "LET'S TALK →" */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Tactile Audio Switch */}
            <button
              onClick={toggleSound}
              className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-studio-dark/30 text-[11px] font-black uppercase transition-all ${
                soundOn ? 'bg-studio-yellow text-studio-dark' : 'bg-studio-cream text-studio-dark/50'
              }`}
              title={soundOn ? "Mute interactive sound effects" : "Enable sound effects"}
            >
              {soundOn ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              <span>{soundOn ? "SFX ON" : "MUTED"}</span>
            </button>

            {/* Main CTA: LET'S TALK → */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenContact();
              }}
              className="inline-flex items-center gap-2 px-5 py-2 rounded-full font-black text-xs sm:text-sm bg-studio-pink hover:bg-studio-pink-hot text-white border-2 border-studio-dark shadow-sticker-sm hover:shadow-sticker transition-all duration-200 active:translate-y-0.5"
            >
              <span>LET’S TALK →</span>
            </button>

            {/* Mobile Animated Hamburger Menu Toggle */}
            <button
              onClick={() => {
                sound.playClick();
                setMobileMenuOpen(!mobileMenuOpen);
              }}
              className="lg:hidden p-2 rounded-full border-2 border-studio-dark bg-white hover:bg-studio-pink-soft text-studio-dark transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Animated Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-studio-cream/98 backdrop-blur-xl lg:hidden flex flex-col justify-between p-6 pt-24 animate-in fade-in zoom-in-95 duration-200">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-studio-pink-soft text-studio-pink text-xs font-bold border border-studio-pink/30 mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>MANSI’S DIGITAL CREATIVE AGENCY</span>
            </div>

            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => {
                  sound.playClick();
                  setMobileMenuOpen(false);
                }}
                className="block text-2xl font-black font-display text-studio-dark hover:text-studio-pink py-2 border-b border-studio-dark/10 transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="space-y-4 pt-6">
            <button
              onClick={() => {
                sound.playClick();
                setMobileMenuOpen(false);
                onOpenContact();
              }}
              className="w-full py-4 rounded-2xl font-black text-base bg-studio-pink hover:bg-studio-pink-hot text-white border-3 border-studio-dark shadow-sticker transition-all flex items-center justify-center gap-2"
            >
              <span>START A PROJECT →</span>
            </button>
            <p className="text-center font-hand text-lg text-studio-dark/70">
              Designed with ♡ for brands that refuse to be boring
            </p>
          </div>
        </div>
      )}
    </>
  );
};
