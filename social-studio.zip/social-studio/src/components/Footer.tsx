import React from 'react';
import { Heart, Instagram, Youtube, Sparkles, ArrowUp, Mail, Phone, MapPin } from 'lucide-react';
import { HeartDoodle } from './Doodles';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const socials = [
    { name: 'Instagram', href: 'https://instagram.com', icon: '📸' },
    { name: 'YouTube', href: 'https://youtube.com', icon: '▶️' },
    { name: 'TikTok', href: 'https://tiktok.com', icon: '🎵' },
    { name: 'Pinterest', href: 'https://pinterest.com', icon: '📌' },
    { name: 'Canva', href: 'https://canva.com', icon: '🎨' },
  ];

  return (
    <footer className="bg-studio-dark text-white border-t-4 border-studio-dark pt-16 sm:pt-20 pb-12 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-16 border-b border-white/10">
          
          {/* Col 1: Brand & Bio */}
          <div className="lg:col-span-5 space-y-4">
            <a href="#hero" className="font-display font-black text-3xl sm:text-4xl tracking-tight text-white inline-block">
              Social Studio <span className="text-studio-pink">♡</span>
            </a>
            
            <p className="text-sm text-white/70 font-medium leading-relaxed max-w-sm">
              A creative social media and digital studio helping businesses, creators, coaches, cafés, local brands and educational brands build attractive, informative and consistent digital identities.
            </p>

            <div className="pt-2">
              <span className="font-hand text-xl text-studio-pink font-bold">
                ATTRACTIVE → INFORMATIVE → CONSISTENT → STUDENT-FOCUSED
              </span>
            </div>

            {/* Social Icons row */}
            <div className="flex flex-wrap items-center gap-2 pt-2">
              {socials.map((s) => (
                <a
                  key={s.name}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-studio-pink hover:text-white border border-white/20 text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <span>{s.icon}</span>
                  <span>{s.name}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-display font-black text-sm uppercase tracking-widest text-studio-pink">
              Navigation
            </h4>
            <ul className="space-y-2 text-sm font-semibold text-white/80">
              <li><a href="#hero" className="hover:text-studio-pink transition-colors">Home</a></li>
              <li><a href="#founder" className="hover:text-studio-pink transition-colors">About Mansi</a></li>
              <li><a href="#services" className="hover:text-studio-pink transition-colors">Services</a></li>
              <li><a href="#portfolio" className="hover:text-studio-pink transition-colors">Portfolio</a></li>
              <li><a href="#creative-desk" className="hover:text-studio-pink transition-colors">Creative Desk</a></li>
              <li><a href="#process" className="hover:text-studio-pink transition-colors">Process</a></li>
              <li><a href="#packages" className="hover:text-studio-pink transition-colors">Monthly Packages</a></li>
            </ul>
          </div>

          {/* Col 3: Direct Inquiry Card */}
          <div className="lg:col-span-4 space-y-4">
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <h4 className="font-display font-black text-sm uppercase tracking-widest text-studio-yellow">
                Say Hello Directly ♡
              </h4>
              <p className="text-xs text-white/70 font-medium leading-relaxed">
                Have a project or partnership in mind? Mansi reads every single inquiry herself.
              </p>
              
              <div className="space-y-2 text-xs font-bold text-white/90">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-studio-pink" />
                  <span>hello@socialstudio.design</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-studio-pink">📸</span>
                  <span>@socialstudio.creative</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-studio-pink" />
                  <span>Global Studio • Working Everywhere</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-semibold text-white/60">
          <p>
            © {new Date().getFullYear()} Social Studio. All rights reserved. Designed with <span className="text-studio-pink">♡</span> by Mansi.
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-studio-pink hover:text-white transition-colors border border-white/20 text-white font-bold"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
};
