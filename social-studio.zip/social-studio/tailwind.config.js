/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        studio: {
          pink: {
            DEFAULT: '#FF6496',
            light: '#FFB8D2',
            soft: '#FFF0F5',
            hot: '#FF2A7A',
            deep: '#D81B60',
          },
          cream: {
            DEFAULT: '#FAF6EE',
            light: '#FCF9F3',
            dark: '#F0E8D8',
            paper: '#FFFDF9',
          },
          dark: {
            DEFAULT: '#141416',
            surface: '#1E1E24',
            card: '#23232A',
            border: '#2E2E38',
          },
          green: {
            DEFAULT: '#72C29B',
            soft: '#E8F5EE',
            sage: '#A5D6B7',
          },
          yellow: {
            DEFAULT: '#FDE047',
            soft: '#FEF9C3',
            note: '#FFF275',
          },
          purple: {
            DEFAULT: '#C084FC',
            soft: '#F3E8FF',
          },
          blue: {
            DEFAULT: '#60A5FA',
            soft: '#EFF6FF',
          }
        }
      },
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'Inter', 'sans-serif'],
        display: ['Cabinet Grotesk', 'Plus Jakarta Sans', 'sans-serif'],
        hand: ['Caveat', 'Playpen Sans', 'cursive'],
        serif: ['Instrument Serif', 'Playfair Display', 'serif'],
      },
      boxShadow: {
        'sticker': '0 8px 0 rgba(20, 20, 22, 1)',
        'sticker-pink': '0 8px 0 #FF2A7A',
        'sticker-sm': '0 4px 0 rgba(20, 20, 22, 1)',
        'sticker-lg': '0 12px 0 rgba(20, 20, 22, 1)',
        'float': '0 20px 40px -15px rgba(255, 100, 150, 0.25)',
        'glow-pink': '0 0 50px rgba(255, 100, 150, 0.35)',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px) rotate(0deg)' },
          '50%': { transform: 'translateY(-10px) rotate(1.5deg)' },
        },
        'float-reverse': {
          '0%, 100%': { transform: 'translateY(0px) rotate(0deg)' },
          '50%': { transform: 'translateY(10px) rotate(-1.5deg)' },
        },
        wiggle: {
          '0%, 100%': { transform: 'rotate(-2deg)' },
          '50%': { transform: 'rotate(2deg)' },
        },
        pulseGlow: {
          '0%, 100%': { opacity: '0.6', transform: 'scale(1)' },
          '50%': { opacity: '0.9', transform: 'scale(1.05)' },
        },
        marquee: {
          '0%': { transform: 'translateX(0%)' },
          '100%': { transform: 'translateX(-50%)' },
        },
        'marquee-reverse': {
          '0%': { transform: 'translateX(-50%)' },
          '100%': { transform: 'translateX(0%)' },
        }
      },
      animation: {
        float: 'float 5s ease-in-out infinite',
        'float-slow': 'float 7s ease-in-out infinite',
        'float-reverse': 'float-reverse 6s ease-in-out infinite',
        wiggle: 'wiggle 3s ease-in-out infinite',
        pulseGlow: 'pulseGlow 4s ease-in-out infinite',
        marquee: 'marquee 25s linear infinite',
        'marquee-reverse': 'marquee-reverse 25s linear infinite',
      }
    },
  },
  plugins: [],
}
