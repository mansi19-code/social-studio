@echo off
title Social Studio - Creative Website
echo ========================================================
echo        SOCIAL STUDIO - CREATIVE WEBSITE
echo ========================================================
echo.
echo Launching local development server...
echo Your browser will open automatically at http://localhost:5173
echo.
start http://localhost:5173
npm run dev
pause
